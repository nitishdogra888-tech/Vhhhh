#!/usr/bin/env bash
set -euo pipefail

# Lightweight pre-commit/CI safety check. It deliberately checks only common
# accidental credential patterns; it is not a replacement for secret scanning.
if grep -RInE --exclude-dir=.git --exclude='*.md' \
  'AKIA[0-9A-Z]{16}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----|xox[baprs]-[0-9A-Za-z-]{10,}|sk-[A-Za-z0-9]{20,}' .; then
  echo "Potential credential material found. Remove it before committing."
  exit 1
fi

echo "Repository safety check passed."
