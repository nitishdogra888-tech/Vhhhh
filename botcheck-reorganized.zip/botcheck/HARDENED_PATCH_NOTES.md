# Hardened trading patch — P0/P1 fixes

This build hardens the live trading path against duplicate exits and crash-time state loss.

## P0 fixes

1. **Atomic exit gate**
   - Replaced the volatile check/set exit flag with an atomic compare-and-acquire gate.
   - WebSocket protection exits and REST/manual exits cannot both acquire the same exit slot.

2. **Single exchange-order execution lock**
   - All BUY/SELL submissions go through `submitAndResolveOrder()`.
   - BUY and SELL network calls are serialized so independent service paths cannot submit simultaneously.

3. **Reconciliation is fail-closed**
   - A saved position is only considered reconciled when exchange quantity is within 0.1% (or 1e-8 absolute).
   - Executable position quantity is restored from the exchange balance, not the larger persisted value.
   - A manual “clear lock” is rejected if exchange and local position state still disagree.

## P1 fixes

4. **Crash-safe pending-order journal**
   - An order intent is synchronously persisted before submission.
   - The journal is cleared only after the fill is resolved and local risk/position state is durably updated.
   - If Android dies during submission/fill/state update, restart detects the journal and hard-locks trading rather than risking a duplicate order or silently losing the accounting event.

5. **Client-order-ID continuity**
   - Each submitted order receives an explicit unique client order ID that is also stored in the journal.
   - Existing Binance idempotent submission/recovery is preserved.

6. **Regression test for concurrent exit ownership**
   - Added `ExecutionGuardsTest` to verify only one concurrent caller can own the exit gate.

## Verification

The modified Kotlin source was syntax-checked with `kotlinc`. Full Android/Gradle compilation was not possible in this environment because the project does not contain the Gradle wrapper JAR and no system Gradle/Android SDK is installed here.
