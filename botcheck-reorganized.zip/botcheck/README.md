# Binance Trading Bot — Android

Kotlin/Android trading application focused on **Binance Spot Testnet**, deterministic technical analysis, hard risk controls, structured AI research, and optional TradingView signal confirmation.

> **Risk warning:** trading can lose money. AI analysis and backtests do not guarantee profit. Keep the bot on Binance Testnet until you have independently tested every execution path.

## Highlights

- Binance Spot Testnet trading path with startup reconciliation and fill verification.
- Deterministic market snapshots from verified/closed candles before AI analysis.
- Structured AI decision model: `BUY`, `SELL`, `HOLD`, or `REVIEW`.
- Invalid or incomplete AI output fails closed to `REVIEW` and cannot create an order.
- Bull/bear challenge and conservative risk-challenge layers are advisory only.
- Hard deterministic risk controls remain authoritative over AI and TradingView.
- Point-in-time filtering for historical/backtest analysis to prevent future-data leakage.
- Persistent AI analysis/checkpoint/outcome history for audit and later context.
- Optional TradingView webhook → VPS relay; the relay is not an exchange-order executor.
- Android boot recovery for the trading service when saved credentials/settings are available.
- Technical strategies, scanner, charts, history, and unit tests.
- Separate NSE/Angel One calculation scaffolding under `com.example.tradingbot.india`.

## Architecture

```text
                    Binance REST / WebSocket
                              |
                              v
                    Closed-candle validation
                              |
                              v
                    Deterministic snapshot
                              |
                +-------------+-------------+
                |             |             |
                v             v             v
            Technical       News        Sentiment
                \             |             /
                 +-----------+------------+
                             |
                             v
                      Bull / Bear challenge
                             |
                             v
                      Structured AI decision
                             |
                             v
                     AI risk challenge
                             |
                             v
                       Strategy / Rules
                             |
                             v
                       HARD risk engine
                             |
                             v
                        Reconciliation
                             |
                             v
                       Execution guards
                             |
                             v
                       Order journal
                             |
                             v
                           Binance
```

**AI, TradingView, and news/sentiment layers never replace the hard risk engine.**

## Repository layout

```text
app/
  src/main/java/com/example/tradingbot/
    AiResearchEngine.kt
    AiSignalAdvisor.kt
    GrokAdvisor.kt
    MarketResearchProvider.kt
    TradingViewSignalClient.kt
    TradingService.kt
    ExecutionGuards.kt
    TradeHistoryStore.kt
    PointInTime.kt
    scanner/
    india/
  src/test/java/com/example/tradingbot/

.github/workflows/build.yml       # GitHub Actions CI + APK artifacts
scripts/check-repo.sh             # local credential-pattern check
tools/backtest/                   # standalone backtest utility
tools/tradingview-relay/          # optional VPS webhook relay
```

## GitHub Actions

The repository includes a CI workflow at `.github/workflows/build.yml`.

On pushes and pull requests to `main`/`master`, it:

1. Checks out the source.
2. Installs JDK 17.
3. Installs Gradle 8.4.
4. Generates the matching Gradle wrapper inside the runner.
5. Verifies the Gradle project configuration.
6. Runs `testDebugUnitTest`.
7. Builds the debug APK.
8. Creates a temporary CI-only signing key.
9. Builds a signed release APK for CI/testing.
10. Uploads both APKs as workflow artifacts.

The temporary release key is generated inside the runner and is **not** committed. It should not be used as a permanent app-distribution signing key.

### Getting the APK from Actions

After a successful workflow run, open the GitHub Actions run and download:

- `trading-bot-debug-apk`
- `trading-bot-release-apk`

For a production release, create and protect your own permanent signing key instead of relying on the temporary CI key.

### Why the repository does not contain `gradlew`

This source package intentionally does not commit the Gradle wrapper JAR. GitHub Actions installs Gradle 8.4 and generates the wrapper during the run. Android Studio can also manage the Gradle project directly.

The configured wrapper distribution is Gradle 8.4 so the project configuration and CI use the same Gradle generation.

## Local Android build

Requirements:

- Android Studio
- JDK 17
- Android SDK Platform 34
- Android SDK Build Tools compatible with API 34

Open the extracted repository in Android Studio and let it sync Gradle. Then run the app or build the debug APK from Android Studio.

For command-line builds, use a Gradle 8.4 installation or generate a local wrapper with Gradle 8.4 before using `./gradlew`.

## Secrets and credentials

**Never put real credentials in GitHub.**

The app is designed to store exchange credentials in encrypted Android storage. Do not hard-code:

- Binance API key/secret
- Angel One credentials/TOTP secrets
- OpenAI/Grok keys
- TradingView webhook secrets
- private keys or keystores

The GitHub Actions workflow does not need exchange credentials and does not place live orders.

See `SECURITY.md` for the security policy.

## TradingView VPS relay

The optional relay is under:

```text
tools/tradingview-relay/
```

It accepts authenticated TradingView webhook signals and stores the latest signal for the Android client. It is intentionally **not** a second order executor.

See `tools/tradingview-relay/README.md` for deployment instructions and `.env.example` for configuration names.

## AI research pipeline

The AI research layer follows this pattern:

```text
Verified snapshot
      |
      +--> Bull case
      |
      +--> Bear case
      |
      +--> News/sentiment context
      |
      v
Structured adjudication
      |
      v
Conservative risk challenge
      |
      v
AiDecision (BUY/SELL/HOLD/REVIEW)
```

An AI decision contains an analysis ID, symbol, timestamp, model identifier, confidence, reasoning, levels where applicable, and research context. Invalid JSON or invalid decision fields result in `REVIEW` rather than an implicit `HOLD`.

AI memory is context/audit history only. It does **not** automatically change hard risk limits.

## Backtesting and data integrity

Historical analysis is point-in-time constrained:

```text
analysis time = T
allowed data  <= T
future data   > T  -> rejected
```

This protection should cover candles, indicators, news/sentiment, scanner results, fundamentals, and AI memory used for historical decisions.

A good backtest is not proof of future performance. Include fees, slippage, latency, liquidity, and realistic execution assumptions when evaluating results.

## Trading safety

The order path remains:

```text
AI / TradingView advisory
        |
        v
Strategy / RuleEngine
        |
        v
Deterministic HARD risk controls
        |
        v
Reconciliation
        |
        v
ExecutionGuards
        |
        v
Pending-order journal
        |
        v
Exchange
```

The AI layer cannot bypass daily loss limits, position protections, duplicate-order controls, reconciliation, or execution serialization.

## Current India/NSE module status

`app/src/main/java/com/example/tradingbot/india/` contains calculation and risk scaffolding for NSE cash-market planning, including cost modeling, market-hour gating, position tracking, and trade statistics.

This module is **not presented as a live Angel One integration**. Order placement/dashboard integration and a complete NSE holiday calendar remain separate work.

## Testing

Current unit-test coverage includes technical indicators, strategy/risk behavior, execution guards, accounting, market-data validation, and India-market calculations.

Before unattended trading, test at minimum:

- duplicate order attempts
- partial fills
- restart/recovery
- stale candles
- invalid AI JSON
- AI `REVIEW`
- TradingView authentication failure
- network loss/reconnect
- daily-loss lock
- consecutive-loss pause
- stop/target/trailing exits
- point-in-time backtests

## GitHub setup

1. Extract this repository.
2. Create an empty GitHub repository.
3. Commit the extracted project to `main`.
4. Push the project.
5. Open **Actions** and run/inspect `Android CI`.
6. Download the APK artifacts only after the workflow is green.

Do not upload API keys or `.env` files. Review the first push with GitHub's secret-scanning/security warnings enabled where available.

## Contributing

See `CONTRIBUTING.md`.

## License

MIT. See `LICENSE`.


## In-App Help / How to Use

The Android app now includes a beginner-friendly **How to Use** screen. It explains the real app flow, the main Dashboard areas, the AI & Profile workspace, the safety/risk layer, and common troubleshooting cases.

You can open it from:
- the launcher/configuration screen: **How to Use**
- the Dashboard → **AI & Profile** tab: **How to Use**

### Screenshots

The help screen intentionally does **not** use fake or stock trading screenshots. The repository contains older `tip_*.png` illustration assets, but the new Help screen does not present those as real screenshots. For device-accurate visual callouts, capture screenshots from the running APK/emulator and add them to `app/src/main/res/drawable/` with clear names such as `help_dashboard.png`, `help_position.png`, `help_controls.png`, `help_history.png`, and `help_ai_profile.png`.

### Build and test

Use the existing Gradle/GitHub Actions workflow. After UI changes, verify Kotlin compilation, Android resources, unit tests, and the debug APK before installation on a device/emulator.

### Safety

The Help screen is documentation only. It does not change API credentials, trading logic, AI behavior, hard risk controls, reconciliation, or execution guards. AI remains advisory and hard risk controls remain authoritative.

## UI/UX refresh

The Android interface now uses a more beginner-first layout while preserving the existing trading and safety architecture. The refresh includes:

- A clearer setup roadmap on the configuration screen.
- Stronger visual hierarchy for exchange credentials, AI, risk, session-risk, and strategy settings.
- Larger, clearer primary Start/Stop actions and grouped navigation shortcuts.
- A dedicated first-run orientation dialog that points new users to the in-app guide and Testnet workflow.
- Improved Dashboard bottom navigation with a clearer selected-tab indicator and consistent spacing.
- Cleaner Scanner and History headers with clearer descriptions and card boundaries.
- Existing Help / How to Use content remains available and is still separate from trading logic.

The UI does not create or display fake market values. Live values continue to come from the existing application state.
