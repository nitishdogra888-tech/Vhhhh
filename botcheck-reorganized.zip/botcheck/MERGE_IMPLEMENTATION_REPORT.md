# TradingAgents / Trading-R1 / DOC merge implementation

## Base selected

The hardened Kotlin project remains the execution foundation. The DOC feature layer was already represented by the hardened project (AI advisors, scanner, indicators, strategy, backtest, chart/UI). Trading-R1 contains only a README in the supplied archive, so there was no implementation to merge.

## Implemented

1. Deterministic verified market snapshot
   - closed candles only
   - OHLCV validation
   - EMA10, SMA50, SMA200, RSI14, Bollinger(20,2), MACD(12,26,9), ATR14, volume ratio
   - recent closes
   - stable SHA-256 snapshot hash
   - future/incomplete data excluded

2. Structured AI decision schema
   - BUY / SELL / HOLD / REVIEW
   - confidence 0..1
   - optional entry/stop/target
   - risk/reward
   - reasoning
   - analysis ID, timestamp, model, snapshot hash
   - malformed levels or invalid JSON become REVIEW
   - BUY levels require coherent direction and minimum 1.5 R:R

3. Bull/Bear challenge
   - separate bullish and bearish research calls
   - adjudicator combines them
   - no LangGraph/Python dependency in Android

4. Conservative risk challenger
   - challenges volatility, R:R, trend conflict, overextension, stale data, low volume, contradictory indicators, and stop quality
   - rejection becomes REVIEW
   - never has authority over hard deterministic risk limits

5. AI memory + reflection
   - stores decision context
   - links approved analysis to a trade
   - records actual net outcome and a reflection
   - prior outcomes are supplied as context to future AI research
   - never changes hard risk settings automatically

6. AI research checkpointing
   - stages are persisted per symbol/closed-candle snapshot
   - interrupted research can reuse completed bull/bear/adjudication/risk stages

7. Point-in-time backtesting
   - explicit as-of cutoff
   - rows after cutoff excluded
   - sorted/deduplicated candles
   - OHLCV validation

8. TradingView/VPS confirmation
   - dependency-free Python webhook relay
   - Docker deployment
   - authenticated latest-signal endpoint
   - Pine Script alert example
   - optional Android gate requiring recent BUY confirmation

9. 24/7 boot restart
   - Android BOOT_COMPLETED receiver
   - saved credentials/settings are reused
   - service now falls back to encrypted saved credentials/settings when a restart intent does not contain them

## Explicitly not merged

- TradingAgents LangGraph graph/runtime
- TradingAgents Python dataflow/provider stack
- TradingAgents portfolio manager as risk authority
- TradingAgents exchange execution code
- Trading-R1 implementation (none supplied beyond README)

## Execution authority

The final order path remains the hardened path:

`strategy -> AI/TradingView optional gates -> deterministic risk checks -> reconciliation -> ExecutionGuards -> pending-order journal -> Binance`

Protective exits are not blocked by the AI or TradingView confirmation gates.

## Secrets

No API key or API secret was added to source. Existing encrypted credential storage remains in use. The VPS relay uses an environment-provided token.

## Verification performed in this environment

- Backtest Kotlin source compiled with local `kotlinc`.
- Backtest point-in-time filtering was exercised with synthetic CSV data.
- TradingView relay Python source passed `py_compile`.
- Full Android Gradle/APK compilation could not be executed here because the Android SDK/Gradle distribution was not available locally and outbound package download was unavailable. The supplied GitHub Actions workflow remains the appropriate full Android build check.
