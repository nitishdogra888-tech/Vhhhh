# Binance Trading Bot — rebuild audit

## India equity calculation engine (this change)

- Added `IndiaCostModel`, `IndiaRiskManager`, `IndiaPositionTracker`,
  `IndiaMarketCalendar`, `IndiaTradeStats` under `.../india/`. These are new,
  additive files — no existing crypto file (`Strategy.kt`, `TradingService.kt`,
  `RuleEngine.kt`, `DashboardActivity.kt`, etc.) was modified, so the existing
  crypto flow's behavior and tests are unaffected.
- Rate-card figures (brokerage, STT, exchange transaction charge, SEBI
  turnover fee, stamp duty, GST, DP charge) were checked against Angel One's
  published charges pages as of this change; these are planning estimates
  for the bot's own math, not tax advice, and should be reconciled against
  real contract notes before being trusted for live sizing decisions.
- Verified by hand (Python re-implementation of the exact same formulas,
  cross-checked against the Kotlin unit tests) that: intraday and delivery
  produce different totals on an identical trade, delivery's charges are
  strictly higher than intraday's on the same notional (STT on both legs +
  DP charge), and brokerage is floored at ₹5 / capped at ₹20 per the rate
  card.
- `IndiaMarketCalendar`'s weekday/session-window logic and its IST-vs-UTC
  day-boundary handling were verified against known calendar dates
  (2026-09-16 Wed, 2026-09-19 Sat) rather than assumed.
- A full Gradle/Kotlin compile was **not** run in this sandbox (no network,
  no local Gradle distribution — same constraint noted below for the rest of
  the repo). Braces/parens and Kotlin syntax were checked by inspection only;
  run the existing GitHub Actions workflow (which already compiles
  `:app:compileDebugKotlin` and runs unit tests first) before trusting this
  compiles clean.
- Not touched: `AngelOneApiClient`'s order-placement path, `TradingService`,
  or any UI screen. This change is the calculation layer only — see the
  README's India section for what integration work remains.

## Current rebuild fixes

- Fixed the manual-history `indexOfFirst` lambda so its parameter is explicitly declared; this removes the Kotlin `Unresolved reference: it` failure pattern seen in CI after interrupted manual-history edits.
- Removed remaining ambiguous implicit lambda `it` usages from the main source set and replaced them with explicit parameter names for safer maintenance and clearer compiler diagnostics.
- Kept manual and automated trade history separated through the existing `manualTrade` flag and dedicated filtered collections.
- Kept real Binance BTC market data and the existing live/testnet trading separation intact.
- Kept manual BUY/SELL, custom stop loss/take profit, auto-exit, position persistence, risk controls, indicator confluence and history features intact.
- Updated GitHub Actions to compile `:app:compileDebugKotlin` first (fail-fast), then run unit tests and both APK builds.
- Kept temporary CI signing isolated to GitHub Actions; no real signing credentials are stored in the repository.
- README is stored at the repository root.

## Verification performed in this environment

- ZIP/project extracted successfully.
- Kotlin source braces/parentheses checked for balanced structure.
- Android XML layout files parsed successfully.
- Required root Gradle/settings/build files verified.
- Required README/AUDIT files verified at repository root.
- Secret-pattern scan completed with no obvious API-key credential embedded in project text.

## Not honestly verified here

A full Android Gradle compile/install was not executed in this sandbox because the Gradle distribution is not locally available and external dependency download is unavailable. GitHub Actions is configured to perform the real compile/test/APK gate.
