# Trading Bot — Patched Priority 1–8 Fixes

This archive contains the Kotlin source patched against the uploaded GitHub-ready project.

## Implemented

1. **Dynamic Binance WebSocket**
   - Uses mainnet stream in LIVE mode and testnet stream in TESTNET mode.
   - Uses the selected symbol instead of hard-coded BTCUSDT.

2. **Persistent Auto-BUY circuit breaker**
   - Five consecutive trading-loop failures latch AUTO-BUY pause.
   - Pause survives service/process restart.
   - Resume action clears the persisted pause.
   - Circuit breaker does not auto-clear after one successful cycle.

3. **Daily trading-budget accounting**
   - Budget is consumed by actual filled BUY notional.
   - Profitable exits no longer refill the daily budget.
   - Daily used-notional is persisted across restart and resets on a new calendar day.
   - Older stored risk records remain compatible.

4. **Two-hour session-budget accounting**
   - Session budget is consumed by actual filled BUY notional.
   - Profit/loss no longer replenishes the notional budget.
   - Session state is persisted across service restart while the two-hour window is still valid.

5. **Safe exchange-position adoption**
   - The bot no longer invents an entry price from the current market price.
   - Adoption queries recent exchange trades and derives a FIFO cost basis.
   - If the trade history cannot explain the full held balance, the bot keeps the hard lock instead of fabricating P&L.

6. **Base-asset/symbol handling**
   - Startup/reconciliation messages and trade notifications use the selected base asset/symbol rather than BTC-specific wording.

7. **Protection during stream failure**
   - If the WebSocket is stale/disconnected, fresh REST market price is used for account valuation and exit protection.
   - New entries remain blocked while the stream is unavailable.

8. **Exit-failure/race protection**
   - REST exit processing will not race an in-flight WebSocket exit.
   - Failed/unknown exits create a persistent protection-error state and alert the user.
   - Repeated identical protection failures do not spam a new notification every cycle.
   - Unknown order submission states are no longer blindly re-submitted by `placeOrderIdempotent()`.

## Tests added

`RiskAccountingTest.kt` covers:
- daily notional budget consumption;
- no budget refill from profit;
- session notional consumption and restoration;
- session profit-target lock.

## Build verification

A full Gradle/Android build could not be executed in this environment because the project has no `gradlew` launcher/JAR and the environment could not download Gradle 8.2 from `services.gradle.org`.

Run the project's normal Android/CI build before installing or using the APK. The patched source is intended for TESTNET validation first; it should not be treated as proof of live-trading safety.
