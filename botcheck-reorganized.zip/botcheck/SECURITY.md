# Security

## API keys and secrets

Never commit Binance, Angel One, OpenAI, Grok, TradingView webhook tokens, or other credentials to Git.

Use the Android app's encrypted credential storage for user-entered exchange credentials. For GitHub Actions, use GitHub Actions Secrets only when a workflow genuinely needs a secret.

The CI workflow in this repository does **not** need exchange credentials and does not place live orders.

If a credential is accidentally committed, revoke/rotate it immediately at the provider and remove it from Git history.

## Trading safety

The project is intended for testing and development. Start with Binance Testnet. AI output, TradingView signals, and backtests must never be treated as guaranteed profitable signals.

Report security vulnerabilities privately rather than opening a public issue with exploit details or credentials.
