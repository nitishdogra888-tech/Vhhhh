# Contributing

## Before opening a PR

1. Do not commit API keys, secrets, keystores, `local.properties`, or `.env` files.
2. Keep exchange execution behind the existing deterministic risk and execution guards.
3. Add or update unit tests for strategy, risk, state, and parsing changes.
4. Keep AI advisory output structured and fail closed: invalid output must become `REVIEW`, not `HOLD` or an order.
5. Do not add live-order credentials to GitHub Actions.

## Local development

Open the project in Android Studio with JDK 17 and allow Gradle/Android Studio to sync the project. The repository targets Android API 34.

The CI workflow generates the Gradle wrapper on the runner, so a pre-generated wrapper JAR is intentionally not committed.

## Pull requests

Describe:
- what changed
- why it changed
- tests performed
- whether order execution behavior changed

Never include real account credentials in issues or pull requests.
