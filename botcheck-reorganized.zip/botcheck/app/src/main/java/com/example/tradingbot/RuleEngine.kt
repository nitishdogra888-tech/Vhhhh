package com.example.tradingbot

import com.example.tradingbot.scanner.TechnicalIndicators
import org.json.JSONArray

/**
 * Small expression language for the Dashboard's "Custom Rule" buy/sell
 * fields. Examples:
 *
 *   RSI < 30
 *   PRICE > EMA50
 *   RSI < 30 AND PRICE > SMA20
 *   RSI(7) > 70 OR PRICE < EMA(200)
 *
 * Grammar (keywords/indicators are case-insensitive):
 *   expr      := andGroup (OR andGroup)*      -- OR of ANDs, left to right
 *   andGroup  := cond (AND cond)*
 *   cond      := operand op operand
 *   operand   := PRICE | RSI[(n)] | EMA(n) | SMA(n) | <number>
 *   op        := <= | >= | == | < | >
 *
 * RSI defaults to period 14, EMA/SMA default to period 20 when no period
 * is given. A blank rule is syntactically valid (validate() returns null)
 * and simply never fires when evaluated.
 */
object RuleEngine {

    private sealed class Operand {
        object Price : Operand()
        data class Constant(val value: Double) : Operand()
        data class Indicator(val kind: String, val period: Int) : Operand()
    }

    private data class Condition(val left: Operand, val op: String, val right: Operand)

    private val OPERATOR_REGEX = Regex("""<=|>=|==|<|>""")
    private val INDICATOR_REGEX = Regex("""^(RSI|EMA|SMA)\(?(\d+)?\)?$""", RegexOption.IGNORE_CASE)

    /** Returns null if the rule is syntactically valid, otherwise a human-readable error. */
    fun validate(rule: String): String? {
        if (rule.isBlank()) return null
        return try {
            parse(rule)
            null
        } catch (e: IllegalArgumentException) {
            e.message ?: "Invalid rule."
        }
    }

    /**
     * Evaluates the rule against the same kline JSON array shape the
     * built-in strategies use. Returns false for a blank rule, an
     * unparsable rule, or when there isn't yet enough candle history for
     * the indicators it references -- never throws.
     */
    fun evaluate(rule: String, klines: JSONArray): Boolean {
        if (rule.isBlank()) return false
        val groups = try {
            parse(rule)
        } catch (e: IllegalArgumentException) {
            return false
        }
        if (klines.length() < 2) return false
        val closes = (0 until klines.length() - 1).map { index -> klines.getJSONArray(index).getString(4).toDouble() }
        if (closes.size < 2) return false
        return groups.any { andGroup -> andGroup.all { cond -> evaluateCondition(cond, closes) } }
    }

    private fun parse(rule: String): List<List<Condition>> {
        val orParts = rule.split(Regex("""(?i)\bOR\b"""))
        if (orParts.any { part -> part.isBlank() }) {
            throw IllegalArgumentException("Rule has an empty clause next to \"OR\".")
        }
        return orParts.map { orPart ->
            val andParts = orPart.split(Regex("""(?i)\bAND\b"""))
            if (andParts.any { part -> part.isBlank() }) {
                throw IllegalArgumentException("Rule has an empty clause next to \"AND\".")
            }
            andParts.map { part -> parseCondition(part) }
        }
    }

    private fun parseCondition(text: String): Condition {
        val trimmed = text.trim()
        val opMatch = OPERATOR_REGEX.find(trimmed)
            ?: throw IllegalArgumentException("Missing comparison operator (<, >, <=, >=, ==) in \"$trimmed\".")
        val left = trimmed.substring(0, opMatch.range.first).trim()
        val right = trimmed.substring(opMatch.range.last + 1).trim()
        if (left.isEmpty() || right.isEmpty()) {
            throw IllegalArgumentException("Incomplete comparison in \"$trimmed\". Expected e.g. \"RSI < 30\".")
        }
        return Condition(parseOperand(left, trimmed), opMatch.value, parseOperand(right, trimmed))
    }

    private fun parseOperand(token: String, context: String): Operand {
        val upper = token.uppercase()
        if (upper == "PRICE" || upper == "CLOSE") return Operand.Price
        INDICATOR_REGEX.matchEntire(upper)?.let { match ->
            val kind = match.groupValues[1]
            val defaultPeriod = if (kind == "RSI") 14 else 20
            val period = match.groupValues[2].toIntOrNull() ?: defaultPeriod
            if (period <= 0) throw IllegalArgumentException("Period must be positive in \"$context\".")
            return Operand.Indicator(kind, period)
        }
        token.toDoubleOrNull()?.let { value -> return Operand.Constant(value) }
        throw IllegalArgumentException(
            "Can't understand \"$token\" in \"$context\". Use PRICE, RSI, RSI(period), EMA(period), SMA(period), or a number."
        )
    }

    private fun resolveOperand(operand: Operand, closes: List<Double>): Double? = when (operand) {
        is Operand.Price -> closes.lastOrNull()
        is Operand.Constant -> operand.value
        is Operand.Indicator -> when (operand.kind) {
            "RSI" -> TechnicalIndicators.rsi(closes, operand.period).lastOrNull()
            "EMA" -> TechnicalIndicators.ema(closes, operand.period).lastOrNull()
            "SMA" -> if (closes.size >= operand.period) closes.takeLast(operand.period).average() else null
            else -> null
        }
    }

    private fun evaluateCondition(cond: Condition, closes: List<Double>): Boolean {
        val left = resolveOperand(cond.left, closes) ?: return false
        val right = resolveOperand(cond.right, closes) ?: return false
        return when (cond.op) {
            "<" -> left < right
            ">" -> left > right
            "<=" -> left <= right
            ">=" -> left >= right
            "==" -> kotlin.math.abs(left - right) < 1e-9
            else -> false
        }
    }
}
