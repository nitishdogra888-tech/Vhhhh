package com.example.tradingbot

import com.example.tradingbot.scanner.TechnicalIndicators
import org.json.JSONArray
import java.security.MessageDigest
import java.util.Locale

/**
 * Deterministic, point-in-time market snapshot. This is the only numeric
 * market source that the AI research layer is allowed to treat as exact.
 * It is deliberately built from CLOSED Binance candles only.
 */
data class MarketSnapshot(
    val symbol: String,
    val asOfMs: Long,
    val candleOpenTimeMs: Long,
    val candleCloseTimeMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val ema10: Double?,
    val sma50: Double?,
    val sma200: Double?,
    val rsi14: Double?,
    val bollingerMiddle: Double?,
    val bollingerUpper: Double?,
    val bollingerLower: Double?,
    val macd: Double?,
    val macdSignal: Double?,
    val macdHistogram: Double?,
    val atr14: Double?,
    val volumeRatio20: Double?,
    val recentCloses: List<Double>,
    val candleCount: Int,
    val source: String = "Binance REST",
    val snapshotHash: String
) {
    val dataAgeMs: Long get() = (asOfMs - candleCloseTimeMs).coerceAtLeast(0L)

    fun asPromptText(): String = buildString {
        appendLine("VERIFIED MARKET SNAPSHOT — SOURCE OF TRUTH")
        appendLine("symbol=$symbol")
        appendLine("analysis_as_of_ms=$asOfMs")
        appendLine("latest_closed_candle_open_ms=$candleOpenTimeMs")
        appendLine("latest_closed_candle_close_ms=$candleCloseTimeMs")
        appendLine("data_age_ms=$dataAgeMs")
        appendLine("source=$source")
        appendLine("snapshot_hash=$snapshotHash")
        appendLine("closed_candles_used=$candleCount")
        appendLine("OHLCV: open=$open high=$high low=$low close=$close volume=$volume")
        appendLine("EMA10=${fmt(ema10)}")
        appendLine("SMA50=${fmt(sma50)}")
        appendLine("SMA200=${fmt(sma200)}")
        appendLine("RSI14=${fmt(rsi14)}")
        appendLine("BB20_MIDDLE=${fmt(bollingerMiddle)} BB20_UPPER=${fmt(bollingerUpper)} BB20_LOWER=${fmt(bollingerLower)}")
        appendLine("MACD=${fmt(macd)} MACD_SIGNAL=${fmt(macdSignal)} MACD_HIST=${fmt(macdHistogram)}")
        appendLine("ATR14=${fmt(atr14)}")
        appendLine("VOLUME_RATIO20=${fmt(volumeRatio20)}")
        appendLine("RECENT_CLOSES=${recentCloses.joinToString(",") { "%.8f".format(Locale.US, it) }}")
        appendLine("RULE: Never invent exact numbers. If another source conflicts with this snapshot, flag the conflict and use REVIEW.")
    }

    private fun fmt(v: Double?): String = v?.let { "%.8f".format(Locale.US, it) } ?: "N/A"
}

object MarketDataValidator {
    data class ValidationResult(val snapshot: MarketSnapshot?, val errors: List<String>) {
        val isValid: Boolean get() = snapshot != null && errors.isEmpty()
    }

    fun buildClosedSnapshot(
        symbol: String,
        klines: JSONArray,
        asOfMs: Long = System.currentTimeMillis(),
        minimumCandles: Int = 200,
        recentCount: Int = 30
    ): ValidationResult {
        val rows = ArrayList<Array<Double>>(klines.length())
        val times = ArrayList<Pair<Long, Long>>(klines.length())
        val errors = ArrayList<String>()

        for (i in 0 until klines.length()) {
            val k = try { klines.getJSONArray(i) } catch (_: Exception) { continue }
            if (k.length() < 7) continue
            val openTime = k.optLong(0, -1L)
            val closeTime = k.optLong(6, -1L)
            val open = k.optString(1).toDoubleOrNull()
            val high = k.optString(2).toDoubleOrNull()
            val low = k.optString(3).toDoubleOrNull()
            val close = k.optString(4).toDoubleOrNull()
            val volume = k.optString(5).toDoubleOrNull()
            if (openTime < 0 || closeTime < 0 || open == null || high == null || low == null || close == null || volume == null) continue
            if (!PointInTime.isAllowed(closeTime, asOfMs)) continue // current/incomplete/future candle is excluded
            rows.add(arrayOf(open, high, low, close, volume))
            times += openTime to closeTime
        }

        if (rows.size < minimumCandles) {
            errors += "Not enough verified closed candles: ${rows.size} < $minimumCandles"
            return ValidationResult(null, errors)
        }

        for (i in rows.indices) {
            val r = rows[i]
            if (!r.all { it.isFinite() }) errors += "Non-finite OHLCV at row $i"
            if (r[0] <= 0 || r[1] <= 0 || r[2] <= 0 || r[3] <= 0 || r[4] < 0) errors += "Invalid OHLCV at row $i"
            if (r[1] < r[2] || r[1] < r[0] || r[1] < r[3] || r[2] > r[0] || r[2] > r[3]) errors += "Impossible OHLC relationship at row $i"
            if (i > 0 && times[i].first <= times[i - 1].first) errors += "Candle timestamps are not strictly increasing"
        }
        if (errors.isNotEmpty()) return ValidationResult(null, errors.distinct())

        val closes = rows.map { it[3] }
        val highs = rows.map { it[1] }
        val lows = rows.map { it[2] }
        val volumes = rows.map { it[4] }
        val ema10 = TechnicalIndicators.ema(closes, 10).lastOrNull()
        val sma50 = TechnicalIndicators.sma(closes, 50).lastOrNull()
        val sma200 = TechnicalIndicators.sma(closes, 200).lastOrNull()
        val rsi14 = TechnicalIndicators.rsi(closes, 14).lastOrNull()
        val bb = TechnicalIndicators.bollingerBands(closes, 20, 2.0)
        val macd = TechnicalIndicators.macd(closes, 12, 26, 9)
        val atr = TechnicalIndicators.atr(highs, lows, closes, 14)
        val volumeRatio = TechnicalIndicators.volumeRatio(volumes, 20)
        val latest = rows.lastIndex
        val snapshotHash = sha256(buildString {
            append(symbol.uppercase(Locale.US)).append('|')
            append(times[latest].first).append('|').append(times[latest].second).append('|')
            rows[latest].joinTo(this, separator = ",")
            append('|').append(ema10).append('|').append(sma50).append('|').append(sma200)
            append('|').append(rsi14).append('|').append(bb.middle[latest]).append('|').append(bb.upper[latest]).append('|').append(bb.lower[latest])
            append('|').append(macd.macdLine[latest]).append('|').append(macd.signalLine[latest]).append('|').append(macd.histogram[latest])
            append('|').append(atr[latest]).append('|').append(volumeRatio)
        })
        val snapshot = MarketSnapshot(
            symbol = symbol.uppercase(Locale.US),
            asOfMs = asOfMs,
            candleOpenTimeMs = times[latest].first,
            candleCloseTimeMs = times[latest].second,
            open = rows[latest][0], high = rows[latest][1], low = rows[latest][2],
            close = rows[latest][3], volume = rows[latest][4],
            ema10 = ema10, sma50 = sma50, sma200 = sma200, rsi14 = rsi14,
            bollingerMiddle = bb.middle[latest], bollingerUpper = bb.upper[latest], bollingerLower = bb.lower[latest],
            macd = macd.macdLine[latest], macdSignal = macd.signalLine[latest], macdHistogram = macd.histogram[latest],
            atr14 = atr[latest], volumeRatio20 = volumeRatio,
            recentCloses = closes.takeLast(recentCount.coerceAtLeast(1)),
            candleCount = rows.size, snapshotHash = snapshotHash
        )
        return ValidationResult(snapshot, emptyList())
    }

    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
