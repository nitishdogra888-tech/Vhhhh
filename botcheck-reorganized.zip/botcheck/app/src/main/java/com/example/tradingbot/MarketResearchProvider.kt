package com.example.tradingbot

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Lightweight, optional current-news context. Exact market numbers still come from MarketSnapshot. */
object MarketResearchProvider {
    data class Research(val headlines: List<String>, val sentiment: String, val fetchedAtMs: Long)
    private val client = OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS).readTimeout(5, TimeUnit.SECONDS).build()
    private val positive = setOf("surge","rally","gain","gains","bullish","approval","growth","record","rise","rises","positive","adoption")
    private val negative = setOf("drop","fall","falls","bearish","hack","lawsuit","loss","losses","risk","warning","decline","negative","crash")

    fun fetch(symbol: String): Research {
        return try {
            val query = URLEncoder.encode("$symbol crypto", "UTF-8")
            val url = "https://news.google.com/rss/search?q=$query&hl=en-US&gl=US&ceid=US:en"
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return Research(emptyList(), "unavailable", System.currentTimeMillis())
                val xml = response.body?.string().orEmpty()
                val titles = Regex("<item>[\\s\\S]*?<title>(?:<!\\[CDATA\\[)?(.*?)(?:\\]\\]>)?</title>", RegexOption.IGNORE_CASE)
                    .findAll(xml).map { it.groupValues[1].replace("&amp;", "&").trim() }.filter { it.isNotBlank() }.take(8).toList()
                val score = titles.sumOf { title ->
                    val words = title.lowercase().split(Regex("[^a-z]+"))
                    words.count { it in positive } - words.count { it in negative }
                }
                val sentiment = when { score >= 2 -> "positive"; score <= -2 -> "negative"; else -> "mixed/neutral" }
                Research(titles, sentiment, System.currentTimeMillis())
            }
        } catch (_: Exception) { Research(emptyList(), "unavailable", System.currentTimeMillis()) }
    }
}
