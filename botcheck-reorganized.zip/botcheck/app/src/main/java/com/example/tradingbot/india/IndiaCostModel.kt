package com.example.tradingbot.india

import kotlin.math.max
import kotlin.math.min

/**
 * INTRADAY = MIS, square off same day. Taxed as speculative business income
 * at slab rate (not a flat rate) -- ASSUMED_SPECULATIVE_TAX_RATE below is a
 * planning assumption, not the trader's actual slab.
 *
 * DELIVERY = CNC, held overnight or longer. STT is charged on both legs
 * (intraday only charges it on the sell leg) and the model assumes a
 * short-term holding (<12 months), taxed at the flat STCG rate. If a
 * position is actually held 12+ months it becomes LTCG (12.5% above a
 * yearly ₹1.25L exemption) instead -- this model does not attempt to track
 * holding period against that threshold.
 */
enum class ProductType { INTRADAY, DELIVERY }

/**
 * NSE cash-market cost model for the India equity flow -- the direct
 * counterpart to [com.example.tradingbot.CostModel] on the crypto side, but
 * built from Indian equity charges instead of Binance fees + crypto TDS.
 * Charges below reflect Angel One's published rate card; ALL numbers are
 * planning estimates for the bot's own risk/trailing math, not tax advice,
 * and not a substitute for the actual contract note on any real trade.
 *
 * What's structurally different from crypto's CostModel, and why each one
 * exists:
 *  - Brokerage is lower-of-flat-or-percentage with a floor (₹20 / 0.1% /
 *    min ₹5 per executed order), not a flat percentage like Binance's
 *    0.1%/side -- so unlike crypto, break-even % is NOT independent of
 *    trade size. breakEvenMoveFraction() here takes a trade value in ₹.
 *  - STT differs by product: both legs for DELIVERY, sell-leg-only for
 *    INTRADAY (crypto's 1% TDS-on-sell has no equity equivalent at all --
 *    equity trades are not subject to that VDA-specific TDS).
 *  - Exchange transaction charge, SEBI turnover fee, stamp duty (buy leg
 *    only) and 18% GST on (brokerage + exchange charge + SEBI fee) are all
 *    India-specific line items with no crypto counterpart.
 *  - DP (depository participant) charges apply only when DELIVERY shares
 *    already sitting in demat are sold -- there is nothing analogous for
 *    INTRADAY (never enters demat) or for crypto (no depository at all).
 *  - Tax treatment is genuinely bifurcated: INTRADAY gains are speculative
 *    business income at the trader's slab rate; DELIVERY gains (assuming
 *    <12 months) are flat 20% STCG. Crypto instead used one flat 30% rate
 *    for everything, which does not apply to equities.
 */
object IndiaCostModel {

    // --- Brokerage (Angel One rate card): lower of flat ₹20 or 0.1% per executed order, min ₹5. ---
    const val BROKERAGE_FLAT_CAP_RS = 20.0
    const val BROKERAGE_RATE = 0.001
    const val BROKERAGE_MIN_RS = 5.0

    // --- Securities Transaction Tax ---
    const val STT_DELIVERY_RATE = 0.001    // 0.1%, charged on BOTH buy and sell legs
    const val STT_INTRADAY_RATE = 0.00025  // 0.025%, charged on the SELL leg only

    // --- NSE exchange transaction charge, both legs, both product types ---
    const val EXCHANGE_TXN_RATE = 0.0030699 / 100.0 // 0.0030699%

    // --- SEBI turnover fee: ₹10 per crore, both legs ---
    const val SEBI_TURNOVER_RATE = 0.0000001 * 10.0 // = 0.000001 (₹10 / ₹1,00,00,000)

    // --- Stamp duty: buy leg only, both product types ---
    const val STAMP_DUTY_RATE = 0.00015 // 0.015%

    // --- GST on (brokerage + exchange charge + SEBI fee) ---
    const val GST_RATE = 0.18

    // --- DP (depository participant) charge: flat per scrip per sell-day, DELIVERY sells only ---
    const val DP_CHARGE_BASE_RS = 20.0
    const val DP_CHARGE_WITH_GST_RS = DP_CHARGE_BASE_RS * (1.0 + GST_RATE) // ~23.6

    // --- Tax planning assumptions (NOT advice -- confirm against the trader's own slab/ITR situation) ---
    /** DELIVERY, assumed holding <12 months: flat STCG rate on net gains. */
    const val STCG_RATE_ASSUMED = 0.20
    /** INTRADAY: speculative business income at slab rate. Default assumes the highest slab as a conservative planning figure. */
    const val SPECULATIVE_TAX_RATE_DEFAULT = 0.30

    fun brokerage(orderValueRs: Double): Double {
        if (orderValueRs <= 0.0) return 0.0
        val percentAmount = orderValueRs * BROKERAGE_RATE
        return max(BROKERAGE_MIN_RS, min(BROKERAGE_FLAT_CAP_RS, percentAmount))
    }

    fun exchangeCharge(orderValueRs: Double): Double = orderValueRs * EXCHANGE_TXN_RATE
    fun sebiCharge(orderValueRs: Double): Double = orderValueRs * SEBI_TURNOVER_RATE
    fun stampDuty(buyValueRs: Double): Double = buyValueRs * STAMP_DUTY_RATE

    fun stt(buyValueRs: Double, sellValueRs: Double, productType: ProductType): Double = when (productType) {
        ProductType.DELIVERY -> buyValueRs * STT_DELIVERY_RATE + sellValueRs * STT_DELIVERY_RATE
        ProductType.INTRADAY -> sellValueRs * STT_INTRADAY_RATE
    }

    /**
     * Full round-trip cost for one BUY-then-SELL trade. `quantity` is whole
     * shares (equities don't fill in fractions the way crypto does).
     */
    fun tradeCost(
        entryPrice: Double,
        exitPrice: Double,
        quantity: Int,
        productType: ProductType,
        speculativeTaxRate: Double = SPECULATIVE_TAX_RATE_DEFAULT
    ): IndiaTradeCost {
        val qty = quantity.toDouble()
        val buyValue = entryPrice * qty
        val sellValue = exitPrice * qty
        val grossPnl = sellValue - buyValue

        val buyBrokerage = brokerage(buyValue)
        val sellBrokerage = brokerage(sellValue)
        val totalBrokerage = buyBrokerage + sellBrokerage

        val totalExchangeCharge = exchangeCharge(buyValue) + exchangeCharge(sellValue)
        val totalSebiCharge = sebiCharge(buyValue) + sebiCharge(sellValue)
        val stampDutyAmount = stampDuty(buyValue)
        val sttAmount = stt(buyValue, sellValue, productType)
        val gstAmount = (totalBrokerage + totalExchangeCharge + totalSebiCharge) * GST_RATE
        val dpCharge = if (productType == ProductType.DELIVERY) DP_CHARGE_WITH_GST_RS else 0.0

        val totalCharges = totalBrokerage + totalExchangeCharge + totalSebiCharge + stampDutyAmount + sttAmount + gstAmount + dpCharge
        val netBeforeTax = grossPnl - totalCharges

        val taxRate = if (productType == ProductType.DELIVERY) STCG_RATE_ASSUMED else speculativeTaxRate
        val taxEstimate = if (netBeforeTax > 0.0) netBeforeTax * taxRate else 0.0
        val netPnl = netBeforeTax - taxEstimate

        return IndiaTradeCost(
            grossPnl = grossPnl,
            brokerage = totalBrokerage,
            sttTax = sttAmount,
            exchangeCharges = totalExchangeCharge,
            sebiCharges = totalSebiCharge,
            stampDuty = stampDutyAmount,
            gst = gstAmount,
            dpCharges = dpCharge,
            taxEstimate = taxEstimate,
            netPnl = netPnl
        )
    }

    /**
     * Favorable price move (as a fraction of entry) needed for net P/L >= 0
     * after every charge above, for a trade of roughly `tradeValueRs` ₹
     * notional. Unlike crypto's version, this is NOT trade-size-independent
     * -- the ₹20 brokerage cap and ₹5 floor mean the break-even % shrinks as
     * trade size grows past the point brokerage stops scaling with it.
     * Pass the actual planned order value in, not an arbitrary placeholder.
     */
    fun breakEvenMoveFraction(
        tradeValueRs: Double,
        productType: ProductType,
        speculativeTaxRate: Double = SPECULATIVE_TAX_RATE_DEFAULT
    ): Double {
        if (tradeValueRs <= 0.0) return 0.0
        val assumedPrice = 100.0
        val quantity = max(1, (tradeValueRs / assumedPrice).toInt())
        var lo = 0.0
        var hi = 0.25
        repeat(48) {
            val mid = (lo + hi) / 2.0
            val exitPrice = assumedPrice * (1.0 + mid)
            val cost = tradeCost(assumedPrice, exitPrice, quantity, productType, speculativeTaxRate)
            if (cost.netPnl >= 0.0) hi = mid else lo = mid
        }
        return hi
    }

    /** Pure estimate for a "sell now" preview; never mutates trade statistics. */
    fun previewSellNow(
        entryPrice: Double,
        currentPrice: Double,
        quantity: Int,
        productType: ProductType,
        speculativeTaxRate: Double = SPECULATIVE_TAX_RATE_DEFAULT
    ): IndiaTradeCost = tradeCost(entryPrice, currentPrice, quantity, productType, speculativeTaxRate)
}

data class IndiaTradeCost(
    val grossPnl: Double,
    val brokerage: Double,
    val sttTax: Double,
    val exchangeCharges: Double,
    val sebiCharges: Double,
    val stampDuty: Double,
    val gst: Double,
    val dpCharges: Double,
    val taxEstimate: Double,
    val netPnl: Double
) {
    val totalCharges: Double
        get() = brokerage + sttTax + exchangeCharges + sebiCharges + stampDuty + gst + dpCharges + taxEstimate
}
