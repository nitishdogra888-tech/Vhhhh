package com.example.tradingbot

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Optional Grok commentary using the *user's* xAI API key.
 * Never places orders. Never uses a bundled/shared key.
 */
object GrokAdvisor {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    data class MarketSnapshot(
        val price: Double,
        val signal: String,
        val reason: String,
        val positionOpen: Boolean,
        val entry: Double,
        val qty: Double,
        val dailyPnlPercent: Double,
        val remainingBudget: Double,
        val tradingLocked: Boolean
    )

    fun advise(apiKey: String, snap: MarketSnapshot): String {
        val key = apiKey.trim()
        if (key.isBlank()) {
            return "Optional: paste your own xAI API key on the start screen (console.x.ai). " +
                "A shared Grok key cannot be shipped inside this app — it would leak. " +
                "Grok never places trades; rules + risk locks still win."
        }

        val user = buildString {
            appendLine("Market snapshot (advisory only):")
            appendLine("price=${snap.price}")
            appendLine("bot_signal=${snap.signal}")
            appendLine("bot_reason=${snap.reason}")
            appendLine("position_open=${snap.positionOpen} entry=${snap.entry} qty=${snap.qty}")
            appendLine("daily_pnl_percent=${snap.dailyPnlPercent}")
            appendLine("remaining_budget_usd=${snap.remainingBudget}")
            appendLine("trading_locked=${snap.tradingLocked}")
            appendLine()
            appendLine("Give 4-7 short bullets: what the bot's own rules are saying, what could go wrong, and what NOT to change. Do not invent fills or guarantee profit.")
        }

        val body = JSONObject().apply {
            put("model", "grok-4.5")
            put("max_tokens", 420)
            put("temperature", 0.2)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content",
                        "You are a cautious trading-system co-pilot for a Binance TESTNET bot. " +
                            "You do not place, cancel, or size orders. Hard locks, daily loss, " +
                            "zero-fill refusal, and stop/trail rules override you. Not financial advice."
                    )
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", user)
                })
            })
        }

        val request = Request.Builder()
            .url("https://api.x.ai/v1/chat/completions")
            .addHeader("Authorization", "Bearer $key")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val err = try {
                    JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
                } catch (_: Exception) { "" }
                throw RuntimeException(
                    if (err.isNotBlank()) err else "xAI error ${response.code}"
                )
            }
            val json = JSONObject(raw)
            return json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .optString("content", "")
                .ifBlank { "Grok returned an empty reply." }
        }
    }
}
