package com.example.tradingbot.scanner

/**
 * Pure functions for computing common technical indicators from a series
 * of closing prices. Each list of doubles is assumed to be ordered oldest
 * to newest. Returned lists are the same length as the input, padded with
 * null where there isn't enough history yet to compute a value.
 */
object TechnicalIndicators {

    fun sma(values: List<Double>, period: Int): List<Double?> {
        if (period <= 0) return values.map { null }
        val result = MutableList<Double?>(values.size) { null }
        var windowSum = 0.0
        for (i in values.indices) {
            windowSum += values[i]
            if (i >= period) windowSum -= values[i - period]
            if (i >= period - 1) result[i] = windowSum / period
        }
        return result
    }

    fun ema(values: List<Double>, period: Int): List<Double?> {
        if (period <= 0 || values.isEmpty()) return values.map { null }
        val result = MutableList<Double?>(values.size) { null }
        val multiplier = 2.0 / (period + 1)

        // Seed the EMA with a simple average of the first `period` values.
        if (values.size < period) return result
        var prevEma = values.take(period).average()
        result[period - 1] = prevEma

        for (i in period until values.size) {
            val currentEma = (values[i] - prevEma) * multiplier + prevEma
            result[i] = currentEma
            prevEma = currentEma
        }
        return result
    }

    /**
     * Standard 14-period RSI (Wilder's smoothing).
     */
    fun rsi(closes: List<Double>, period: Int = 14): List<Double?> {
        val result = MutableList<Double?>(closes.size) { null }
        if (closes.size <= period) return result

        var gainSum = 0.0
        var lossSum = 0.0
        for (i in 1..period) {
            val change = closes[i] - closes[i - 1]
            if (change >= 0) gainSum += change else lossSum -= change
        }
        var avgGain = gainSum / period
        var avgLoss = lossSum / period
        result[period] = rsiFromAverages(avgGain, avgLoss)

        for (i in (period + 1) until closes.size) {
            val change = closes[i] - closes[i - 1]
            val gain = if (change >= 0) change else 0.0
            val loss = if (change < 0) -change else 0.0
            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
            result[i] = rsiFromAverages(avgGain, avgLoss)
        }
        return result
    }

    private fun rsiFromAverages(avgGain: Double, avgLoss: Double): Double {
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    data class MacdResult(
        val macdLine: List<Double?>,
        val signalLine: List<Double?>,
        val histogram: List<Double?>
    )

    /**
     * Standard MACD(12, 26, 9): fast EMA minus slow EMA, plus a signal
     * line that is the EMA of the MACD line itself.
     */
    fun macd(
        closes: List<Double>,
        fastPeriod: Int = 12,
        slowPeriod: Int = 26,
        signalPeriod: Int = 9
    ): MacdResult {
        val fastEma = ema(closes, fastPeriod)
        val slowEma = ema(closes, slowPeriod)

        val macdLine = closes.indices.map { i ->
            val f = fastEma[i]
            val s = slowEma[i]
            if (f != null && s != null) f - s else null
        }

        // EMA of the MACD line, computed only over the non-null portion.
        val firstValid = macdLine.indexOfFirst { value -> value != null }
        val signalLine = MutableList<Double?>(closes.size) { null }
        if (firstValid != -1) {
            val macdValues = macdLine.subList(firstValid, macdLine.size).map { value -> value!! }
            val emaOfMacd = ema(macdValues, signalPeriod)
            for (i in emaOfMacd.indices) {
                signalLine[firstValid + i] = emaOfMacd[i]
            }
        }

        val histogram = closes.indices.map { i ->
            val m = macdLine[i]
            val s = signalLine[i]
            if (m != null && s != null) m - s else null
        }

        return MacdResult(macdLine, signalLine, histogram)
    }

    data class BollingerResult(
        val middle: List<Double?>,
        val upper: List<Double?>,
        val lower: List<Double?>
    )

    fun bollingerBands(values: List<Double>, period: Int = 20, deviations: Double = 2.0): BollingerResult {
        val middle = sma(values, period)
        val upper = MutableList<Double?>(values.size) { null }
        val lower = MutableList<Double?>(values.size) { null }
        for (i in values.indices) {
            if (i < period - 1) continue
            val start = i - period + 1
            val mean = middle[i] ?: continue
            var sumSq = 0.0
            for (j in start..i) {
                val d = values[j] - mean
                sumSq += d * d
            }
            val sd = kotlin.math.sqrt(sumSq / period)
            upper[i] = mean + deviations * sd
            lower[i] = mean - deviations * sd
        }
        return BollingerResult(middle, upper, lower)
    }

    fun stochRsi(closes: List<Double>, rsiPeriod: Int = 14, stochPeriod: Int = 14): List<Double?> {
        val rsi = rsi(closes, rsiPeriod)
        val result = MutableList<Double?>(closes.size) { null }
        for (i in rsi.indices) {
            if (i < stochPeriod - 1) continue
            val window = rsi.subList(i - stochPeriod + 1, i + 1).mapNotNull { value -> value }
            if (window.size < stochPeriod) continue
            val current = rsi[i] ?: continue
            val lo = window.minOrNull() ?: continue
            val hi = window.maxOrNull() ?: continue
            result[i] = if (hi == lo) 0.5 else ((current - lo) / (hi - lo)).coerceIn(0.0, 1.0)
        }
        return result
    }

    fun atr(highs: List<Double>, lows: List<Double>, closes: List<Double>, period: Int = 14): List<Double?> {
        val result = MutableList<Double?>(closes.size) { null }
        if (highs.size != lows.size || lows.size != closes.size || closes.size <= period) return result
        val tr = MutableList(closes.size) { 0.0 }
        tr[0] = highs[0] - lows[0]
        for (i in 1 until closes.size) {
            tr[i] = maxOf(
                highs[i] - lows[i],
                kotlin.math.abs(highs[i] - closes[i - 1]),
                kotlin.math.abs(lows[i] - closes[i - 1])
            )
        }
        var atr = tr.take(period).average()
        result[period - 1] = atr
        for (i in period until tr.size) {
            atr = ((atr * (period - 1)) + tr[i]) / period
            result[i] = atr
        }
        return result
    }

    fun volumeRatio(volumes: List<Double>, period: Int = 20): Double {
        if (volumes.size < period + 1) return 1.0
        val avg = volumes.takeLast(period + 1).dropLast(1).average()
        return if (avg <= 0.0) 1.0 else volumes.last() / avg
    }

    enum class Crossover { GOLDEN, DEATH, NONE }

    /**
     * Detects a crossover between a fast and slow moving average on the
     * most recent bar only (fast crossing above slow = GOLDEN / bullish,
     * fast crossing below slow = DEATH / bearish).
     */
    fun detectCrossover(fast: List<Double?>, slow: List<Double?>): Crossover {
        val n = fast.size
        if (n < 2) return Crossover.NONE
        val fPrev = fast[n - 2]; val fCurr = fast[n - 1]
        val sPrev = slow[n - 2]; val sCurr = slow[n - 1]
        if (fPrev == null || fCurr == null || sPrev == null || sCurr == null) {
            return Crossover.NONE
        }
        return when {
            fPrev <= sPrev && fCurr > sCurr -> Crossover.GOLDEN
            fPrev >= sPrev && fCurr < sCurr -> Crossover.DEATH
            else -> Crossover.NONE
        }
    }
}
