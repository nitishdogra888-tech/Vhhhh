package com.example.tradingbot.india

/**
 * Same STOP_LOSS/TAKE_PROFIT/TRAILING_STOP/REVERSAL_SIGNAL/MANUAL_CLOSE set
 * as crypto's ExitReason, plus SQUARE_OFF_DEADLINE -- an exit reason that
 * has no crypto equivalent, because Binance never closes. An open INTRADAY
 * position that hits IndiaMarketCalendar's cutoff must exit regardless of
 * where price is relative to its stop/target.
 */
enum class IndiaExitReason { STOP_LOSS, TAKE_PROFIT, TRAILING_STOP, REVERSAL_SIGNAL, MANUAL_CLOSE, SQUARE_OFF_DEADLINE, NONE }

/** Everything needed to resume an open India position across a service restart. */
data class IndiaPositionSnapshot(
    val tradingSymbol: String,
    val entryPrice: Double,
    val quantity: Int,
    val entryTimestampMs: Long,
    val peakProfitPercent: Double,
    val stopLossPercent: Double,
    val takeProfitPercent: Double,
    val trailingActivationPercent: Double,
    val productType: ProductType,
    val manualTrade: Boolean = false
)

/**
 * India counterpart to crypto's PositionTracker. Two real differences beyond
 * the obvious (whole-share Int quantity, ₹ prices):
 *
 *  1. The cost-aware trailing floor is computed from IndiaCostModel using
 *     THIS position's actual ₹ notional, not a fixed constant -- because
 *     unlike Binance's flat 0.1%/side fee, Angel One's brokerage has a flat
 *     cap and floor, so break-even % genuinely depends on trade size (see
 *     IndiaCostModel.breakEvenMoveFraction doc).
 *  2. checkExit() also asks IndiaMarketCalendar whether an INTRADAY
 *     position is past its square-off cutoff, independent of stop-loss/
 *     take-profit/trailing -- crypto's PositionTracker has no such check
 *     because there is no session close to square off against.
 */
class IndiaPositionTracker(
    private val trailingGivebackPercent: Double = 0.003
) {
    var inPosition: Boolean = false
        private set
    var tradingSymbol: String = ""
        private set
    var entryPrice: Double = 0.0
        private set
    var quantity: Int = 0
        private set
    var productType: ProductType = ProductType.INTRADAY
        private set

    private var stopLossPercent: Double = 0.012
    private var takeProfitPercent: Double = 0.025
    private var trailingActivationPercent: Double = 0.026
    private var minNetExitPercent: Double = 0.0
    private var peakProfitPercent: Double = 0.0
    private var entryTimestampMs: Long = 0L
    private var manualTrade: Boolean = false

    fun open(
        tradingSymbol: String,
        price: Double,
        qty: Int,
        productType: ProductType,
        stopLossPercent: Double = 0.012,
        takeProfitPercent: Double = 0.025,
        trailingActivationPercent: Double = 0.026,
        nowMs: Long = System.currentTimeMillis(),
        manualTrade: Boolean = false
    ) {
        this.tradingSymbol = tradingSymbol
        this.entryPrice = price
        this.quantity = qty
        this.productType = productType
        this.stopLossPercent = stopLossPercent.coerceIn(0.001, 0.50)
        this.takeProfitPercent = takeProfitPercent.coerceIn(0.0, 2.0)
        this.trailingActivationPercent = trailingActivationPercent.coerceIn(0.0, 2.0)
        this.minNetExitPercent = IndiaCostModel.breakEvenMoveFraction(price * qty, productType)
        this.manualTrade = manualTrade
        this.inPosition = true
        this.peakProfitPercent = 0.0
        this.entryTimestampMs = nowMs
    }

    fun close() {
        inPosition = false
        tradingSymbol = ""
        entryPrice = 0.0
        quantity = 0
        peakProfitPercent = 0.0
        entryTimestampMs = 0L
        manualTrade = false
    }

    fun reduceQuantity(newQuantity: Int) {
        quantity = newQuantity
        if (quantity <= 0) close()
    }

    fun snapshot(): IndiaPositionSnapshot? =
        if (inPosition) IndiaPositionSnapshot(
            tradingSymbol, entryPrice, quantity, entryTimestampMs, peakProfitPercent,
            stopLossPercent, takeProfitPercent, trailingActivationPercent, productType, manualTrade
        ) else null

    fun restore(snap: IndiaPositionSnapshot) {
        inPosition = true
        tradingSymbol = snap.tradingSymbol
        entryPrice = snap.entryPrice
        quantity = snap.quantity
        entryTimestampMs = snap.entryTimestampMs
        peakProfitPercent = snap.peakProfitPercent
        stopLossPercent = snap.stopLossPercent
        takeProfitPercent = snap.takeProfitPercent
        trailingActivationPercent = snap.trailingActivationPercent
        productType = snap.productType
        manualTrade = snap.manualTrade
        minNetExitPercent = IndiaCostModel.breakEvenMoveFraction(entryPrice * quantity, productType)
    }

    fun holdDurationMs(nowMs: Long = System.currentTimeMillis()): Long =
        if (inPosition) nowMs - entryTimestampMs else 0L

    fun isManualTrade(): Boolean = inPosition && manualTrade

    fun stopLossPriceLevel(): Double =
        if (inPosition && entryPrice > 0) entryPrice * (1 - stopLossPercent) else 0.0

    fun takeProfitPriceLevel(): Double =
        if (inPosition && entryPrice > 0) entryPrice * (1 + takeProfitPercent) else 0.0

    fun trailingArmPriceLevel(): Double =
        if (inPosition && entryPrice > 0) entryPrice * (1 + trailingActivationPercent) else 0.0

    fun checkExit(currentPrice: Double, nowMs: Long = System.currentTimeMillis()): IndiaExitReason {
        if (!inPosition || entryPrice <= 0) return IndiaExitReason.NONE

        // Session-close gate first: a square-off deadline overrides everything else for INTRADAY,
        // even a position that is currently below its stop-loss level (still must flatten).
        if (productType == ProductType.INTRADAY && IndiaMarketCalendar.isPastIntradaySquareOffDeadline(nowMs)) {
            return IndiaExitReason.SQUARE_OFF_DEADLINE
        }

        val currentProfitPercent = (currentPrice - entryPrice) / entryPrice
        if (currentProfitPercent > peakProfitPercent) peakProfitPercent = currentProfitPercent

        val givebackFromPeak = peakProfitPercent - currentProfitPercent
        val trailingActive = peakProfitPercent >= trailingActivationPercent
        val aboveModeledBreakEven = currentProfitPercent >= minNetExitPercent

        return when {
            currentProfitPercent <= -stopLossPercent -> IndiaExitReason.STOP_LOSS
            takeProfitPercent > 0.0 && currentProfitPercent >= takeProfitPercent -> IndiaExitReason.TAKE_PROFIT
            trailingActive && givebackFromPeak >= trailingGivebackPercent && aboveModeledBreakEven ->
                IndiaExitReason.TRAILING_STOP
            else -> IndiaExitReason.NONE
        }
    }

    fun statusReason(currentPrice: Double, nowMs: Long = System.currentTimeMillis()): String {
        if (!inPosition || entryPrice <= 0) return "No open position."
        val currentProfitPercent = (currentPrice - entryPrice) / entryPrice * 100.0
        val peak = peakProfitPercent * 100.0
        val stopAt = -stopLossPercent * 100.0
        val bePct = minNetExitPercent * 100.0

        val squareOffNote = if (productType == ProductType.INTRADAY) {
            val cutoff = IndiaMarketCalendar.INTRADAY_SQUARE_OFF_CUTOFF
            " MIS position -- will be force-closed by $cutoff IST regardless of stop/target."
        } else ""

        return if (peakProfitPercent >= trailingActivationPercent) {
            val trailStopLevel = peak - trailingGivebackPercent * 100.0
            val floorNote = if (trailStopLevel / 100.0 < minNetExitPercent)
                " Trail floor is modeled break-even (+${"%.2f".format(bePct)}%) — will not lock a net loss."
            else ""
            "Trailing stop is active: currently ${fmtPct(currentProfitPercent)} vs entry (peak was ${fmtPct(peak)}). " +
                "Will exit if profit falls back to ${"%.2f".format(trailStopLevel)}%.$floorNote$squareOffNote"
        } else {
            "Holding: currently ${fmtPct(currentProfitPercent)} vs entry. Trailing stop arms once profit reaches " +
                "+${"%.2f".format(trailingActivationPercent * 100)}%; hard stop-loss exits at ${"%.2f".format(stopAt)}%.$squareOffNote"
        }
    }

    fun exitReasonText(reason: IndiaExitReason, currentPrice: Double): String {
        if (entryPrice <= 0) return ""
        val currentProfitPercent = (currentPrice - entryPrice) / entryPrice * 100.0
        val peak = peakProfitPercent * 100.0
        return when (reason) {
            IndiaExitReason.STOP_LOSS -> "Hard stop-loss triggered: down ${fmtPct(currentProfitPercent)} vs entry, at or " +
                "beyond the ${"%.2f".format(-stopLossPercent * 100)}% limit. Closing to cap the loss."
            IndiaExitReason.TRAILING_STOP -> "Trailing stop triggered: profit pulled back from a peak of ${fmtPct(peak)} to " +
                "${fmtPct(currentProfitPercent)}, giving back ${"%.2f".format(trailingGivebackPercent * 100)} points " +
                "from the peak (still at/above modeled break-even). Locking in the gain before it erodes further."
            IndiaExitReason.REVERSAL_SIGNAL -> "Strategy signal reversed after the minimum hold time elapsed — " +
                "closing at ${fmtPct(currentProfitPercent)} vs entry rather than holding against the new signal."
            IndiaExitReason.TAKE_PROFIT -> if (manualTrade) "Manual take-profit target reached at ${fmtPct(currentProfitPercent)} vs entry. Auto-exit is enabled, so the trade is closing now." else "Take-profit target reached at ${fmtPct(currentProfitPercent)} vs entry. Closing automatically."
            IndiaExitReason.MANUAL_CLOSE -> "Position closed manually at ${fmtPct(currentProfitPercent)} vs entry."
            IndiaExitReason.SQUARE_OFF_DEADLINE -> "NSE session square-off deadline (${IndiaMarketCalendar.INTRADAY_SQUARE_OFF_CUTOFF} IST) reached for this MIS position — " +
                "closing at ${fmtPct(currentProfitPercent)} vs entry regardless of stop/target, same as a broker-side auto square-off would."
            IndiaExitReason.NONE -> ""
        }
    }

    private fun fmtPct(v: Double): String = (if (v >= 0) "+" else "") + "%.2f".format(v) + "%"
}
