package com.example.tradingbot.scanner

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.tradingbot.SecureStorage
import com.example.tradingbot.databinding.ActivityScannerBinding
import kotlinx.coroutines.launch

/**
 * Enter a comma-separated watchlist, tap Scan, see ranked BUY/SELL/WATCH
 * results. Uses Alpaca market data if keys have been saved via
 * SecureStorage (same encrypted-at-rest pattern as the Binance keys on
 * the main screen); otherwise falls back to Yahoo Finance, which needs
 * no key at all so the screen works the moment you open it.
 */
class ScannerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScannerBinding
    private lateinit var adapter: ScanResultAdapter
    private lateinit var secureStorage: SecureStorage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScannerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        secureStorage = SecureStorage(this)

        adapter = ScanResultAdapter()
        binding.resultsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.resultsRecyclerView.adapter = adapter

        binding.watchlistInput.setText("AAPL,MSFT,TSLA,NVDA,AMZN")

        // Never pre-fill the secret field, same reasoning as any password
        // field — the key ID alone is fine to show back for confirmation.
        binding.alpacaKeyIdInput.setText(secureStorage.getAlpacaKeyId())
        updateDataSourceStatus()

        binding.saveAlpacaKeysButton.setOnClickListener { saveAlpacaKeys() }
        binding.clearAlpacaKeysButton.setOnClickListener { clearAlpacaKeys() }
        binding.scanButton.setOnClickListener { runScan() }

        // Run once automatically on open with the default watchlist.
        runScan()
    }

    private fun saveAlpacaKeys() {
        val keyId = binding.alpacaKeyIdInput.text.toString().trim()
        val secret = binding.alpacaSecretInput.text.toString().trim()

        if (keyId.isEmpty() || secret.isEmpty()) {
            binding.dataSourceStatusText.text = "Enter both fields to save Alpaca keys"
            return
        }

        secureStorage.saveAlpacaCredentials(keyId, secret)
        binding.alpacaSecretInput.setText("") // don't linger in the input once saved
        updateDataSourceStatus()
    }

    private fun clearAlpacaKeys() {
        AlertDialog.Builder(this)
            .setTitle("Clear saved Alpaca keys?")
            .setMessage("The scanner will fall back to Yahoo Finance (no key needed).")
            .setPositiveButton("Clear") { _, _ ->
                secureStorage.clearAlpacaCredentials()
                binding.alpacaKeyIdInput.setText("")
                binding.alpacaSecretInput.setText("")
                updateDataSourceStatus()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateDataSourceStatus() {
        binding.dataSourceStatusText.text = if (secureStorage.hasAlpacaCredentials()) {
            "Using Alpaca (saved keys found)"
        } else {
            "Using Yahoo Finance (no Alpaca keys saved)"
        }
    }

    private fun buildProvider(): StockDataProvider {
        return if (secureStorage.hasAlpacaCredentials()) {
            AlpacaDataProvider(
                keyId = secureStorage.getAlpacaKeyId(),
                secretKey = secureStorage.getAlpacaSecretKey()
            )
        } else {
            YahooFinanceProvider()
        }
    }

    private fun runScan() {
        val symbols = binding.watchlistInput.text.toString()
            .split(",")
            .map { symbol -> symbol.trim().uppercase() }
            .filter { symbol -> symbol.isNotEmpty() }

        if (symbols.isEmpty()) {
            binding.statusText.text = "Enter at least one symbol"
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.statusText.text = "Scanning ${symbols.size} symbols…"
        binding.scanButton.isEnabled = false

        val scanner = MarketScanner(buildProvider())

        lifecycleScope.launch {
            try {
                val results = scanner.scan(symbols)
                adapter.submitList(results)
                binding.statusText.text = if (results.isEmpty()) {
                    "No results — try different symbols or check your connection"
                } else {
                    "${results.size} of ${symbols.size} symbols scanned"
                }
            } catch (e: Exception) {
                binding.statusText.text = "Scan failed: ${e.message}"
            } finally {
                binding.progressBar.visibility = View.GONE
                binding.scanButton.isEnabled = true
            }
        }
    }
}
