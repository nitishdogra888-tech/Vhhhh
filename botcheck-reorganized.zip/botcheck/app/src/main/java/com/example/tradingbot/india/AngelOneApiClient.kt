package com.example.tradingbot.india

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.experimental.and

/**
 * Angel One SmartAPI client.
 *
 * IMPORTANT: unlike BinanceApiClient, there is no testnet mode here. Every
 * call this class makes goes to Angel One's live trading API and, once an
 * order-placement call is wired up and invoked, moves real money in a real
 * NSE account. AppPreferences.canTrade() and the dashboard's Live-mode gate
 * exist to stop the crypto/bStocks flows from reaching this client
 * accidentally, but there's no equivalent "safe by default" here the way
 * BTCUSDT-on-testnet is -- treat every method below as live from the start.
 *
 * Auth flow (SmartAPI): clientCode + password/PIN + a 6-digit TOTP code
 * (from the authenticator secret Angel One gives you when you enable API
 * access) exchange for a JWT + refresh token pair, refreshed daily. This is
 * fundamentally different from Binance's static HMAC key/secret, so none of
 * BinanceApiClient's signing logic applies.
 *
 * STATUS: scaffolding only. The HTTP calls below match Angel One's
 * documented SmartAPI request/response shapes, but this has not been
 * exercised against a live account -- verify field names and response
 * parsing against your own account before relying on it, and start with
 * getLtp/getCandleData (read-only) before ever calling placeOrder.
 */
class AngelOneApiClient(
    private val apiKey: String,
    private val clientCode: String,
    private val password: String,
    private val totpSecret: String
) {
    private val baseUrl = "https://apiconnect.angelbroking.com"

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private var jwtToken: String? = null
    private var refreshToken: String? = null
    private var feedToken: String? = null

    /** RFC 6238 TOTP, matching whatever authenticator app Angel One's setup page told you to use. */
    private fun currentTotp(): String {
        val secretBytes = base32Decode(totpSecret)
        val timeStep = System.currentTimeMillis() / 1000 / 30
        val timeBytes = ByteArray(8)
        var value = timeStep
        for (i in 7 downTo 0) {
            timeBytes[i] = (value and 0xFF).toByte()
            value = value shr 8
        }
        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(secretBytes, "HmacSHA1"))
        val hash = mac.doFinal(timeBytes)
        val offset = (hash[hash.size - 1] and 0x0F).toInt()
        val binary = ((hash[offset].toInt() and 0x7F) shl 24) or
            ((hash[offset + 1].toInt() and 0xFF) shl 16) or
            ((hash[offset + 2].toInt() and 0xFF) shl 8) or
            (hash[offset + 3].toInt() and 0xFF)
        val otp = binary % 1_000_000
        return otp.toString().padStart(6, '0')
    }

    private fun base32Decode(input: String): ByteArray {
        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
        val clean = input.trim().uppercase().replace("=", "")
        var bits = 0
        var value = 0
        val output = ArrayList<Byte>()
        for (c in clean) {
            val idx = alphabet.indexOf(c)
            if (idx < 0) continue
            value = (value shl 5) or idx
            bits += 5
            if (bits >= 8) {
                bits -= 8
                output.add(((value shr bits) and 0xFF).toByte())
            }
        }
        return output.toByteArray()
    }

    private fun commonHeaders(builder: Request.Builder, clientLocalIp: String, clientPublicIp: String, macAddress: String) {
        builder.addHeader("Content-Type", "application/json")
        builder.addHeader("Accept", "application/json")
        builder.addHeader("X-UserType", "USER")
        builder.addHeader("X-SourceID", "WEB")
        builder.addHeader("X-ClientLocalIP", clientLocalIp)
        builder.addHeader("X-ClientPublicIP", clientPublicIp)
        builder.addHeader("X-MACAddress", macAddress)
        builder.addHeader("X-PrivateKey", apiKey)
        jwtToken?.let { builder.addHeader("Authorization", "Bearer $it") }
    }

    /**
     * Logs in and stores the JWT/refresh/feed tokens for subsequent calls.
     * Per SEBI's 2026 rules, brokers expect this session to be bound to a
     * whitelisted static IP -- clientLocalIp/clientPublicIp below need to
     * match whatever static IP you registered with Angel One, which in
     * practice means this client runs from a small always-on server, not
     * directly from the phone.
     */
    fun login(clientLocalIp: String, clientPublicIp: String, macAddress: String): Boolean {
        val body = JSONObject().apply {
            put("clientcode", clientCode)
            put("password", password)
            put("totp", currentTotp())
        }
        val request = Request.Builder()
            .url("$baseUrl/rest/auth/angelbroking/user/v1/loginByPassword")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
        commonHeaders(request, clientLocalIp, clientPublicIp, macAddress)
        client.newCall(request.build()).execute().use { response ->
            val responseBody = response.body?.string() ?: "{}"
            if (!response.isSuccessful) throw RuntimeException("Angel One login failed (${response.code}): $responseBody")
            val json = JSONObject(responseBody)
            if (!json.optBoolean("status", false)) throw RuntimeException("Angel One login rejected: ${json.optString("message")}")
            val data = json.getJSONObject("data")
            jwtToken = data.optString("jwtToken")
            refreshToken = data.optString("refreshToken")
            feedToken = data.optString("feedToken")
            return jwtToken?.isNotBlank() == true
        }
    }

    /** Last traded price for one instrument. Read-only -- safe to call before you trust order placement. */
    fun getLtp(exchange: String, tradingSymbol: String, token: String, clientLocalIp: String, clientPublicIp: String, macAddress: String): Double {
        val body = JSONObject().apply {
            put("exchange", exchange)
            put("tradingsymbol", tradingSymbol)
            put("symboltoken", token)
        }
        val request = Request.Builder()
            .url("$baseUrl/rest/secure/angelbroking/order/v1/getLtpData")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
        commonHeaders(request, clientLocalIp, clientPublicIp, macAddress)
        client.newCall(request.build()).execute().use { response ->
            val responseBody = response.body?.string() ?: "{}"
            if (!response.isSuccessful) throw RuntimeException("getLtpData failed (${response.code}): $responseBody")
            val json = JSONObject(responseBody)
            return json.getJSONObject("data").optDouble("ltp", 0.0)
        }
    }

    /** Historical candles. interval e.g. "ONE_MINUTE", "FIVE_MINUTE", "ONE_DAY". */
    fun getCandleData(exchange: String, token: String, interval: String, fromDateTime: String, toDateTime: String, clientLocalIp: String, clientPublicIp: String, macAddress: String): JSONArray {
        val body = JSONObject().apply {
            put("exchange", exchange)
            put("symboltoken", token)
            put("interval", interval)
            put("fromdate", fromDateTime)
            put("todate", toDateTime)
        }
        val request = Request.Builder()
            .url("$baseUrl/rest/secure/angelbroking/historical/v1/getCandleData")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
        commonHeaders(request, clientLocalIp, clientPublicIp, macAddress)
        client.newCall(request.build()).execute().use { response ->
            val responseBody = response.body?.string() ?: "{}"
            if (!response.isSuccessful) throw RuntimeException("getCandleData failed (${response.code}): $responseBody")
            val json = JSONObject(responseBody)
            return json.optJSONArray("data") ?: JSONArray()
        }
    }

    /**
     * Places a REAL order with REAL money. Deliberately not wired into any
     * UI yet -- call this only once you've verified login/getLtp work
     * against your own account, and only with SEBI's order-rate limits and
     * algo-registration rules (see the 2026 framework) in mind.
     */
    fun placeOrder(
        exchange: String,
        tradingSymbol: String,
        token: String,
        transactionType: String, // "BUY" or "SELL"
        quantity: Int,
        orderType: String = "MARKET", // or "LIMIT"
        productType: String = "INTRADAY",
        price: Double = 0.0,
        clientLocalIp: String,
        clientPublicIp: String,
        macAddress: String
    ): String {
        val body = JSONObject().apply {
            put("variety", "NORMAL")
            put("tradingsymbol", tradingSymbol)
            put("symboltoken", token)
            put("transactiontype", transactionType)
            put("exchange", exchange)
            put("ordertype", orderType)
            put("producttype", productType)
            put("duration", "DAY")
            put("price", if (orderType == "MARKET") "0" else price.toString())
            put("quantity", quantity.toString())
        }
        val request = Request.Builder()
            .url("$baseUrl/rest/secure/angelbroking/order/v1/placeOrder")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
        commonHeaders(request, clientLocalIp, clientPublicIp, macAddress)
        client.newCall(request.build()).execute().use { response ->
            val responseBody = response.body?.string() ?: "{}"
            if (!response.isSuccessful) throw RuntimeException("placeOrder failed (${response.code}): $responseBody")
            val json = JSONObject(responseBody)
            if (!json.optBoolean("status", false)) throw RuntimeException("Order rejected: ${json.optString("message")}")
            return json.getJSONObject("data").optString("orderid")
        }
    }
}
