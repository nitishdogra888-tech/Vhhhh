package com.example.tradingbot.india

/** Daily risk fields that must survive process death. Keyed to the IST calendar day, not device-local. */
data class IndiaDailyRiskSnapshot(
    val tradingDay: String,
    val dayStartEquity: Double,
    val remainingBudgetInr: Double,
    val dailyStopLocked: Boolean,
    val consecutiveLosses: Int,
    val tradesToday: Int,
    val lastExitMs: Long
)

/**
 * India counterpart to crypto's RiskManager. Same shape (daily ₹ budget,
 * daily-loss lock, consecutive-loss pause, max trades/day, cooldown) plus
 * two things that have no crypto equivalent:
 *
 *  1. Position sizing returns whole shares (Int, floor-divided), not a
 *     fractional quantity -- NSE doesn't fill fractional shares.
 *  2. newEntryBlockReason() also checks IndiaMarketCalendar: no new entries
 *     when NSE is shut (nights/weekends -- crypto's RiskManager never needed
 *     this, Binance never closes), and no new INTRADAY entries past the
 *     square-off entry cutoff since there wouldn't be enough of the session
 *     left to hold a fresh MIS position responsibly.
 *
 * The "day" boundary itself is also different on purpose: crypto's daily
 * reset can use whatever calendar day the device reports, but NSE's trading
 * day is defined in IST, so this always keys off IndiaMarketCalendar.tradingDayKey()
 * regardless of device timezone.
 */
class IndiaRiskManager(
    private val dailyTradingBudgetInr: Double = 1000.0,
    private val maxDailyLossPercent: Double = 0.03,
    private val maxConsecutiveLosses: Int = 3,
    private val maxTradesPerDay: Int = 8
) {
    private var dayStartEquity: Double? = null
    private var currentEquity: Double = 0.0
    private var currentFreeCash: Double = 0.0
    private var remainingBudgetInr: Double = dailyTradingBudgetInr
    private var dailyStopLocked: Boolean = false
    private var consecutiveLosses: Int = 0
    private var tradesToday: Int = 0
    var lastExitMs: Long = 0L
        private set

    fun updateBalance(equity: Double, freeCash: Double) {
        if (dayStartEquity == null) {
            dayStartEquity = equity
            remainingBudgetInr = dailyTradingBudgetInr.coerceAtMost(equity)
        }
        currentEquity = equity
        currentFreeCash = freeCash
        if (dailyLossLimitBreached()) dailyStopLocked = true
    }

    fun recordTradeResult(netPnl: Double, nowMs: Long = System.currentTimeMillis()) {
        remainingBudgetInr = (remainingBudgetInr + netPnl)
            .coerceAtLeast(0.0)
            .coerceAtMost(dailyTradingBudgetInr)
        tradesToday++
        lastExitMs = nowMs
        if (netPnl < 0) consecutiveLosses++ else consecutiveLosses = 0
        if (dailyLossLimitBreached()) dailyStopLocked = true
    }

    fun remainingBudget(): Double = remainingBudgetInr
    fun isDailyStopLocked(): Boolean = dailyStopLocked
    fun consecutiveLosses(): Int = consecutiveLosses
    fun tradesToday(): Int = tradesToday
    fun maxTradesPerDayLimit(): Int = maxTradesPerDay
    fun maxConsecutiveLossesLimit(): Int = maxConsecutiveLosses

    /** Whole shares only -- NSE has no fractional fills. Floors, never rounds up past the budget. */
    fun tradeQuantity(price: Double): Int {
        if (price <= 0.0) return 0
        val tradeValue = remainingBudgetInr.coerceAtMost(currentFreeCash)
        return (tradeValue / price).toInt().coerceAtLeast(0)
    }

    fun dailyLossLimitBreached(): Boolean {
        val start = dayStartEquity ?: return dailyStopLocked
        if (start <= 0) return dailyStopLocked
        val lossPercent = (start - currentEquity) / start
        return dailyStopLocked || lossPercent >= maxDailyLossPercent
    }

    /**
     * Null if entries are allowed; otherwise a dashboard/log reason.
     * Checks IndiaMarketCalendar first since a closed market makes every
     * other check moot, then falls through to the same budget/loss/
     * cooldown gates crypto's RiskManager uses.
     */
    fun newEntryBlockReason(nowMs: Long, entryCooldownMs: Long, productType: ProductType): String? {
        IndiaMarketCalendar.marketClosedReason(nowMs)?.let { return it }
        if (productType == ProductType.INTRADAY && IndiaMarketCalendar.isPastIntradayEntryCutoff(nowMs)) {
            return "Too close to the ${IndiaMarketCalendar.INTRADAY_SQUARE_OFF_CUTOFF} IST square-off cutoff to open a new MIS position today."
        }
        if (dailyStopLocked || dailyLossLimitBreached()) {
            return "Daily loss lock is active — new entries blocked until tomorrow's IST reset."
        }
        if (consecutiveLosses >= maxConsecutiveLosses) {
            return "Paused after $consecutiveLosses consecutive losses (limit $maxConsecutiveLosses)."
        }
        if (tradesToday >= maxTradesPerDay) {
            return "Max trades for today reached ($tradesToday/$maxTradesPerDay)."
        }
        if (lastExitMs > 0L && nowMs - lastExitMs < entryCooldownMs) {
            val waitSec = (entryCooldownMs - (nowMs - lastExitMs)) / 1000
            return "Entry cooldown after last exit (${waitSec}s remaining)."
        }
        return null
    }

    fun resetDay(equity: Double, freeCash: Double) {
        dayStartEquity = equity
        currentEquity = equity
        currentFreeCash = freeCash
        remainingBudgetInr = dailyTradingBudgetInr.coerceAtMost(equity)
        dailyStopLocked = false
        consecutiveLosses = 0
        tradesToday = 0
        lastExitMs = 0L
    }

    fun snapshot(tradingDay: String): IndiaDailyRiskSnapshot = IndiaDailyRiskSnapshot(
        tradingDay = tradingDay,
        dayStartEquity = dayStartEquity ?: currentEquity,
        remainingBudgetInr = remainingBudgetInr,
        dailyStopLocked = dailyStopLocked,
        consecutiveLosses = consecutiveLosses,
        tradesToday = tradesToday,
        lastExitMs = lastExitMs
    )

    /** `today` should come from IndiaMarketCalendar.tradingDayKey(), not a device-local date. */
    fun restore(snap: IndiaDailyRiskSnapshot, today: String, equity: Double, freeCash: Double) {
        if (snap.tradingDay == today) {
            dayStartEquity = snap.dayStartEquity
            remainingBudgetInr = snap.remainingBudgetInr
            dailyStopLocked = snap.dailyStopLocked
            consecutiveLosses = snap.consecutiveLosses
            tradesToday = snap.tradesToday
            lastExitMs = snap.lastExitMs
            currentEquity = equity
            currentFreeCash = freeCash
        } else {
            resetDay(equity, freeCash)
        }
    }
}
