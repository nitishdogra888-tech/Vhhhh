package com.example.tradingbot

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Vision-based AI trade advisor. Sends a screenshot of the BTC chart plus
 * the bot's own numeric readout to a multimodal model and asks for a
 * structured verdict (signal/probability/reasoning/levels). Like
 * GrokAdvisor, this NEVER places, sizes, or cancels an order -- it only
 * produces an advisory verdict that DashboardActivity may notify on. The
 * bot's own rules and hard risk locks always override it.
 *
 * Supports OpenAI, xAI (Grok), and Anthropic (Claude) vision models, plus
 * an optional self-hosted/OpenAI-compatible custom endpoint, so the user
 * can bring whichever key they already have. evaluateWithFallback() tries
 * each configured provider in order and only returns a neutral HOLD
 * verdict if every configured provider failed (or none were configured).
 */
object AiSignalAdvisor {

    // Single place to bump these as providers rename/retire models.
    private const val OPENAI_MODEL = "gpt-5-mini"
    private const val XAI_MODEL = "grok-4.5"
    private const val ANTHROPIC_MODEL = "claude-sonnet-5"
    private const val ANTHROPIC_VERSION = "2023-06-01"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    enum class Signal { BUY, SELL, HOLD }

    data class FullSnapshot(
        val price: Double,
        val botSignal: String,
        val botReason: String,
        val bullishScore: Int,
        val bearishScore: Int,
        val ruleQuality: Int,
        val rsi: Double,
        val emaFast: Double,
        val emaSlow: Double,
        val atrPercent: Double,
        val trendStrength: Double,
        val positionOpen: Boolean,
        val entry: Double,
        val qty: Double,
        val dailyPnlPercent: Double,
        val remainingBudgetUsd: Double,
        val tradingLocked: Boolean,
        val totalTrades: Int,
        val winRatePercent: Double,
        val consecutiveLosses: Int,
        val recentClosedPrices: List<Double>,
        val indicatorsAvailable: Boolean = true
    )

    data class Verdict(
        val signal: Signal,
        val probability: Double,
        val reasoning: String,
        val nextHourOutlook: String,
        val riskLevel: String,
        val keySupport: Double,
        val keyResistance: Double,
        val suggestedStopLossPrice: Double,
        val suggestedTakeProfitPrice: Double,
        val riskRewardRatio: Double,
        val suggestedBuyUsd: Double,
        val estimatedProfitUsd: Double,
        val estimatedProfitPercent: Double,
        val horizon: String = "1h"
    )

    data class Result(
        val verdict: Verdict,
        val provider: String,
        val warnings: List<String> = emptyList()
    )

    private val NEUTRAL_VERDICT = Verdict(
        signal = Signal.HOLD,
        probability = 0.0,
        reasoning = "No AI provider configured or reachable — staying neutral.",
        nextHourOutlook = "",
        riskLevel = "UNKNOWN",
        keySupport = 0.0,
        keyResistance = 0.0,
        suggestedStopLossPrice = 0.0,
        suggestedTakeProfitPrice = 0.0,
        riskRewardRatio = 0.0,
        suggestedBuyUsd = 0.0,
        estimatedProfitUsd = 0.0,
        estimatedProfitPercent = 0.0,
        horizon = ""
    )

    /**
     * Single-provider path (OpenAI only) used by the automated capture
     * cycle, which already gate-checks for a saved OpenAI key before
     * calling this. Throws on any failure so the caller's existing
     * try/catch -> AiCaptureStore.failCapture() path handles it.
     */
    fun evaluateWithImage(apiKey: String, snap: FullSnapshot, imageBase64: String): Verdict {
        return callOpenAi(apiKey, snap, imageBase64)
    }

    /**
     * Tries every configured provider in order (OpenAI -> xAI -> Anthropic
     * -> custom endpoint) and returns the first success. Collects a
     * human-readable warning for each provider that was tried and failed,
     * and falls back to a neutral HOLD verdict (never throws) if every
     * configured provider failed or none were configured at all -- callers
     * on this path (manual upload, automated-event) show the result either
     * way rather than treating "no key saved" as a hard error.
     */
    fun evaluateWithFallback(
        openAiKey: String,
        xaiKey: String,
        anthropicKey: String,
        customVisionEndpoint: String,
        snapshot: FullSnapshot,
        imageBase64: String
    ): Result {
        val warnings = mutableListOf<String>()

        if (openAiKey.isNotBlank()) {
            try {
                return Result(callOpenAi(openAiKey, snapshot, imageBase64), "OpenAI ($OPENAI_MODEL)", warnings)
            } catch (e: Exception) {
                warnings.add("OpenAI failed: ${e.message ?: "unknown error"}")
            }
        }

        if (xaiKey.isNotBlank()) {
            try {
                return Result(callXai(xaiKey, snapshot, imageBase64), "xAI ($XAI_MODEL)", warnings)
            } catch (e: Exception) {
                warnings.add("xAI failed: ${e.message ?: "unknown error"}")
            }
        }

        if (anthropicKey.isNotBlank()) {
            try {
                return Result(callAnthropic(anthropicKey, snapshot, imageBase64), "Anthropic ($ANTHROPIC_MODEL)", warnings)
            } catch (e: Exception) {
                warnings.add("Anthropic failed: ${e.message ?: "unknown error"}")
            }
        }

        if (customVisionEndpoint.isNotBlank()) {
            try {
                return Result(callCustomEndpoint(customVisionEndpoint, snapshot, imageBase64), "Custom endpoint", warnings)
            } catch (e: Exception) {
                warnings.add("Custom endpoint failed: ${e.message ?: "unknown error"}")
            }
        }

        if (warnings.isEmpty()) {
            warnings.add("No AI provider key saved — add one on the AI tab to enable vision analysis.")
        }
        return Result(NEUTRAL_VERDICT, "None", warnings)
    }

    // ---- shared prompt building ----

    private fun systemPrompt(): String =
        "You are a cautious trading-chart vision analyst for a Binance Spot trading bot. " +
            "You are shown a candlestick chart screenshot plus the bot's own indicator readout. " +
            "You do not place, cancel, or size orders -- you only produce an advisory verdict; " +
            "the bot's own rules and hard risk locks always override you. Not financial advice. " +
            "Respond with ONLY a single minified JSON object (no markdown, no commentary) with " +
            "exactly these keys: signal (\"BUY\"|\"SELL\"|\"HOLD\"), probability (0-100 number), " +
            "reasoning (short string, 1-2 sentences), next_hour_outlook (short string), " +
            "risk_level (\"LOW\"|\"MEDIUM\"|\"HIGH\"), key_support (number), key_resistance (number), " +
            "suggested_stop_loss_price (number), suggested_take_profit_price (number), " +
            "risk_reward_ratio (number), suggested_buy_usd (number, 0 if not BUY), " +
            "estimated_profit_usd (number, 0 if not BUY), estimated_profit_percent (number, 0 if not BUY), " +
            "horizon (short string like \"1h\")."

    private fun userPrompt(snap: FullSnapshot): String = buildString {
        appendLine("Market snapshot (advisory only, chart image attached):")
        appendLine("price=${snap.price}")
        appendLine("bot_signal=${snap.botSignal} bot_reason=${snap.botReason}")
        appendLine("indicators_available=${snap.indicatorsAvailable}")
        if (snap.indicatorsAvailable) {
            appendLine("bullish_score=${snap.bullishScore} bearish_score=${snap.bearishScore} rule_quality=${snap.ruleQuality}")
            appendLine("rsi=${snap.rsi} ema_fast=${snap.emaFast} ema_slow=${snap.emaSlow} atr_percent=${snap.atrPercent} trend_strength=${snap.trendStrength}")
        }
        appendLine("position_open=${snap.positionOpen} entry=${snap.entry} qty=${snap.qty}")
        appendLine("daily_pnl_percent=${snap.dailyPnlPercent} remaining_budget_usd=${snap.remainingBudgetUsd} trading_locked=${snap.tradingLocked}")
        appendLine("total_trades=${snap.totalTrades} win_rate_percent=${snap.winRatePercent} consecutive_losses=${snap.consecutiveLosses}")
        if (snap.recentClosedPrices.isNotEmpty()) {
            appendLine("recent_closes=${snap.recentClosedPrices.joinToString(",") { "%.2f".format(it) }}")
        }
        appendLine()
        appendLine("Study the chart image and the numbers above together. Return the JSON verdict described in the system prompt only.")
    }

    private fun parseVerdict(rawContent: String): Verdict {
        val cleaned = rawContent.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val obj = JSONObject(cleaned)
        val signal = when (obj.optString("signal", "HOLD").uppercase()) {
            "BUY" -> Signal.BUY
            "SELL" -> Signal.SELL
            else -> Signal.HOLD
        }
        return Verdict(
            signal = signal,
            probability = obj.optDouble("probability", 0.0).coerceIn(0.0, 100.0),
            reasoning = obj.optString("reasoning", "").take(500),
            nextHourOutlook = obj.optString("next_hour_outlook", "").take(300),
            riskLevel = obj.optString("risk_level", "MEDIUM"),
            keySupport = obj.optDouble("key_support", 0.0),
            keyResistance = obj.optDouble("key_resistance", 0.0),
            suggestedStopLossPrice = obj.optDouble("suggested_stop_loss_price", 0.0),
            suggestedTakeProfitPrice = obj.optDouble("suggested_take_profit_price", 0.0),
            riskRewardRatio = obj.optDouble("risk_reward_ratio", 0.0),
            suggestedBuyUsd = obj.optDouble("suggested_buy_usd", 0.0),
            estimatedProfitUsd = obj.optDouble("estimated_profit_usd", 0.0),
            estimatedProfitPercent = obj.optDouble("estimated_profit_percent", 0.0),
            horizon = obj.optString("horizon", "1h")
        )
    }

    // ---- provider calls ----
    // All three hosted providers speak a "system/user + image" chat shape;
    // only the envelope (auth header, endpoint, exact JSON shape) differs.

    private fun callOpenAi(apiKey: String, snap: FullSnapshot, imageBase64: String): Verdict {
        val body = JSONObject().apply {
            put("model", OPENAI_MODEL)
            put("max_tokens", 600)
            put("temperature", 0.2)
            put("response_format", JSONObject().put("type", "json_object"))
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", systemPrompt()))
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", JSONArray().apply {
                        put(JSONObject().put("type", "text").put("text", userPrompt(snap)))
                        put(
                            JSONObject().put("type", "image_url")
                                .put("image_url", JSONObject().put("url", "data:image/png;base64,$imageBase64"))
                        )
                    })
                })
            })
        }
        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer ${apiKey.trim()}")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val err = try { JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty() } catch (_: Exception) { "" }
                throw RuntimeException(err.ifBlank { "OpenAI error ${response.code}" })
            }
            val content = JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
            return parseVerdict(content)
        }
    }

    private fun callXai(apiKey: String, snap: FullSnapshot, imageBase64: String): Verdict {
        val body = JSONObject().apply {
            put("model", XAI_MODEL)
            put("max_tokens", 600)
            put("temperature", 0.2)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", systemPrompt()))
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", JSONArray().apply {
                        put(JSONObject().put("type", "text").put("text", userPrompt(snap)))
                        put(
                            JSONObject().put("type", "image_url")
                                .put("image_url", JSONObject().put("url", "data:image/png;base64,$imageBase64"))
                        )
                    })
                })
            })
        }
        val request = Request.Builder()
            .url("https://api.x.ai/v1/chat/completions")
            .addHeader("Authorization", "Bearer ${apiKey.trim()}")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val err = try { JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty() } catch (_: Exception) { "" }
                throw RuntimeException(err.ifBlank { "xAI error ${response.code}" })
            }
            val content = JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
            return parseVerdict(content)
        }
    }

    private fun callAnthropic(apiKey: String, snap: FullSnapshot, imageBase64: String): Verdict {
        val body = JSONObject().apply {
            put("model", ANTHROPIC_MODEL)
            put("max_tokens", 600)
            put("system", systemPrompt())
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", JSONArray().apply {
                        put(JSONObject().put("type", "text").put("text", userPrompt(snap)))
                        put(
                            JSONObject().put("type", "image").put(
                                "source",
                                JSONObject().put("type", "base64").put("media_type", "image/png").put("data", imageBase64)
                            )
                        )
                    })
                })
            })
        }
        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey.trim())
            .addHeader("anthropic-version", ANTHROPIC_VERSION)
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val err = try { JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty() } catch (_: Exception) { "" }
                throw RuntimeException(err.ifBlank { "Anthropic error ${response.code}" })
            }
            val content = JSONObject(raw).getJSONArray("content").getJSONObject(0).optString("text", "")
            return parseVerdict(content)
        }
    }

    /**
     * A self-hosted or third-party endpoint that speaks the same
     * OpenAI-compatible chat-completions + image_url shape (e.g. an
     * OpenRouter or local vLLM/Ollama vision deployment). The saved value
     * is treated as the full request URL; no API key header is sent unless
     * the URL already embeds one, since self-hosted endpoints vary widely
     * in auth scheme -- keep that in mind before pointing this at anything
     * that expects a bearer token.
     */
    private fun callCustomEndpoint(endpoint: String, snap: FullSnapshot, imageBase64: String): Verdict {
        val body = JSONObject().apply {
            put("model", "vision-default")
            put("max_tokens", 600)
            put("temperature", 0.2)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", systemPrompt()))
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", JSONArray().apply {
                        put(JSONObject().put("type", "text").put("text", userPrompt(snap)))
                        put(
                            JSONObject().put("type", "image_url")
                                .put("image_url", JSONObject().put("url", "data:image/png;base64,$imageBase64"))
                        )
                    })
                })
            })
        }
        val request = Request.Builder()
            .url(endpoint.trim())
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw RuntimeException("Custom endpoint error ${response.code}")
            val content = JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
            return parseVerdict(content)
        }
    }
}
