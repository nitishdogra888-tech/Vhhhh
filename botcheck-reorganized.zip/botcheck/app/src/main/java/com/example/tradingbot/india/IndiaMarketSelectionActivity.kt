package com.example.tradingbot.india

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tradingbot.R

/**
 * NSE market picker. Shows a curated Nifty shortlist by default; typing in
 * the search box filters that shortlist client-side.
 *
 * TODO (needs a live Angel One account to build against): replace the
 * client-side filter over IndianMarkets.NIFTY_SHORTLIST with a real search
 * against Angel One's downloadable instrument master
 * (https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json)
 * so the full ~2,000-stock NSE universe (plus BSE/F&O/MCX if you want them)
 * is reachable, not just these ten. That file is large (tens of MB), so it
 * should be downloaded once and cached on device / behind your relay
 * server, not fetched on every keystroke.
 */
class IndiaMarketSelectionActivity : AppCompatActivity() {

    private lateinit var stockList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_india_market_selection)

        stockList = findViewById(R.id.stockList)
        val searchInput = findViewById<EditText>(R.id.stockSearchInput)

        renderList(IndianMarkets.NIFTY_SHORTLIST)

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.trim()?.uppercase() ?: ""
                val filtered = if (query.isEmpty()) {
                    IndianMarkets.NIFTY_SHORTLIST
                } else {
                    IndianMarkets.NIFTY_SHORTLIST.filter {
                        it.tradingSymbol.uppercase().contains(query) || it.displayName.uppercase().contains(query)
                    }
                }
                renderList(filtered)
            }
        })
    }

    private fun renderList(stocks: List<IndianStock>) {
        stockList.removeAllViews()
        val inflater = LayoutInflater.from(this)
        for (stock in stocks) {
            val row = inflater.inflate(R.layout.item_market_row, stockList, false)

            val badge = row.findViewById<TextView>(R.id.marketIconBadge)
            badge.text = stock.tradingSymbol.take(1)
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.parseColor(stock.accentColor))
            badge.background = bg

            row.findViewById<TextView>(R.id.marketBaseAsset).text = stock.tradingSymbol.removeSuffix("-EQ")
            row.findViewById<TextView>(R.id.marketDisplayName).text = stock.displayName

            val note = row.findViewById<TextView>(R.id.marketNote)
            note.visibility = android.view.View.GONE

            row.setOnClickListener {
                // Trading Angel One-backed stocks needs live credentials wired
                // into DashboardActivity/TradingService first -- see
                // AngelOneApiClient's class doc for what's still stubbed.
                Toast.makeText(
                    this,
                    "${stock.displayName}: add your Angel One API key/TOTP secret in Settings to trade this live.",
                    Toast.LENGTH_LONG
                ).show()
            }
            stockList.addView(row)
        }

        if (stocks.isEmpty()) {
            val empty = TextView(this)
            empty.text = "No match in the shortlist yet. Full NSE search needs the instrument-master integration (see class doc)."
            empty.setTextColor(getColor(R.color.text_tertiary))
            empty.setPadding(0, 24, 0, 0)
            stockList.addView(empty)
        }
    }
}
