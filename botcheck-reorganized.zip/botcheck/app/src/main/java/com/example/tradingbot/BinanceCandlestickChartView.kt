package com.example.tradingbot

import com.example.tradingbot.scanner.TechnicalIndicators
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Lightweight Binance-style candlestick chart. It intentionally uses Binance market data,
 * while keeping rendering local and dependency-free so the app stays small and fast.
 */
data class ChartCandle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val closed: Boolean = true
)

class BinanceCandlestickChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(40, 43, 50); strokeWidth = 1f }
    private val wick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2f }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(150, 155, 165); textSize = 24f }
    private val cross = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 170, 175, 185); strokeWidth = 1f }
    private val emaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(112, 170, 255); style = Paint.Style.STROKE; strokeWidth = 3f }

    private val candles = ArrayList<ChartCandle>(512)
    private var indicatorStripText: String? = null
    private var showVolume = true
    private var showEma = true
    private var levelEntry: Double? = null
    private var levelStop: Double? = null
    private var levelTake: Double? = null
    private var levelTrail: Double? = null
    private val levelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2.5f; style = Paint.Style.STROKE; pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f) }
    private val levelLabelBg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val levelLabelText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 20f }
    private var offset = 0f
    private var candleWidth = 13f
    private var downX = 0f
    private var lastOffset = 0f
    private var crossX = -1f
    private var crossY = -1f
    private var crossIndex = -1
    private var scaleDetector: ScaleGestureDetector

    init {
        setBackgroundColor(Color.rgb(16, 18, 23))
        scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                candleWidth = (candleWidth * detector.scaleFactor).coerceIn(5f, 38f)
                clampOffset()
                invalidate()
                return true
            }
        })
    }

    fun setCandles(data: List<ChartCandle>) {
        candles.clear()
        data.filter { candle -> candle.open > 0 && candle.high > 0 && candle.low > 0 && candle.close > 0 }
            .takeLast(500)
            .forEach { candle -> candles.add(candle) }
        if (crossIndex >= candles.size) crossIndex = -1
        rebuildIndicatorStripCache()
        clampOffset()
        invalidate()
    }

    fun updateLast(candle: ChartCandle) {
        if (candle.open <= 0 || candle.high <= 0 || candle.low <= 0 || candle.close <= 0) return
        val idx = candles.indexOfFirst { existing -> existing.openTime == candle.openTime }
        if (idx >= 0) {
            if (candles[idx] == candle) return
            candles[idx] = candle
        } else {
            candles.add(candle)
            if (candles.size > 500) candles.removeAt(0)
        }
        rebuildIndicatorStripCache()
        clampOffset()
        invalidate()
    }

    fun setShowVolume(show: Boolean) { showVolume = show; invalidate() }
    fun setShowEma(show: Boolean) { showEma = show; invalidate() }

    /**
     * Draws dashed horizontal reference lines for the currently open
     * position (entry/stop/take-profit/trailing-arm). Pass null for any
     * level that doesn't apply (e.g. no open position, or trailing not
     * armed yet) to hide just that line.
     */
    fun setLevels(entry: Double?, stop: Double?, take: Double?, trail: Double?) {
        levelEntry = entry
        levelStop = stop
        levelTake = take
        levelTrail = trail
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                lastOffset = offset
                crossX = event.x
                crossY = event.y
                crossIndex = nearestIndex(event.x)
                parent.requestDisallowInterceptTouchEvent(true)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!scaleDetector.isInProgress && event.pointerCount == 1) {
                    offset = lastOffset + (event.x - downX)
                    clampOffset()
                    crossX = event.x
                    crossY = event.y
                    crossIndex = nearestIndex(event.x)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent.requestDisallowInterceptTouchEvent(false)
                invalidate()
            }
        }
        return true
    }

    private val crossLabelBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(190, 16, 18, 23) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (candles.size < 2) {
            canvas.drawText("Loading Binance BTC/USDT candles…", 24f, height / 2f, text)
            return
        }

        val volumeHeight = if (showVolume) height * 0.22f else 0f
        val chartTop = 8f
        val chartBottom = height - volumeHeight - 10f
        val left = 54f
        val right = width - 16f
        val countVisible = max(1, ((right - left) / candleWidth).toInt())
        val end = (candles.size - 1 - (-offset / candleWidth).toInt()).coerceIn(1, candles.size - 1)
        val start = (end - countVisible - 2).coerceAtLeast(0)
        val visible = candles.subList(start, end + 1)
        val minPrice = visible.minOf { candle -> candle.low }
        val maxPrice = visible.maxOf { candle -> candle.high }
        val range = max(maxPrice - minPrice, maxPrice * 0.000001)

        for (i in 1..4) {
            val y = chartTop + (chartBottom - chartTop) * i / 5f
            canvas.drawLine(left, y, right, y, grid)
            val p = maxPrice - range * i / 5.0
            canvas.drawText(formatPrice(p), 4f, y - 4f, text)
        }
        for (i in 0..6) {
            val x = left + (right - left) * i / 6f
            canvas.drawLine(x, chartTop, x, chartBottom, grid)
        }

        visible.forEachIndexed { local, c ->
            val idx = start + local
            val x = left + (local + 0.5f) * candleWidth + offset % candleWidth
            if (x < left - candleWidth || x > right + candleWidth) return@forEachIndexed
            val yOpen = y(c.open, minPrice, range, chartTop, chartBottom)
            val yClose = y(c.close, minPrice, range, chartTop, chartBottom)
            val yHigh = y(c.high, minPrice, range, chartTop, chartBottom)
            val yLow = y(c.low, minPrice, range, chartTop, chartBottom)
            val up = c.close >= c.open
            val color = if (up) Color.rgb(37, 196, 137) else Color.rgb(240, 92, 92)
            wick.color = color
            body.color = color
            canvas.drawLine(x, yHigh, x, yLow, wick)
            val half = max(1.5f, candleWidth * 0.34f)
            canvas.drawRect(x - half, min(yOpen, yClose), x + half, max(yOpen, yClose).coerceAtLeast(min(yOpen, yClose) + 1f), body)

            if (showVolume) {
                val vTop = chartBottom + 6f
                val vBottom = height - 8f
                val maxVol = visible.maxOf { candle -> candle.volume }.coerceAtLeast(1e-12)
                val vh = (c.volume / maxVol).toFloat() * (vBottom - vTop)
                body.alpha = 90
                canvas.drawRect(x - half, vBottom - vh, x + half, vBottom, body)
                body.alpha = 255
            }
        }

        if (showEma) drawEma(canvas, visible, start, left, chartTop, chartBottom, minPrice, range)
        drawIndicatorStrip(canvas, visible)
        drawLevel(canvas, levelEntry, Color.rgb(150, 155, 165), "ENTRY", left, right, minPrice, range, chartTop, chartBottom)
        drawLevel(canvas, levelStop, Color.rgb(240, 92, 92), "STOP", left, right, minPrice, range, chartTop, chartBottom)
        drawLevel(canvas, levelTake, Color.rgb(37, 196, 137), "TAKE", left, right, minPrice, range, chartTop, chartBottom)
        drawLevel(canvas, levelTrail, Color.rgb(112, 170, 255), "TRAIL", left, right, minPrice, range, chartTop, chartBottom)

        if (crossIndex >= 0 && crossIndex < candles.size) {
            val c = candles[crossIndex]
            val local = crossIndex - start
            val x = left + (local + 0.5f) * candleWidth + offset % candleWidth
            if (x in left..right) {
                crossX = x
                canvas.drawLine(x, chartTop, x, height - 1f, cross)
                if (crossY in chartTop..chartBottom) canvas.drawLine(left, crossY, right, crossY, cross)
                val info = "${formatPrice(c.close)}  O ${formatPrice(c.open)}  H ${formatPrice(c.high)}  L ${formatPrice(c.low)}"
                canvas.drawRect(left, chartTop, min(right, left + text.measureText(info) + 18f), chartTop + 32f, crossLabelBg)
                canvas.drawText(info, left + 8f, chartTop + 23f, text)
                canvas.drawText(formatTime(c.openTime), max(left, x - 45f), height - 8f, text)
            }
        }
    }


    private fun drawLevel(
        canvas: Canvas,
        price: Double?,
        color: Int,
        label: String,
        left: Float,
        right: Float,
        minPrice: Double,
        range: Double,
        top: Float,
        bottom: Float
    ) {
        if (price == null || price <= 0) return
        val py = y(price, minPrice, range, top, bottom)
        if (py < top - 20f || py > bottom + 20f) return
        levelPaint.color = color
        canvas.drawLine(left, py, right, py, levelPaint)
        val labelStr = "$label ${formatPrice(price)}"
        levelLabelBg.color = color
        levelLabelBg.alpha = 210
        val labelWidth = levelLabelText.measureText(labelStr) + 14f
        canvas.drawRect(right - labelWidth, py - 15f, right, py + 15f, levelLabelBg)
        canvas.drawText(labelStr, right - labelWidth + 7f, py + 7f, levelLabelText)
    }

    private fun rebuildIndicatorStripCache() {
        if (candles.size < 50) {
            indicatorStripText = null
            return
        }
        val closes = candles.map { candle -> candle.close }
        val highs = candles.map { candle -> candle.high }
        val lows = candles.map { candle -> candle.low }
        val volumes = candles.map { candle -> candle.volume }
        val ema20 = TechnicalIndicators.ema(closes, 20).lastOrNull() ?: return
        val ema50 = TechnicalIndicators.ema(closes, 50).lastOrNull() ?: return
        val rsi = TechnicalIndicators.rsi(closes, 14).lastOrNull() ?: return
        val macd = TechnicalIndicators.macd(closes).histogram.lastOrNull() ?: return
        val stoch = TechnicalIndicators.stochRsi(closes).lastOrNull() ?: return
        val bb = TechnicalIndicators.bollingerBands(closes, 20, 2.0)
        val bbU = bb.upper.lastOrNull() ?: return
        val bbL = bb.lower.lastOrNull() ?: return
        val bbPos = if (bbU > bbL) ((closes.last() - bbL) / (bbU - bbL) * 100.0) else 50.0
        val atr = TechnicalIndicators.atr(highs, lows, closes, 14).lastOrNull() ?: return
        val atrPct = if (closes.last() > 0) atr / closes.last() * 100.0 else 0.0
        val vr = TechnicalIndicators.volumeRatio(volumes, 20)
        indicatorStripText = "EMA20 ${fmt(ema20)}  EMA50 ${fmt(ema50)}  RSI ${"%.1f".format(rsi)}  MACD ${"%.3f".format(macd)}  Stoch ${"%.2f".format(stoch)}  BB ${"%.0f".format(bbPos)}%  Vol ${"%.1f".format(vr)}x  ATR ${"%.2f".format(atrPct)}%"
    }

    private fun drawIndicatorStrip(canvas: Canvas, visible: List<ChartCandle>) {
        val info = indicatorStripText ?: return
        canvas.drawRect(54f, 8f, width - 16f, 34f, crossLabelBg)
        text.textSize = 19f
        text.color = Color.rgb(180, 186, 197)
        canvas.drawText(info, 62f, 27f, text)
        text.textSize = 24f
    }

    private fun fmt(v: Double): String = if (v >= 1000) String.format(java.util.Locale.US, "%,.0f", v) else String.format(java.util.Locale.US, "%.4f", v)

    private fun drawEma(canvas: Canvas, visible: List<ChartCandle>, start: Int, left: Float, top: Float, bottom: Float, minPrice: Double, range: Double) {
        if (visible.size < 3) return
        val alpha = 2.0 / (20 + 1)
        var ema = visible.first().close
        val path = Path()
        visible.forEachIndexed { i, c ->
            ema = alpha * c.close + (1 - alpha) * ema
            val x = left + (i + 0.5f) * candleWidth + offset % candleWidth
            val py = y(ema, minPrice, range, top, bottom)
            if (i == 0) path.moveTo(x, py) else path.lineTo(x, py)
        }
        canvas.drawPath(path, emaPaint)
    }

    private fun y(price: Double, minPrice: Double, range: Double, top: Float, bottom: Float): Float = bottom - ((price - minPrice) / range).toFloat() * (bottom - top)

    private fun nearestIndex(x: Float): Int {
        val left = 54f
        val relative = ((x - left - offset % candleWidth) / candleWidth - 0.5f).toInt()
        if (candles.isEmpty()) return -1
        val end = (candles.size - 1 - (-offset / candleWidth).toInt()).coerceIn(0, candles.size - 1)
        return (end - ((width - x) / candleWidth).toInt()).coerceIn(0, candles.size - 1)
    }

    private fun clampOffset() {
        val content = max(0f, (candles.size - 1) * candleWidth - (width - 70f))
        offset = offset.coerceIn(-content, 0f)
    }

    private fun formatPrice(v: Double): String = if (v >= 1000) String.format(java.util.Locale.US, "%,.0f", v) else String.format(java.util.Locale.US, "%.4f", v)
    private fun formatTime(ms: Long): String = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date(ms))
}
