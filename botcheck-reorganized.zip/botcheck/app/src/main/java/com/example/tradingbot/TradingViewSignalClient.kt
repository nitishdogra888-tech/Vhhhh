package com.example.tradingbot

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Pulls the latest TradingView webhook signal from the optional VPS relay. */
object TradingViewSignalClient {
    data class Signal(val symbol: String, val action: String, val price: Double, val timeMs: Long)
    private val client = OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS).readTimeout(5, TimeUnit.SECONDS).build()

    fun latest(baseUrl: String, token: String, symbol: String): Signal? {
        if (baseUrl.isBlank() || token.isBlank()) return null
        val url = baseUrl.trimEnd('/') + "/signal/latest?symbol=" + java.net.URLEncoder.encode(symbol, "UTF-8")
        val req = Request.Builder().url(url).header("X-Webhook-Token", token).get().build()
        client.newCall(req).execute().use { response ->
            if (!response.isSuccessful) return null
            val obj = JSONObject(response.body?.string().orEmpty())
            if (obj.optBoolean("found", false).not()) return null
            return Signal(obj.optString("symbol", symbol), obj.optString("action", "").uppercase(), obj.optDouble("price", 0.0), obj.optLong("timeMs", 0L))
        }
    }
}
