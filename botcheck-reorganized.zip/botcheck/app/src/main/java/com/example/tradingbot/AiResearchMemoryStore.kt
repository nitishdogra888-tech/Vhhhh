package com.example.tradingbot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistent AI memory is context/audit only. It can never change hard risk
 * limits or directly authorize an order.
 */
class AiResearchMemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("ai_research_memory", Context.MODE_PRIVATE)
    private val key = "records"
    fun saveDecision(decision: AiResearchEngine.AiDecision, tradeLinked: Boolean = false) {
        val arr = load()
        arr.put(JSONObject().apply {
            put("analysisId", decision.analysisId); put("symbol", decision.symbol); put("asOfMs", decision.asOfMs)
            put("snapshotHash", decision.snapshotHash); put("model", decision.model); put("signal", decision.signal.name)
            put("confidence", decision.confidence); put("entry", decision.entryPrice); put("stop", decision.stopLoss)
            put("takeProfit", decision.takeProfit); put("reasoning", decision.reasoning); put("bullCase", decision.bullCase)
            put("bearCase", decision.bearCase); put("riskChallenge", decision.riskChallenge); put("status", if (tradeLinked) "OPEN" else "ANALYSIS")
        })
        trimAndSave(arr)
    }
    fun markTradeLinked(analysisId: String) {
        val arr = load()
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("analysisId") == analysisId) { o.put("status", "OPEN"); break }
        }
        trimAndSave(arr)
    }

    fun recordLatestOutcome(symbol: String, netPnl: Double, outcome: String) {
        val arr = load()
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("symbol") == symbol && o.optString("status") == "OPEN") {
                val signal = o.optString("signal", "UNKNOWN")
                val reflection = when {
                    netPnl > 0.0 -> "The $signal thesis produced a positive net outcome (${String.format(java.util.Locale.US, "%.4f", netPnl)}). Preserve the evidence, but do not treat one win as proof of future performance."
                    netPnl < 0.0 -> "The $signal thesis produced a negative net outcome (${String.format(java.util.Locale.US, "%.4f", netPnl)}). Re-check the bull/bear evidence and risk assumptions on similar setups; do not alter hard limits automatically."
                    else -> "The $signal thesis closed near flat. Treat the setup as inconclusive and avoid automatic strategy changes."
                }
                o.put("status", "CLOSED").put("actualOutcome", outcome).put("netPnl", netPnl).put("reflection", reflection).put("outcomeAtMs", System.currentTimeMillis())
                break
            }
        }
        trimAndSave(arr)
    }
    fun recent(symbol: String, limit: Int = 5): JSONArray {
        val all = load(); val out = JSONArray()
        for (i in all.length() - 1 downTo 0) {
            val o = all.optJSONObject(i) ?: continue
            if (o.optString("symbol") == symbol) { out.put(o); if (out.length() >= limit) break }
        }
        return out
    }
    private fun load() = runCatching { JSONArray(prefs.getString(key, "[]")) }.getOrElse { JSONArray() }
    private fun trimAndSave(arr: JSONArray) {
        val out = JSONArray(); val start = maxOf(0, arr.length() - 100)
        for (i in start until arr.length()) out.put(arr.getJSONObject(i))
        prefs.edit().putString(key, out.toString()).apply()
    }
}
