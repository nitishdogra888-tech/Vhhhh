package com.example.tradingbot.india

/**
 * India counterpart to crypto's TradeStats. Crypto only had to tally two
 * cost buckets (exchange fees, TDS) plus a flat tax estimate; India's rate
 * card has enough distinct line items (brokerage, STT, exchange charge,
 * SEBI fee, stamp duty, GST, DP charge) that a trader would actually want
 * to see broken out separately on a history/summary screen, so each gets
 * its own running total here rather than being folded together.
 */
class IndiaTradeStats {
    var totalTrades: Int = 0
        private set
    var wins: Int = 0
        private set
    var losses: Int = 0
        private set
    var totalWinPercent: Double = 0.0
        private set
    var totalLossPercent: Double = 0.0
        private set

    var totalGrossPnl: Double = 0.0
        private set
    var totalBrokerage: Double = 0.0
        private set
    var totalStt: Double = 0.0
        private set
    var totalExchangeCharges: Double = 0.0
        private set
    var totalSebiCharges: Double = 0.0
        private set
    var totalStampDuty: Double = 0.0
        private set
    var totalGst: Double = 0.0
        private set
    var totalDpCharges: Double = 0.0
        private set
    var totalTaxEstimate: Double = 0.0
        private set
    var totalNetPnl: Double = 0.0
        private set

    fun restore(
        totalTrades: Int, wins: Int, losses: Int,
        totalWinPercent: Double, totalLossPercent: Double,
        totalGrossPnl: Double, totalBrokerage: Double, totalStt: Double,
        totalExchangeCharges: Double, totalSebiCharges: Double, totalStampDuty: Double,
        totalGst: Double, totalDpCharges: Double, totalTaxEstimate: Double, totalNetPnl: Double
    ) {
        this.totalTrades = totalTrades
        this.wins = wins
        this.losses = losses
        this.totalWinPercent = totalWinPercent
        this.totalLossPercent = totalLossPercent
        this.totalGrossPnl = totalGrossPnl
        this.totalBrokerage = totalBrokerage
        this.totalStt = totalStt
        this.totalExchangeCharges = totalExchangeCharges
        this.totalSebiCharges = totalSebiCharges
        this.totalStampDuty = totalStampDuty
        this.totalGst = totalGst
        this.totalDpCharges = totalDpCharges
        this.totalTaxEstimate = totalTaxEstimate
        this.totalNetPnl = totalNetPnl
    }

    fun recordTrade(entryPrice: Double, exitPrice: Double, quantity: Int, productType: ProductType): IndiaTradeCost {
        val changePercent = (exitPrice - entryPrice) / entryPrice * 100.0
        totalTrades++
        if (changePercent >= 0) {
            wins++
            totalWinPercent += changePercent
        } else {
            losses++
            totalLossPercent += changePercent
        }

        val cost = IndiaCostModel.tradeCost(entryPrice, exitPrice, quantity, productType)

        totalGrossPnl += cost.grossPnl
        totalBrokerage += cost.brokerage
        totalStt += cost.sttTax
        totalExchangeCharges += cost.exchangeCharges
        totalSebiCharges += cost.sebiCharges
        totalStampDuty += cost.stampDuty
        totalGst += cost.gst
        totalDpCharges += cost.dpCharges
        totalTaxEstimate += cost.taxEstimate
        totalNetPnl += cost.netPnl

        return cost
    }

    fun winRatePercent(): Double =
        if (totalTrades == 0) 0.0 else (wins.toDouble() / totalTrades) * 100.0

    fun averageWinPercent(): Double = if (wins == 0) 0.0 else totalWinPercent / wins
    fun averageLossPercent(): Double = if (losses == 0) 0.0 else totalLossPercent / losses

    /** Sum of every non-tax charge line, i.e. what brokerage + regulatory friction alone cost (excludes the tax estimate). */
    fun totalTradingCharges(): Double =
        totalBrokerage + totalStt + totalExchangeCharges + totalSebiCharges + totalStampDuty + totalGst + totalDpCharges
}
