package com.example.tradingbot

import android.graphics.Bitmap
import java.util.UUID

/**
 * In-memory (not persisted across process death) rolling log of every AI
 * vision capture -- automated-event, manual-upload, or capture-cycle --
 * so the AI tab can show the model's work as it happens (thumbnail +
 * signal + reasoning), not just a one-off notification when it clears the
 * confidence threshold.
 */
object AiCaptureStore {

    enum class Status {
        RUNNING,
        DONE,
        FAILED
    }

    data class Capture(
        val id: String,
        val thumbnail: Bitmap?,
        val price: Double,
        val timestampMs: Long,
        val status: Status,
        val signal: AiSignalAdvisor.Signal? = null,
        val probability: Double = 0.0,
        val reasoning: String = "",
        val nextHourOutlook: String = "",
        val riskLevel: String = "",
        val keySupport: Double = 0.0,
        val keyResistance: Double = 0.0,
        val suggestedStopLossPrice: Double = 0.0,
        val suggestedTakeProfitPrice: Double = 0.0,
        val riskRewardRatio: Double = 0.0,
        val suggestedBuyUsd: Double = 0.0,
        val estimatedProfitUsd: Double = 0.0,
        val estimatedProfitPercent: Double = 0.0,
        val error: String? = null
    )

    private const val MAX_CAPTURES = 40

    private val captures = mutableListOf<Capture>()

    @Synchronized
    fun startCapture(thumbnail: Bitmap?, price: Double): String {
        val id = UUID.randomUUID().toString()

        captures.add(
            index = 0,
            element = Capture(
                id = id,
                thumbnail = thumbnail,
                price = price,
                timestampMs = System.currentTimeMillis(),
                status = Status.RUNNING
            )
        )

        if (captures.size > MAX_CAPTURES) {
            captures.removeAt(captures.lastIndex)
        }

        return id
    }

    @Synchronized
    fun completeCapture(
        id: String,
        verdict: AiSignalAdvisor.Verdict
    ) {
        val index = captures.indexOfFirst { it.id == id }
        if (index == -1) return

        val current = captures[index]

        captures[index] = current.copy(
            status = Status.DONE,
            signal = verdict.signal,
            probability = verdict.probability,
            reasoning = verdict.reasoning,
            nextHourOutlook = verdict.nextHourOutlook,
            riskLevel = verdict.riskLevel,
            keySupport = verdict.keySupport,
            keyResistance = verdict.keyResistance,
            suggestedStopLossPrice = verdict.suggestedStopLossPrice,
            suggestedTakeProfitPrice = verdict.suggestedTakeProfitPrice,
            riskRewardRatio = verdict.riskRewardRatio,
            suggestedBuyUsd = verdict.suggestedBuyUsd,
            estimatedProfitUsd = verdict.estimatedProfitUsd,
            estimatedProfitPercent = verdict.estimatedProfitPercent,
            error = null
        )
    }

    @Synchronized
    fun failCapture(id: String, error: String) {
        val index = captures.indexOfFirst { it.id == id }
        if (index == -1) return

        captures[index] = captures[index].copy(
            status = Status.FAILED,
            error = error
        )
    }

    @Synchronized
    fun all(): List<Capture> {
        return captures.toList()
    }
}
