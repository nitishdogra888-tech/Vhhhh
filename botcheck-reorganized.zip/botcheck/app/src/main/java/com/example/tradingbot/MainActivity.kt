package com.example.tradingbot

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.AdapterView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** Validated values from the "Session risk" card — see MainActivity.readSessionRiskSettings(). */
private data class SessionRiskSettings(
    val sessionBudgetUsd: Double,
    val sessionProfitTargetUsd: Double,
    val sessionMaxLossUsd: Double
)

class MainActivity : AppCompatActivity() {

    private lateinit var secureStorage: SecureStorage

    companion object {
        // Cap kept in-memory log lines so a long-running bot session can't
        // grow this TextView (and the app's memory) without bound.
        private const val MAX_LOG_LINES = 300
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op either way */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        secureStorage = SecureStorage(this)
        requestNotificationPermissionIfNeeded()
        showFirstRunGuideIfNeeded()

        val apiKeyInput = findViewById<EditText>(R.id.apiKeyInput)
        val apiSecretInput = findViewById<EditText>(R.id.apiSecretInput)
        val xaiApiKeyInput = findViewById<EditText>(R.id.xaiApiKeyInput)
        val dailyBudgetInput = findViewById<EditText>(R.id.dailyBudgetInput)
        val stopLossInput = findViewById<EditText>(R.id.stopLossInput)
        val gainTargetInput = findViewById<EditText>(R.id.gainTargetInput)
        val sessionBudgetInput = findViewById<EditText>(R.id.sessionBudgetInput)
        val sessionProfitTargetInput = findViewById<EditText>(R.id.sessionProfitTargetInput)
        val sessionMaxLossInput = findViewById<EditText>(R.id.sessionMaxLossInput)
        val logView = findViewById<TextView>(R.id.logView)
        val logScroll = findViewById<ScrollView>(R.id.logScroll)
        val startButton = findViewById<Button>(R.id.startButton)
        val stopButton = findViewById<Button>(R.id.stopButton)
        val clearKeysButton = findViewById<Button>(R.id.clearKeysButton)
        val strategySpinner = findViewById<Spinner>(R.id.strategySpinner)
        val strategyDescription = findViewById<TextView>(R.id.strategyDescription)

        // Strategy picker: populated from StrategyId (see Strategy.kt). Adding
        // a new built-in strategy there makes it show up here automatically.
        val strategyOptions = StrategyId.entries.toList()
        strategySpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            strategyOptions.map { option -> option.displayName }
        )
        val savedStrategyId = secureStorage.getStrategyId()
        strategySpinner.setSelection(strategyOptions.indexOf(savedStrategyId).coerceAtLeast(0))
        strategyDescription.text = savedStrategyId.description
        strategySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val selected = strategyOptions[position]
                strategyDescription.text = selected.description
                secureStorage.saveStrategyId(selected)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Auto-fill previously saved credentials and trading settings, if any.
        // Percent fields are stored as fractions (0.012) but shown/edited as
        // whole percent (1.2) since that's what a person actually types.
        fun formatPlain(v: Double): String =
            if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()

        apiKeyInput.setText(secureStorage.getApiKey())
        apiSecretInput.setText(secureStorage.getApiSecret())
        xaiApiKeyInput.setText(secureStorage.getXaiApiKey())
        dailyBudgetInput.setText(formatPlain(secureStorage.getDailyBudgetUsd()))
        stopLossInput.setText(formatPlain(secureStorage.getStopLossPercent() * 100.0))
        gainTargetInput.setText(formatPlain(secureStorage.getTrailingActivationPercent() * 100.0))
        sessionBudgetInput.setText(formatPlain(secureStorage.getSessionBudgetUsd()))
        sessionProfitTargetInput.setText(formatPlain(secureStorage.getSessionProfitTargetUsd()))
        sessionMaxLossInput.setText(formatPlain(secureStorage.getSessionMaxLossUsd()))

        fun appendLog(msg: String) {
            val lines = logView.text.split("\n").toMutableList()
            lines.add(msg)
            if (lines.size > MAX_LOG_LINES) {
                // Drop oldest lines rather than let this grow forever.
                val trimmed = lines.takeLast(MAX_LOG_LINES).toMutableList()
                trimmed[0] = "… (older entries trimmed)"
                logView.text = trimmed.joinToString("\n")
            } else {
                logView.text = lines.joinToString("\n")
            }
            // Keep the newest line in view instead of leaving the user
            // scrolled to a stale position as the log grows.
            logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }

        TradingService.onLog = { msg ->
            runOnUiThread { appendLog(msg) }
        }

        // Parses + validates the three trading-settings fields. Returns null
        // (after showing an explanatory dialog) if anything is missing or
        // out of a sane range, so a typo can't silently start the bot with
        // a $0 budget or a 0% stop-loss.
        fun readTradingSettings(): Triple<Double, Double, Double>? {
            val budget = dailyBudgetInput.text.toString().toDoubleOrNull()
            val stopLossPct = stopLossInput.text.toString().toDoubleOrNull()
            val gainPct = gainTargetInput.text.toString().toDoubleOrNull()

            val error = when {
                budget == null || budget <= 0.0 -> "Daily trading budget must be a number greater than 0."
                stopLossPct == null || stopLossPct <= 0.0 || stopLossPct > 50.0 -> "Stop-loss must be a number between 0 and 50 (%)."
                gainPct == null || gainPct <= 0.0 || gainPct > 50.0 -> "Gain target must be a number between 0 and 50 (%)."
                else -> null
            }
            if (error != null) {
                AlertDialog.Builder(this)
                    .setTitle("Check trading settings")
                    .setMessage(error)
                    .setPositiveButton("OK", null)
                    .show()
                return null
            }
            // Safe: all three passed the null/range checks above.
            return Triple(budget!!, stopLossPct!! / 100.0, gainPct!! / 100.0)
        }

        // Parses + validates the three session-risk fields. Returns null (after
        // showing an explanatory dialog) if anything is missing or out of a sane
        // range. The loss cap is allowed to exceed the session budget (a losing
        // streak's drawdown isn't capped by the per-window trade-sizing budget),
        // but everything must still be a positive number.
        fun readSessionRiskSettings(): SessionRiskSettings? {
            val budget = sessionBudgetInput.text.toString().toDoubleOrNull()
            val profitTarget = sessionProfitTargetInput.text.toString().toDoubleOrNull()
            val maxLoss = sessionMaxLossInput.text.toString().toDoubleOrNull()

            val error = when {
                budget == null || budget <= 0.0 -> "Session budget must be a number greater than 0."
                profitTarget == null || profitTarget <= 0.0 -> "Pause-after-profit must be a number greater than 0."
                maxLoss == null || maxLoss <= 0.0 -> "Pause-after-loss must be a number greater than 0."
                else -> null
            }
            if (error != null) {
                AlertDialog.Builder(this)
                    .setTitle("Check session risk settings")
                    .setMessage(error)
                    .setPositiveButton("OK", null)
                    .show()
                return null
            }
            // Safe: all three passed the null/range checks above.
            return SessionRiskSettings(budget!!, profitTarget!!, maxLoss!!)
        }

        fun startBot() {
            val apiKey = apiKeyInput.text.toString().trim()
            val apiSecret = apiSecretInput.text.toString().trim()
            if (apiKey.isEmpty() || apiSecret.isEmpty()) {
                AlertDialog.Builder(this)
                    .setTitle("Binance keys required")
                    .setMessage("Enter your Binance Spot Testnet API Key and Secret before starting the bot.")
                    .setPositiveButton("OK", null)
                    .show()
                return
            }
            val settings = readTradingSettings() ?: return
            val (dailyBudget, stopLossFraction, gainFraction) = settings
            val sessionSettings = readSessionRiskSettings() ?: return

            // Save encrypted so next launch auto-fills these
            secureStorage.saveCredentials(apiKey, apiSecret)
            secureStorage.saveXaiApiKey(xaiApiKeyInput.text.toString())
            secureStorage.saveTradingSettings(
                dailyBudgetUsd = dailyBudget,
                stopLossPercent = stopLossFraction,
                trailingActivationPercent = secureStorage.getTrailingActivationPercent(),
                takeProfitPercent = gainFraction
            )
            secureStorage.saveSessionRiskSettings(
                sessionBudgetUsd = sessionSettings.sessionBudgetUsd,
                sessionProfitTargetUsd = sessionSettings.sessionProfitTargetUsd,
                sessionMaxLossUsd = sessionSettings.sessionMaxLossUsd
            )

            val strategyId = secureStorage.getStrategyId()
            val intent = Intent(this, TradingService::class.java).apply {
                putExtra("apiKey", apiKey)
                putExtra("apiSecret", apiSecret)
                putExtra(TradingService.EXTRA_DAILY_BUDGET_USD, dailyBudget)
                putExtra(TradingService.EXTRA_STOP_LOSS_PERCENT, stopLossFraction)
                putExtra(TradingService.EXTRA_TRAILING_ACTIVATION_PERCENT, secureStorage.getTrailingActivationPercent())
                putExtra(TradingService.EXTRA_TAKE_PROFIT_PERCENT, gainFraction)
                putExtra(TradingService.EXTRA_AUTO_MODE, secureStorage.getAutoMode())
                putExtra(TradingService.EXTRA_AUTO_EXIT, secureStorage.getProtectOpenTrade())
                putExtra(TradingService.EXTRA_STRATEGY_ID, strategyId.name)
                putExtra(TradingService.EXTRA_SESSION_BUDGET_USD, sessionSettings.sessionBudgetUsd)
                putExtra(TradingService.EXTRA_SESSION_PROFIT_TARGET_USD, sessionSettings.sessionProfitTargetUsd)
                putExtra(TradingService.EXTRA_SESSION_MAX_LOSS_USD, sessionSettings.sessionMaxLossUsd)
            }
            startForegroundService(intent)
            appendLog("Starting bot... (strategy: ${strategyId.displayName}, budget \$${"%.2f".format(dailyBudget)}/day, stop-loss ${"%.2f".format(stopLossFraction * 100)}%, gain target ${"%.2f".format(gainFraction * 100)}%, " +
                "session budget \$${"%.2f".format(sessionSettings.sessionBudgetUsd)}/2h, pause at +\$${"%.2f".format(sessionSettings.sessionProfitTargetUsd)}/-\$${"%.2f".format(sessionSettings.sessionMaxLossUsd)})")
        }

        startButton.setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            val settings = readTradingSettings() ?: return@setOnClickListener
            val (dailyBudget, stopLossFraction, gainFraction) = settings
            val sessionSettings = readSessionRiskSettings() ?: return@setOnClickListener
            val chosenStrategy = secureStorage.getStrategyId()
            AlertDialog.Builder(this)
                .setTitle("Start trading bot?")
                .setMessage(
                    "Binance Testnet · Spot markets\n\n" +
                        "• Strategy: ${chosenStrategy.displayName}\n" +
                        "  ${chosenStrategy.description}\n" +
                        "• Stop-loss ${"%.2f".format(stopLossFraction * 100)}% · " +
                        "trail arms at ${"%.2f".format(gainFraction * 100)}% (cost-aware, no exit below break-even)\n" +
                        "• Daily trading budget: \$${"%.2f".format(dailyBudget)} " +
                        "(depletes on losses, persisted across restarts, refills next day)\n" +
                        "• Session risk (2h window): \$${"%.2f".format(sessionSettings.sessionBudgetUsd)} budget, " +
                        "pauses new entries at +\$${"%.2f".format(sessionSettings.sessionProfitTargetUsd)} or " +
                        "-\$${"%.2f".format(sessionSettings.sessionMaxLossUsd)} net for the rest of that window\n" +
                        "• Daily loss cutoff: 3% (locks new entries; survives restart)\n" +
                        "• Max 8 trades/day · pause after 3 consecutive losses · 15 min entry cooldown\n\n" +
                        "This uses fake testnet funds. No real money is at risk."
                )
                .setPositiveButton("Start") { _, _ -> startBot() }
                .setNegativeButton("Cancel", null)
                .show()
        }

        stopButton.setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            stopService(Intent(this, TradingService::class.java))
            appendLog("Bot stopped.")
        }

        findViewById<Button>(R.id.openDashboardButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        findViewById<Button>(R.id.openHelpButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            startActivity(Intent(this, HelpActivity::class.java))
        }

        findViewById<Button>(R.id.openScannerButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            startActivity(Intent(this, com.example.tradingbot.scanner.ScannerActivity::class.java))
        }

        clearKeysButton.setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            AlertDialog.Builder(this)
                .setTitle("Clear saved keys?")
                .setMessage("This removes the saved API key/secret from this device. It does not affect the Binance account itself.")
                .setPositiveButton("Clear") { _, _ ->
                    secureStorage.clearCredentials()
                    apiKeyInput.setText("")
                    apiSecretInput.setText("")
                    xaiApiKeyInput.setText("")
                    appendLog("Saved API keys cleared from device.")
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    /**
     * Notifications (used for the daily-loss-limit alert) require runtime
     * permission on Android 13+. The manifest declares it, but it still has
     * to be requested — otherwise that alert would silently never show up.
     */

    /**
     * A one-time orientation dialog for first-time users. It does not change
     * trading state or settings; it only points beginners to the existing
     * in-app guide and reinforces the Testnet-first workflow.
     */
    private fun showFirstRunGuideIfNeeded() {
        val prefs = getSharedPreferences("ui_preferences", MODE_PRIVATE)
        if (prefs.getBoolean("first_run_seen", false)) return

        AlertDialog.Builder(this)
            .setTitle("Welcome to Trading Bot")
            .setMessage(
                "Start simple:\n\n" +
                    "1. Configure your Testnet connection.\n" +
                    "2. Review the risk settings.\n" +
                    "3. Learn the Dashboard, AI and Controls.\n" +
                    "4. Test before considering any live trading.\n\n" +
                    "AI is advisory and hard safety controls remain authoritative.\n\n" +
                    "You can reopen the full beginner guide from the How to Use button."
            )
            .setNegativeButton("Got it") { _, _ ->
                prefs.edit().putBoolean("first_run_seen", true).apply()
            }
            .setPositiveButton("How to Use") { _, _ ->
                prefs.edit().putBoolean("first_run_seen", true).apply()
                startActivity(Intent(this, HelpActivity::class.java))
            }
            .setOnCancelListener {
                prefs.edit().putBoolean("first_run_seen", true).apply()
            }
            .show()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    override fun onDestroy() {
        // Avoid leaking this Activity's callback into the next Activity
        // instance if the app is recreated (rotation, process restart).
        TradingService.onLog = null
        super.onDestroy()
    }
}
