package com.example.tradingbot.scanner

/**
 * Outcome of scanning a single symbol. `score` is the net count of
 * bullish signals minus bearish signals from RSI, MACD, and MA
 * crossover; `overallSignal` buckets that into something a UI or the
 * existing trading pipeline can act on directly.
 */
data class ScanResult(
    val symbol: String,
    val lastClose: Double,
    val rsi: Double?,
    val macdHistogram: Double?,
    val maCrossover: TechnicalIndicators.Crossover,
    val score: Int,
    val overallSignal: OverallSignal
)

enum class OverallSignal { BUY, SELL, WATCH, NONE }
