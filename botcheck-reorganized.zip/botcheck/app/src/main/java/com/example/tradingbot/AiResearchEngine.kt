package com.example.tradingbot

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Small Kotlin-native adaptation of the useful TradingAgents ideas:
 * deterministic snapshot -> bull/bear challenge -> structured adjudication
 * -> conservative risk challenge. It never talks to Binance and never has
 * authority to place, size, cancel, or bypass an order.
 */
object AiResearchEngine {
    private const val MODEL = "gpt-5-mini"
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .build()

    enum class AiSignal { BUY, SELL, HOLD, REVIEW }

    data class AiDecision(
        val analysisId: String,
        val symbol: String,
        val asOfMs: Long,
        val snapshotHash: String,
        val model: String,
        val signal: AiSignal,
        val confidence: Double,
        val entryPrice: Double?,
        val stopLoss: Double?,
        val takeProfit: Double?,
        val riskReward: Double?,
        val reasoning: String,
        val bullCase: String,
        val bearCase: String,
        val riskChallenge: String,
        val tradingViewAction: String? = null
    )

    data class GateResult(val decision: AiDecision, val warnings: List<String> = emptyList())

    private data class Debate(val bull: String, val bear: String)

    fun evaluate(
        apiKey: String,
        snapshot: MarketSnapshot,
        strategyDecision: StrategyDecision,
        tradingViewAction: String? = null,
        checkpoint: AiAnalysisCheckpointStore,
        memory: AiResearchMemoryStore? = null
    ): GateResult {
        if (apiKey.isBlank()) return GateResult(review(snapshot, "OpenAI key is not configured."))
        val analysisId = "analysis-${snapshot.symbol}-${snapshot.candleCloseTimeMs}-${snapshot.snapshotHash.take(12)}"
        if (snapshot.candleCloseTimeMs > snapshot.asOfMs) {
            return GateResult(review(snapshot, "Snapshot contains a candle after the analysis cutoff."))
        }

        val warnings = mutableListOf<String>()
        val research = MarketResearchProvider.fetch(snapshot.symbol)
        val memoryText = memory?.recent(snapshot.symbol, 5)?.let { arr ->
            (0 until arr.length()).joinToString("\n") { i ->
                val o = arr.optJSONObject(i)
                "- prior=${o?.optString("signal", "")}, confidence=${o?.optDouble("confidence", 0.0)}, outcome=${o?.optString("actualOutcome", "unresolved")}, netPnl=${o?.optDouble("netPnl", 0.0)}"
            }
        }.orEmpty().ifBlank { "No prior AI trade lessons recorded." }
        val newsText = research.headlines.joinToString("\n") { "- $it" }.ifBlank { "No current headlines available." }
        val context = snapshot.asPromptText() + "\nBOT STRATEGY SIGNAL=${strategyDecision.signal}\nBOT STRATEGY REASON=${strategyDecision.reason}\n" +
            "CURRENT NEWS CONTEXT (non-authoritative, fetchedAtMs=${research.fetchedAtMs}, sentiment=${research.sentiment}):\n$newsText\n" +
            "PRIOR AI MEMORY (context only; never changes hard limits):\n$memoryText\n"
        checkpoint.begin(analysisId, snapshot)

        val debate = try {
            val bull = checkpoint.get(analysisId, "BULL_DONE") ?: callJson(
                apiKey, "BULL", context + "Make the strongest evidence-based bullish case. Return JSON: {\"case\":\"...\"}."
            ).optString("case", "").also { checkpoint.put(analysisId, "BULL_DONE", it) }
            val bear = checkpoint.get(analysisId, "BEAR_DONE") ?: callJson(
                apiKey, "BEAR", context + "Make the strongest evidence-based bearish case. Return JSON: {\"case\":\"...\"}."
            ).optString("case", "").also { checkpoint.put(analysisId, "BEAR_DONE", it) }
            if (bull.isBlank() || bear.isBlank()) throw IllegalStateException("Bull/bear output was empty")
            Debate(bull, bear)
        } catch (e: Exception) {
            return GateResult(review(snapshot, "Bull/bear research failed: ${e.message ?: "unknown error"}"), listOf("AI research failed"))
        }

        val adjudication = try {
            checkpoint.get(analysisId, "AI_DECISION")?.let { JSONObject(it) } ?: callJson(
                apiKey, "ADJUDICATOR",
                context + "\nBULL CASE:\n${debate.bull}\nBEAR CASE:\n${debate.bear}\n" +
                    "Adjudicate using only the verified snapshot. Return JSON exactly with keys " +
                    "signal(BUY|SELL|HOLD|REVIEW), confidence(0..1), entryPrice(number|null), " +
                    "stopLoss(number|null), takeProfit(number|null), reasoning(string). " +
                    "Do not invent exact levels unsupported by the snapshot."
            ).also { checkpoint.put(analysisId, "AI_DECISION", it.toString()) }
        } catch (e: Exception) {
            return GateResult(review(snapshot, "AI adjudication failed: ${e.message ?: "unknown error"}"), listOf("AI adjudication failed"))
        }

        val parsed = parseDecision(adjudication, snapshot, analysisId, debate, tradingViewAction)
        if (parsed.signal == AiSignal.REVIEW) return GateResult(parsed, warnings)

        val risk = try {
            checkpoint.get(analysisId, "RISK_DONE")?.let { JSONObject(it) } ?: callJson(
                apiKey, "RISK_CHALLENGER",
                context + "\nPROPOSED DECISION:\n${adjudication}\n" +
                    "Act as a conservative risk challenger. Find reasons this proposed trade should NOT happen: excessive volatility, poor R:R, stale data, trend conflict, overextension, low volume/liquidity, contradictory indicators, or uncertain stop. " +
                    "Return JSON exactly: {\"approve\":true|false,\"reasons\":\"...\"}. Never suggest bypassing hard deterministic risk limits."
            ).also { checkpoint.put(analysisId, "RISK_DONE", it.toString()) }
        } catch (e: Exception) {
            return GateResult(review(snapshot, "Risk challenge failed: ${e.message ?: "unknown error"}"), listOf("Risk challenge failed"))
        }

        val approved = risk.optBoolean("approve", false)
        val riskText = risk.optString("reasons", "No risk explanation returned.").trim()
        val final = if (!approved && parsed.signal != AiSignal.HOLD) {
            parsed.copy(signal = AiSignal.REVIEW, reasoning = "AI risk challenger rejected the proposed ${parsed.signal}: $riskText", riskChallenge = riskText)
        } else parsed.copy(riskChallenge = riskText)
        checkpoint.complete(analysisId)
        return GateResult(final, warnings)
    }

    private fun parseDecision(
        json: JSONObject,
        snapshot: MarketSnapshot,
        analysisId: String,
        debate: Debate,
        tradingViewAction: String?
    ): AiDecision {
        val rawSignal = json.optString("signal", "REVIEW").uppercase()
        val signal = when (rawSignal) { "BUY" -> AiSignal.BUY; "SELL" -> AiSignal.SELL; "HOLD" -> AiSignal.HOLD; else -> AiSignal.REVIEW }
        val confidence = json.optDouble("confidence", Double.NaN)
        val entry = json.optDoubleOrNull("entryPrice")
        val stop = json.optDoubleOrNull("stopLoss")
        val target = json.optDoubleOrNull("takeProfit")
        val valid = confidence.isFinite() && confidence in 0.0..1.0 &&
            snapshot.close > 0.0 && (entry == null || entry > 0.0) && (stop == null || stop > 0.0) && (target == null || target > 0.0) &&
            json.optString("reasoning").isNotBlank()
        if (!valid) {
            return review(snapshot, "Structured AI output failed validation; malformed output is REVIEW, never HOLD.", analysisId, debate.bull, debate.bear, tradingViewAction)
        }
        val rr = if (entry != null && stop != null && target != null && kotlin.math.abs(entry - stop) > 1e-12) {
            kotlin.math.abs(target - entry) / kotlin.math.abs(entry - stop)
        } else null
        val levelsValidForSignal = when (signal) {
            AiSignal.BUY -> entry != null && stop != null && target != null && stop < entry && target > entry && rr != null && rr >= 1.5
            AiSignal.SELL -> entry != null && stop != null && target != null && stop > entry && target < entry && rr != null && rr >= 1.5
            else -> true
        }
        if (!levelsValidForSignal) {
            return review(snapshot, "Structured AI output failed level/R:R validation; malformed trade levels become REVIEW.", analysisId, debate.bull, debate.bear, tradingViewAction)
        }
        return AiDecision(analysisId, snapshot.symbol, snapshot.asOfMs, snapshot.snapshotHash, MODEL, signal, confidence, entry, stop, target, rr,
            json.optString("reasoning").trim(), debate.bull, debate.bear, "", tradingViewAction)
    }

    private fun review(snapshot: MarketSnapshot, reason: String, id: String = UUID.randomUUID().toString(), bull: String = "", bear: String = "", tv: String? = null) =
        AiDecision(id, snapshot.symbol, snapshot.asOfMs, snapshot.snapshotHash, MODEL, AiSignal.REVIEW, 0.0, null, null, null, null, reason, bull, bear, "", tv)

    private fun callJson(apiKey: String, stage: String, userPrompt: String): JSONObject {
        val body = JSONObject().apply {
            put("model", MODEL)
            put("max_tokens", 700)
            put("messages", JSONArray().apply {
                put(JSONObject().apply { put("role", "system"); put("content", "You are the $stage component of a cautious trading research pipeline. Exact market numbers must come only from the supplied verified snapshot. Never promise profit. Return JSON only.") })
                put(JSONObject().apply { put("role", "user"); put("content", userPrompt) })
            })
            put("response_format", JSONObject().put("type", "json_object"))
        }
        val request = Request.Builder().url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer ${apiKey.trim()}")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("OpenAI $stage HTTP ${response.code}")
            val content = JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()
            if (content.isBlank()) throw IllegalStateException("OpenAI $stage returned empty JSON")
            return JSONObject(stripCodeFence(content))
        }
    }

    private fun stripCodeFence(text: String): String = text.trim().removePrefix("```").removeSuffix("```").removePrefix("json").trim()

    private fun JSONObject.optDoubleOrNull(key: String): Double? {
        if (!has(key) || isNull(key)) return null
        val value = when (val raw = get(key)) {
            is Number -> raw.toDouble()
            is String -> raw.replace(",", "").trim().removePrefix("$").toDoubleOrNull()
            else -> null
        }
        return value?.takeIf { it.isFinite() }
    }
}
