package com.example.tradingbot

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * First screen after the splash animation. Lets the person choose which
 * market to trade (crypto or a tokenized stock), and whether the bot is in
 * Testnet (paper) or Live (real funds) mode. The choice is passed on to
 * DashboardActivity, which drives the chart, strategy, and TradingService
 * off whatever Market is selected here -- there is nothing BTC-specific
 * left downstream once a market is picked.
 */
class MarketSelectionActivity : AppCompatActivity() {

    private lateinit var marketListContainer: LinearLayout
    private lateinit var modeSwitch: Switch
    private lateinit var modeTitle: TextView
    private lateinit var modeSubtitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_market_selection)

        marketListContainer = findViewById(R.id.marketList)
        modeSwitch = findViewById(R.id.modeSwitch)
        modeTitle = findViewById(R.id.modeTitle)
        modeSubtitle = findViewById(R.id.modeSubtitle)

        val currentMode = AppPreferences.getTradingMode(this)
        modeSwitch.isChecked = currentMode == TradingMode.LIVE
        refreshModeLabels(currentMode)

        modeSwitch.setOnCheckedChangeListener { switchView, checked ->
            if (checked) {
                // Real funds. Confirm explicitly rather than silently flipping the mode.
                switchView.isChecked = false
                confirmSwitchToLive()
            } else {
                AppPreferences.setTradingMode(this, TradingMode.TESTNET)
                refreshModeLabels(TradingMode.TESTNET)
                renderMarketList()
            }
        }

        renderMarketList()

        findViewById<LinearLayout>(R.id.indiaMarketsRow).setOnClickListener {
            startActivity(Intent(this, com.example.tradingbot.india.IndiaMarketSelectionActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        // In case credentials/mode changed elsewhere (e.g. Settings), keep this screen honest.
        val mode = AppPreferences.getTradingMode(this)
        modeSwitch.isChecked = mode == TradingMode.LIVE
        refreshModeLabels(mode)
        renderMarketList()
    }

    private fun confirmSwitchToLive() {
        AlertDialog.Builder(this)
            .setTitle("Switch to Live trading?")
            .setMessage(
                "Live mode places real orders with real funds on Binance, using your Live API " +
                    "key (not your Testnet key). This is required to trade tokenized stocks " +
                    "(bStocks) since they don't exist on Testnet.\n\n" +
                    "Make sure you've entered Live API credentials with trading permission " +
                    "before enabling this, and understand that losses are real."
            )
            .setPositiveButton("Switch to Live") { _, _ ->
                AppPreferences.setTradingMode(this, TradingMode.LIVE)
                modeSwitch.isChecked = true
                refreshModeLabels(TradingMode.LIVE)
                renderMarketList()
            }
            .setNegativeButton("Stay on Testnet") { _, _ ->
                modeSwitch.isChecked = false
            }
            .setCancelable(false)
            .show()
    }

    private fun refreshModeLabels(mode: TradingMode) {
        if (mode == TradingMode.LIVE) {
            modeTitle.text = "Mode: Live"
            modeSubtitle.text = "Real funds. Real orders on Binance."
            modeSubtitle.setTextColor(getColor(R.color.negative))
        } else {
            modeTitle.text = "Mode: Testnet"
            modeSubtitle.text = "Paper trading. No real funds at risk."
            modeSubtitle.setTextColor(getColor(R.color.text_secondary))
        }
    }

    private fun renderMarketList() {
        marketListContainer.removeAllViews()
        val mode = AppPreferences.getTradingMode(this)
        val inflater = LayoutInflater.from(this)

        for (market in Markets.ALL) {
            val row = inflater.inflate(R.layout.item_market_row, marketListContainer, false)

            val badge = row.findViewById<TextView>(R.id.marketIconBadge)
            badge.text = market.baseAsset.take(1)
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.parseColor(market.accentColor))
            badge.background = bg

            row.findViewById<TextView>(R.id.marketBaseAsset).text = market.baseAsset
            row.findViewById<TextView>(R.id.marketDisplayName).text = market.displayName

            val note = row.findViewById<TextView>(R.id.marketNote)
            val tradable = mode == TradingMode.LIVE || market.testnetAvailable
            if (!tradable) {
                note.visibility = View.VISIBLE
                note.text = "Chart & analysis only on Testnet · switch to Live to trade"
            } else {
                note.visibility = View.GONE
            }

            row.setOnClickListener { selectMarket(market) }
            marketListContainer.addView(row)
        }
    }

    private fun selectMarket(market: Market) {
        AppPreferences.setSelectedMarket(this, market)
        val intent = Intent(this, DashboardActivity::class.java)
        intent.putExtra(EXTRA_SYMBOL, market.symbol)
        startActivity(intent)
    }

    companion object {
        const val EXTRA_SYMBOL = "extra_symbol"
    }
}
