package com.example.tradingbot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.max
import kotlin.math.min

class BitcoinPriceChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 5f
        style = Paint.Style.STROKE
        color = 0xFF6C6EF5.toInt()
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 1f
        color = 0xFF2A2D34.toInt()
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 22f
        color = 0xFF8A8F98.toInt()
    }

    private var values: List<Double> = emptyList()

    fun setData(newValues: List<Double>) {
        values = newValues.filter { value -> value.isFinite() && value > 0.0 }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = 10f
        val right = width - 10f
        val top = 12f
        val bottom = height - 12f

        // Light grid for quick reading.
        for (i in 1..3) {
            val y = top + (bottom - top) * i / 4f
            canvas.drawLine(left, y, right, y, gridPaint)
        }

        if (values.size < 2) {
            canvas.drawText("Waiting for BTC market data…", left, height / 2f, labelPaint)
            return
        }

        val minValue = values.minOrNull() ?: return
        val maxValue = values.maxOrNull() ?: return
        val range = max(maxValue - minValue, minValue * 0.00001)
        val path = Path()

        values.forEachIndexed { index, value ->
            val x = left + (right - left) * index / (values.size - 1).toFloat()
            val y = bottom - ((value - minValue) / range).toFloat() * (bottom - top)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        canvas.drawPath(path, linePaint)

        // End-point dot and simple high/low labels.
        val last = values.last()
        val lastX = right
        val lastY = bottom - ((last - minValue) / range).toFloat() * (bottom - top)
        canvas.drawCircle(lastX, lastY, 7f, linePaint)
        canvas.drawText("Low ${format(minValue)}", left, height - 2f, labelPaint)
        val highLabel = "High ${format(maxValue)}"
        canvas.drawText(highLabel, max(left, right - labelPaint.measureText(highLabel)), top + 20f, labelPaint)
    }

    private fun format(value: Double): String {
        return if (value >= 1000) String.format(java.util.Locale.US, "$%,.0f", value)
        else String.format(java.util.Locale.US, "$%.2f", value)
    }
}
