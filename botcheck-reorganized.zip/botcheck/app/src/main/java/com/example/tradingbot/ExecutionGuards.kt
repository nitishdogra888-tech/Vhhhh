package com.example.tradingbot

import java.util.concurrent.atomic.AtomicBoolean

/**
 * Non-blocking single-owner gate used for live exit submission. CAS is required
 * here: a volatile Boolean cannot make check-then-set atomic across WebSocket
 * and REST threads.
 */
class AtomicExecutionGate {
    private val busy = AtomicBoolean(false)

    fun tryAcquire(): Boolean = busy.compareAndSet(false, true)

    fun release() {
        busy.set(false)
    }

    fun isHeld(): Boolean = busy.get()
}
