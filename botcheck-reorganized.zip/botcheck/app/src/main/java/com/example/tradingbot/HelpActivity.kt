package com.example.tradingbot

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.card.MaterialCardView

/**
 * Beginner-friendly, in-app explanation of the actual screens and safety flow.
 *
 * This screen deliberately contains no trading logic and never handles credentials.
 * It only explains the existing application.
 */
class HelpActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)

        findViewById<MaterialToolbar>(R.id.helpToolbar).setNavigationOnClickListener {
            finish()
        }

        val sections = listOf(
            R.id.helpStartCard,
            R.id.helpScreensCard,
            R.id.helpAiCard,
            R.id.helpProfileCard,
            R.id.helpFlowCard,
            R.id.helpSafetyCard,
            R.id.helpTroubleshootingCard
        )

        sections.forEach { id ->
            val card = findViewById<MaterialCardView>(id)
            val body = card.findViewById<View>(resources.getIdentifier(
                "${resources.getResourceEntryName(id)}Body", "id", packageName
            ))
            val title = card.findViewById<TextView>(resources.getIdentifier(
                "${resources.getResourceEntryName(id)}Title", "id", packageName
            ))
            if (body != null) {
                card.setOnClickListener {
                    body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                }
            }
            if (title != null) title.isClickable = false
        }
    }
}
