package com.example.tradingbot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import java.util.Locale

/**
 * A live price line-chart, styled like a modern trading-app sparkline:
 * a smoothed curve, a soft gradient fill underneath, a glowing dot on
 * the latest tick, min/max axis labels for scale, a bold live price
 * readout, and (when a position is open) a dashed entry-price line with
 * a marker dot — green above it (in profit), red below it (in loss).
 * No external charting library required.
 */
class SparklineView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var points: List<Double> = emptyList()
    private var lineColor: Int = Color.parseColor("#1DBE86") // teal/green

    // Optional horizontal reference line marking the open position's entry
    // price, so it's visually obvious whether the current price is above
    // (in profit) or below (in loss) where the bot bought in.
    private var referencePrice: Double? = null
    private var referenceLabel: String = ""

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5.5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val dotOuterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        alpha = 60
    }

    private val dotInnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val referenceLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 8f), 0f)
    }

    private val referenceDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val referenceLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 22f
        isFakeBoldText = true
    }

    // Bold live price readout, pinned to the top-right of the chart.
    private val currentPricePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 30f
        isFakeBoldText = true
        textAlign = Paint.Align.RIGHT
    }

    // Small faint min/max scale labels on the left edge.
    private val axisLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 20f
        color = Color.parseColor("#8A8F98")
    }

    private fun fmt(v: Double) = String.format(Locale.US, "$%,.2f", v)

    /**
     * Light moving-average smoothing so a single noisy tick doesn't read
     * as a huge spike, while keeping the true latest price for the dot,
     * the live readout, and the entry comparison. The raw data itself is
     * unchanged elsewhere in the app — this only affects the drawn curve.
     */
    private fun smoothed(raw: List<Double>): List<Double> {
        if (raw.size < 3) return raw
        val out = DoubleArray(raw.size)
        for (i in raw.indices) {
            val lo = (i - 1).coerceAtLeast(0)
            val hi = (i + 1).coerceAtMost(raw.size - 1)
            var sum = 0.0
            var n = 0
            for (j in lo..hi) { sum += raw[j]; n++ }
            out[i] = sum / n
        }
        // Keep the true latest tick exact — the dot and price readout must
        // reflect the real current price, not a smoothed approximation.
        out[out.size - 1] = raw.last()
        return out.toList()
    }

    fun setData(newPoints: List<Double>, isUptrend: Boolean) {
        points = newPoints
        lineColor = if (isUptrend) Color.parseColor("#1DBE86") else Color.parseColor("#F0553A")
        invalidate()
    }

    /**
     * Draws a dashed horizontal line at [price] (the open position's entry
     * price) with a marker dot on the left edge, so it's easy to see at a
     * glance whether the live price is currently above it (profit) or
     * below it (loss). Pass null to clear it when there's no open position.
     */
    fun setReferencePrice(price: Double?, label: String = "Entry") {
        referencePrice = price
        referenceLabel = label
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (points.size < 2) return

        val raw = points
        val plotted = smoothed(raw)
        val ref = referencePrice
        val min = minOf(raw.min(), ref ?: raw.min())
        val max = maxOf(raw.max(), ref ?: raw.max())
        val range = (max - min).let { valueRange -> if (valueRange == 0.0) 1.0 else valueRange }

        val w = width.toFloat()
        val h = height.toFloat()
        // Headroom for the price readout at top, and the line/dot so they
        // never clip at the edges.
        val topInset = 34f
        val bottomInset = 22f
        val usableH = (h - topInset - bottomInset).coerceAtLeast(1f)
        val stepX = w / (plotted.size - 1)

        fun yFor(v: Double) = topInset + usableH - ((v - min) / range).toFloat() * usableH

        val linePath = Path()
        val fillPath = Path()

        var x = 0f
        var y = yFor(plotted[0])
        linePath.moveTo(x, y)
        fillPath.moveTo(x, h)
        fillPath.lineTo(x, y)

        for (i in 1 until plotted.size) {
            val nx = i * stepX
            val ny = yFor(plotted[i])
            // Smooth curve between points instead of straight segments.
            val midX = (x + nx) / 2f
            linePath.cubicTo(midX, y, midX, ny, nx, ny)
            fillPath.cubicTo(midX, y, midX, ny, nx, ny)
            x = nx
            y = ny
        }
        fillPath.lineTo(x, h)
        fillPath.close()

        // Gradient fill: solid-ish near the line, fading to transparent at the bottom.
        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, h,
            Color.argb(70, Color.red(lineColor), Color.green(lineColor), Color.blue(lineColor)),
            Color.argb(0, Color.red(lineColor), Color.green(lineColor), Color.blue(lineColor)),
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(fillPath, fillPaint)

        linePaint.color = lineColor
        canvas.drawPath(linePath, linePaint)

        // Min/max scale labels so the line isn't just an unlabeled squiggle.
        axisLabelPaint.textAlign = Paint.Align.LEFT
        canvas.drawText(fmt(max), 2f, topInset - 12f, axisLabelPaint)
        canvas.drawText(fmt(min), 2f, h - 4f, axisLabelPaint)

        // Glowing endpoint dot on the true latest price (not smoothed).
        val lastX = x
        val lastY = yFor(raw.last())
        dotOuterPaint.color = lineColor
        dotInnerPaint.color = lineColor
        canvas.drawCircle(lastX, lastY, 9f, dotOuterPaint)
        canvas.drawCircle(lastX, lastY, 4f, dotInnerPaint)

        // Bold live price readout, top-right — the real-time number, not
        // just a line to eyeball.
        currentPricePaint.color = lineColor
        canvas.drawText(fmt(raw.last()), w - 2f, 24f, currentPricePaint)

        // Entry-price reference line: green when the latest price is above
        // it (in profit vs entry), red when below (in loss vs entry).
        if (ref != null) {
            val currentPrice = raw.last()
            val refColor = if (currentPrice >= ref) Color.parseColor("#1DBE86") else Color.parseColor("#F0553A")
            val refY = yFor(ref)
            referenceLinePaint.color = refColor
            canvas.drawLine(0f, refY, w, refY, referenceLinePaint)

            // Marker dot on the entry line itself, in addition to the line,
            // so the entry point reads clearly even at a glance.
            referenceDotPaint.color = refColor
            canvas.drawCircle(14f, refY, 6f, referenceDotPaint)

            referenceLabelPaint.color = refColor
            val label = "$referenceLabel ${fmt(ref)}"
            val labelY = (refY - 6f).coerceIn(referenceLabelPaint.textSize, h - 4f)
            canvas.drawText(label, 26f, labelY, referenceLabelPaint)
        }
    }
}
