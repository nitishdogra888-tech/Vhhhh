package com.example.tradingbot

/** Shared look-ahead guard for live snapshots and historical tooling. */
object PointInTime {
    fun isAllowed(timestampMs: Long, analysisTimestampMs: Long): Boolean = timestampMs <= analysisTimestampMs

    fun latestAllowedIndex(timestampsMs: List<Long>, analysisTimestampMs: Long): Int =
        timestampsMs.indexOfLast { isAllowed(it, analysisTimestampMs) }
}
