package com.example.tradingbot

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.Lifecycle
import kotlinx.coroutines.launch

/**
 * Fullscreen mirror of the dashboard's BTC/USDT chart. It does not
 * re-bootstrap candles or open its own websocket -- it just observes
 * ChartDataBus, which DashboardActivity keeps updated in the background
 * (the dashboard's websocket/session isn't torn down while this is open).
 */
class FullscreenChartActivity : AppCompatActivity() {

    private lateinit var chart: BinanceCandlestickChartView
    private lateinit var rangeLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fullscreen_chart)

        chart = findViewById(R.id.fullscreenPriceChart)
        rangeLabel = findViewById(R.id.fullscreenChartRangeLabel)
        findViewById<TextView>(R.id.fullscreenChartBackButton).setOnClickListener { finish() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { ChartDataBus.candles.collect { candles -> chart.setCandles(candles) } }
                launch {
                    ChartDataBus.levels.collect { levels ->
                        chart.setLevels(levels.entry, levels.stop, levels.take, levels.trail)
                    }
                }
                launch {
                    ChartDataBus.rangeLabel.collect { label ->
                        if (label.isNotBlank()) rangeLabel.text = label
                    }
                }
            }
        }
    }
}
