package com.example.tradingbot.scanner

import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

/**
 * Tunable thresholds for turning raw indicator values into a signal.
 */
data class ScannerConfig(
    val rsiPeriod: Int = 14,
    val rsiOversold: Double = 30.0,
    val rsiOverbought: Double = 70.0,
    val macdFast: Int = 12,
    val macdSlow: Int = 26,
    val macdSignal: Int = 9,
    val maFastPeriod: Int = 50,
    val maSlowPeriod: Int = 200,
    val barsToFetch: Int = 250,
    // Minimum |score| to be classified BUY/SELL instead of WATCH/NONE.
    val signalThreshold: Int = 2
)

/**
 * Scans a watchlist of symbols in parallel, computing RSI, MACD, and a
 * moving-average crossover for each, then ranks them by how many of
 * those signals agree.
 */
class MarketScanner(
    private val dataProvider: StockDataProvider,
    private val config: ScannerConfig = ScannerConfig()
) {

    /**
     * Returns one [ScanResult] per symbol that could be scanned
     * successfully (symbols that error out are silently skipped —
     * check logs if you need to know which ones failed), sorted with
     * the strongest bullish signals first.
     */
    suspend fun scan(symbols: List<String>): List<ScanResult> = coroutineScope {
        val deferred = symbols.map { symbol ->
            async { runCatching { scanSymbol(symbol) }.getOrNull() }
        }
        deferred.mapNotNull { task -> task.await() }
            .sortedByDescending { result -> result.score }
    }

    private suspend fun scanSymbol(symbol: String): ScanResult? {
        val bars = dataProvider.getDailyBars(symbol, config.barsToFetch)
        if (bars.size < config.maSlowPeriod) return null // not enough history

        val closes = bars.map { bar -> bar.close }

        val rsiSeries = TechnicalIndicators.rsi(closes, config.rsiPeriod)
        val lastRsi = rsiSeries.lastOrNull()

        val macd = TechnicalIndicators.macd(
            closes, config.macdFast, config.macdSlow, config.macdSignal
        )
        val lastHistogram = macd.histogram.lastOrNull()
        val prevHistogram = macd.histogram.getOrNull(macd.histogram.size - 2)

        val fastMa = TechnicalIndicators.ema(closes, config.maFastPeriod)
        val slowMa = TechnicalIndicators.ema(closes, config.maSlowPeriod)
        val crossover = TechnicalIndicators.detectCrossover(fastMa, slowMa)

        var score = 0

        // RSI: oversold is bullish, overbought is bearish.
        if (lastRsi != null) {
            if (lastRsi <= config.rsiOversold) score += 1
            if (lastRsi >= config.rsiOverbought) score -= 1
        }

        // MACD: histogram crossing from negative to positive (or vice
        // versa) signals fresh momentum.
        if (lastHistogram != null && prevHistogram != null) {
            if (prevHistogram <= 0 && lastHistogram > 0) score += 1
            if (prevHistogram >= 0 && lastHistogram < 0) score -= 1
        }

        // MA crossover: golden cross bullish, death cross bearish.
        when (crossover) {
            TechnicalIndicators.Crossover.GOLDEN -> score += 1
            TechnicalIndicators.Crossover.DEATH -> score -= 1
            TechnicalIndicators.Crossover.NONE -> {}
        }

        val overall = when {
            score >= config.signalThreshold -> OverallSignal.BUY
            score <= -config.signalThreshold -> OverallSignal.SELL
            score != 0 -> OverallSignal.WATCH
            else -> OverallSignal.NONE
        }

        return ScanResult(
            symbol = symbol,
            lastClose = closes.last(),
            rsi = lastRsi,
            macdHistogram = lastHistogram,
            maCrossover = crossover,
            score = score,
            overallSignal = overall
        )
    }
}
