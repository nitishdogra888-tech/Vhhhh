package com.example.tradingbot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persists closed-trade history, cumulative stats, open position, daily
 * risk, and a hard trading lock so a restart cannot wipe risk controls.
 */
class TradeHistoryStore(context: Context) {

    private val prefs = context.getSharedPreferences("trading_bot_history", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_TRADES = "trades_json"
        private const val KEY_MANUAL_TRADES = "manual_trades_json"
        private const val KEY_CUMULATIVE = "cumulative_json"
        private const val KEY_OPEN_POSITION = "open_position_json"
        private const val KEY_DAILY_RISK = "daily_risk_json"
        private const val KEY_TRADING_LOCK = "trading_lock_json"
        private const val KEY_AUTO_BUY_CIRCUIT = "auto_buy_circuit_json"
        private const val KEY_SESSION_RISK = "session_risk_json"
        private const val KEY_PROTECTION_ERROR = "protection_error"
        private const val KEY_PENDING_ORDER = "pending_order_json"
        private const val KEY_AI_ANALYSIS = "ai_analysis_json"
        private const val KEY_AI_RESEARCH = "ai_research_json"
        private const val MAX_STORED_TRADES = 200
        private const val MAX_STORED_AI_ANALYSES = 200
    }

    fun saveOpenPosition(snapshot: PositionSnapshot) {
        val obj = JSONObject().apply {
            put("entryPrice", snapshot.entryPrice)
            put("quantity", snapshot.quantity)
            put("entryTimestampMs", snapshot.entryTimestampMs)
            put("peakProfitPercent", snapshot.peakProfitPercent)
            put("stopLossPercent", snapshot.stopLossPercent)
            put("takeProfitPercent", snapshot.takeProfitPercent)
            put("trailingActivationPercent", snapshot.trailingActivationPercent)
            put("manualTrade", snapshot.manualTrade)
        }
        prefs.edit().putString(KEY_OPEN_POSITION, obj.toString()).apply()
    }

    fun loadOpenPosition(): PositionSnapshot? {
        val json = prefs.getString(KEY_OPEN_POSITION, null) ?: return null
        return try {
            val obj = JSONObject(json)
            PositionSnapshot(
                entryPrice = obj.getDouble("entryPrice"),
                quantity = obj.getDouble("quantity"),
                entryTimestampMs = obj.getLong("entryTimestampMs"),
                peakProfitPercent = obj.getDouble("peakProfitPercent"),
                stopLossPercent = obj.optDouble("stopLossPercent", TradingService.DEFAULT_STOP_LOSS_PERCENT),
                takeProfitPercent = obj.optDouble("takeProfitPercent", TradingService.DEFAULT_TAKE_PROFIT_PERCENT),
                trailingActivationPercent = obj.optDouble("trailingActivationPercent", TradingService.DEFAULT_TRAILING_ACTIVATION_PERCENT),
                manualTrade = obj.optBoolean("manualTrade", false)
            )
        } catch (e: Exception) {
            null
        }
    }

    fun clearOpenPosition() {
        prefs.edit().remove(KEY_OPEN_POSITION).apply()
    }

    fun saveDailyRisk(snapshot: DailyRiskSnapshot) {
        val obj = JSONObject().apply {
            put("tradingDay", snapshot.tradingDay)
            put("dayStartEquity", snapshot.dayStartEquity)
            put("remainingBudgetUsd", snapshot.remainingBudgetUsd)
            put("dailyStopLocked", snapshot.dailyStopLocked)
            put("consecutiveLosses", snapshot.consecutiveLosses)
            put("tradesToday", snapshot.tradesToday)
            put("lastExitMs", snapshot.lastExitMs)
            put("dailyNotionalUsedUsd", snapshot.dailyNotionalUsedUsd)
        }
        prefs.edit().putString(KEY_DAILY_RISK, obj.toString()).apply()
    }

    fun loadDailyRisk(): DailyRiskSnapshot? {
        val json = prefs.getString(KEY_DAILY_RISK, null) ?: return null
        return try {
            val obj = JSONObject(json)
            DailyRiskSnapshot(
                tradingDay = obj.getString("tradingDay"),
                dayStartEquity = obj.getDouble("dayStartEquity"),
                remainingBudgetUsd = obj.getDouble("remainingBudgetUsd"),
                dailyStopLocked = obj.getBoolean("dailyStopLocked"),
                consecutiveLosses = obj.optInt("consecutiveLosses", 0),
                tradesToday = obj.optInt("tradesToday", 0),
                lastExitMs = obj.optLong("lastExitMs", 0L),
                dailyNotionalUsedUsd = obj.optDouble("dailyNotionalUsedUsd", Double.NaN)
            )
        } catch (e: Exception) {
            null
        }
    }

    fun saveTradingLock(locked: Boolean, reason: String) {
        val obj = JSONObject().apply {
            put("locked", locked)
            put("reason", reason)
        }
        prefs.edit().putString(KEY_TRADING_LOCK, obj.toString()).apply()
    }

    fun loadTradingLock(): Pair<Boolean, String> {
        val json = prefs.getString(KEY_TRADING_LOCK, null) ?: return false to ""
        return try {
            val obj = JSONObject(json)
            obj.optBoolean("locked", false) to obj.optString("reason", "")
        } catch (e: Exception) {
            false to ""
        }
    }

    fun clearTradingLock() {
        prefs.edit().remove(KEY_TRADING_LOCK).apply()
    }

    fun saveAutoBuyCircuitPaused(paused: Boolean, reason: String = "") {
        prefs.edit().putString(KEY_AUTO_BUY_CIRCUIT, JSONObject().apply {
            put("paused", paused)
            put("reason", reason)
        }.toString()).apply()
    }

    fun loadAutoBuyCircuitPaused(): Pair<Boolean, String> {
        val json = prefs.getString(KEY_AUTO_BUY_CIRCUIT, null) ?: return false to ""
        return try {
            val obj = JSONObject(json)
            obj.optBoolean("paused", false) to obj.optString("reason", "")
        } catch (_: Exception) { false to "" }
    }

    fun saveSessionRisk(snapshot: SessionRiskSnapshot) {
        prefs.edit().putString(KEY_SESSION_RISK, JSONObject().apply {
            put("windowStartMs", snapshot.windowStartMs)
            put("windowNetPnl", snapshot.windowNetPnl)
            put("windowNotionalUsedUsd", snapshot.windowNotionalUsedUsd)
            put("windowLockReason", snapshot.windowLockReason)
        }.toString()).apply()
    }

    fun loadSessionRisk(): SessionRiskSnapshot? {
        val json = prefs.getString(KEY_SESSION_RISK, null) ?: return null
        return try {
            val obj = JSONObject(json)
            SessionRiskSnapshot(
                obj.optLong("windowStartMs", 0L),
                obj.optDouble("windowNetPnl", 0.0),
                obj.optDouble("windowNotionalUsedUsd", 0.0),
                if (obj.isNull("windowLockReason")) null else obj.optString("windowLockReason", "").ifBlank { null }
            )
        } catch (_: Exception) { null }
    }


    fun savePendingOrder(snapshot: PendingOrderSnapshot) {
        prefs.edit().putString(KEY_PENDING_ORDER, JSONObject().apply {
            put("symbol", snapshot.symbol)
            put("side", snapshot.side)
            put("quantity", snapshot.quantity)
            put("clientOrderId", snapshot.clientOrderId)
            put("createdAtMs", snapshot.createdAtMs)
        }.toString()).commit()
    }

    fun loadPendingOrder(): PendingOrderSnapshot? {
        val json = prefs.getString(KEY_PENDING_ORDER, null) ?: return null
        return try {
            val obj = JSONObject(json)
            PendingOrderSnapshot(
                symbol = obj.getString("symbol"),
                side = obj.getString("side"),
                quantity = obj.getDouble("quantity"),
                clientOrderId = obj.getString("clientOrderId"),
                createdAtMs = obj.getLong("createdAtMs")
            )
        } catch (_: Exception) {
            null
        }
    }

    fun clearPendingOrder() {
        prefs.edit().remove(KEY_PENDING_ORDER).commit()
    }
    fun saveProtectionError(error: String?) {
        if (error.isNullOrBlank()) prefs.edit().remove(KEY_PROTECTION_ERROR).apply()
        else prefs.edit().putString(KEY_PROTECTION_ERROR, error).apply()
    }

    fun loadProtectionError(): String = prefs.getString(KEY_PROTECTION_ERROR, "") ?: ""

    fun appendTrade(
        timestampMs: Long,
        entryPrice: Double,
        exitPrice: Double,
        quantity: Double,
        cost: TradeCost,
        pricePath: List<Double> = emptyList(),
        clientOrderId: String = "",
        exchangeOrderId: Long = 0L,
        fillStatus: String = "",
        exitReason: String = "",
        manualTrade: Boolean = false
    ) {
        val trades = getTrades()
        trades.put(JSONObject().apply {
            put("t", timestampMs)
            put("entry", entryPrice)
            put("exit", exitPrice)
            put("qty", quantity)
            put("gross", cost.grossPnl)
            put("fees", cost.exchangeFees)
            put("tds", cost.tds)
            put("tax", cost.taxOnGain)
            put("net", cost.netPnl)
            put("path", JSONArray(pricePath))
            put("clientOrderId", clientOrderId)
            put("orderId", exchangeOrderId)
            put("fillStatus", fillStatus)
            put("exitReason", exitReason)
            put("manualTrade", manualTrade)
        })

        val toStore = if (trades.length() > MAX_STORED_TRADES) {
            JSONArray((0 until trades.length()).map { index -> trades.getJSONObject(index) }.takeLast(MAX_STORED_TRADES))
        } else {
            trades
        }
        prefs.edit().putString(KEY_TRADES, toStore.toString()).apply()

        if (manualTrade) {
            val manualTrades = getManualTrades()
            manualTrades.put(trades.getJSONObject(trades.length() - 1))
            val manualToStore = if (manualTrades.length() > MAX_STORED_TRADES) {
                JSONArray((0 until manualTrades.length()).map { index -> manualTrades.getJSONObject(index) }.takeLast(MAX_STORED_TRADES))
            } else manualTrades
            prefs.edit().putString(KEY_MANUAL_TRADES, manualToStore.toString()).apply()
        }
    }

    fun getTrades(): JSONArray =
        try {
            JSONArray(prefs.getString(KEY_TRADES, "[]"))
        } catch (e: Exception) {
            JSONArray()
        }

    /**
     * Raw stored JSON string, with no parse/re-serialize round trip. The
     * dashboard broadcast only needs the JSON *text* to put in an Intent
     * extra -- decoding it into a JSONArray and calling toString() on it
     * again on every broadcast was pure wasted CPU, since appendTrade()
     * already wrote out valid, up-to-date JSON text.
     */
    fun getTradesJson(): String = prefs.getString(KEY_TRADES, "[]") ?: "[]"

    fun getManualTrades(): JSONArray {
        // Rebuild from the authoritative combined history so upgrades from older
        // versions (where the separate manual collection did not exist) still
        // show every manually-tagged trade. Persist the rebuilt subset for a
        // fast, separately recoverable manual-history collection.
        val all = getTrades()
        val out = JSONArray()
        for (i in 0 until all.length()) {
            val obj = all.getJSONObject(i)
            if (obj.optBoolean("manualTrade", false)) out.put(obj)
        }
        prefs.edit().putString(KEY_MANUAL_TRADES, out.toString()).apply()
        return out
    }

    fun getAutomatedTrades(): JSONArray {
        val all = getTrades()
        val out = JSONArray()
        for (i in 0 until all.length()) {
            val obj = all.getJSONObject(i)
            if (!obj.optBoolean("manualTrade", false)) out.put(obj)
        }
        return out
    }

    /**
     * Logs one AiSignalAdvisor verdict (automated-event vision pass or a
     * manually-uploaded chart) alongside the trade history -- purely a
     * record of what the AI said and when; it never feeds back into order
     * placement or sizing on its own.
     */
    fun appendAiAnalysis(
        timestampMs: Long,
        source: String,
        provider: String,
        price: Double,
        signal: String,
        probability: Double,
        reasoning: String,
        entry: Double,
        takeProfit: Double,
        stopLoss: Double,
        riskReward: Double,
        horizon: String
    ) {
        val analyses = getAiAnalysesRaw()
        analyses.put(JSONObject().apply {
            put("t", timestampMs)
            put("source", source)
            put("provider", provider)
            put("price", price)
            put("signal", signal)
            put("probability", probability)
            put("reasoning", reasoning)
            put("entry", entry)
            put("takeProfit", takeProfit)
            put("stopLoss", stopLoss)
            put("riskReward", riskReward)
            put("horizon", horizon)
        })

        val toStore = if (analyses.length() > MAX_STORED_AI_ANALYSES) {
            JSONArray((0 until analyses.length()).map { index -> analyses.getJSONObject(index) }.takeLast(MAX_STORED_AI_ANALYSES))
        } else {
            analyses
        }
        prefs.edit().putString(KEY_AI_ANALYSIS, toStore.toString()).apply()
    }

    private fun getAiAnalysesRaw(): JSONArray =
        try {
            JSONArray(prefs.getString(KEY_AI_ANALYSIS, "[]"))
        } catch (e: Exception) {
            JSONArray()
        }

    fun getAiAnalyses(): JSONArray = getAiAnalysesRaw()


    fun appendAiResearchDecision(decision: AiResearchEngine.AiDecision) {
        val arr = try { JSONArray(prefs.getString(KEY_AI_RESEARCH, "[]")) } catch (_: Exception) { JSONArray() }
        arr.put(JSONObject().apply {
            put("analysisId", decision.analysisId)
            put("symbol", decision.symbol)
            put("timestamp", decision.asOfMs)
            put("snapshotHash", decision.snapshotHash)
            put("model", decision.model)
            put("signal", decision.signal.name)
            put("confidence", decision.confidence)
            put("reasoning", decision.reasoning)
            put("entry", decision.entryPrice)
            put("stop", decision.stopLoss)
            put("takeProfit", decision.takeProfit)
            put("riskReward", decision.riskReward)
            put("bullCase", decision.bullCase)
            put("bearCase", decision.bearCase)
            put("riskChallenge", decision.riskChallenge)
            put("tradingViewAction", decision.tradingViewAction)
            put("status", "ANALYSIS")
        })
        val start = maxOf(0, arr.length() - 200)
        val out = JSONArray()
        for (i in start until arr.length()) out.put(arr.getJSONObject(i))
        prefs.edit().putString(KEY_AI_RESEARCH, out.toString()).apply()
    }

    fun recordAiResearchOutcome(analysisId: String, netPnl: Double, outcome: String) {
        val arr = try { JSONArray(prefs.getString(KEY_AI_RESEARCH, "[]")) } catch (_: Exception) { JSONArray() }
        for (i in arr.length() - 1 downTo 0) {
            val obj = arr.optJSONObject(i) ?: continue
            if (obj.optString("analysisId") == analysisId) {
                obj.put("status", "CLOSED").put("actualOutcome", outcome).put("netPnl", netPnl)
                break
            }
        }
        prefs.edit().putString(KEY_AI_RESEARCH, arr.toString()).apply()
    }

    fun getAiResearchAnalyses(): JSONArray =
        try { JSONArray(prefs.getString(KEY_AI_RESEARCH, "[]")) } catch (_: Exception) { JSONArray() }

    fun saveCumulative(stats: TradeStats) {
        val obj = JSONObject().apply {
            put("totalTrades", stats.totalTrades)
            put("wins", stats.wins)
            put("losses", stats.losses)
            put("totalWinPercent", stats.totalWinPercent)
            put("totalLossPercent", stats.totalLossPercent)
            put("totalGrossPnl", stats.totalGrossPnl)
            put("totalExchangeFees", stats.totalExchangeFees)
            put("totalTds", stats.totalTds)
            put("totalTaxEstimate", stats.totalTaxEstimate)
            put("totalNetPnl", stats.totalNetPnl)
        }
        prefs.edit().putString(KEY_CUMULATIVE, obj.toString()).apply()
    }

    fun restoreCumulative(stats: TradeStats) {
        val json = prefs.getString(KEY_CUMULATIVE, null) ?: return
        try {
            val obj = JSONObject(json)
            stats.restore(
                totalTrades = obj.getInt("totalTrades"),
                wins = obj.getInt("wins"),
                losses = obj.getInt("losses"),
                totalWinPercent = obj.getDouble("totalWinPercent"),
                totalLossPercent = obj.getDouble("totalLossPercent"),
                totalGrossPnl = obj.getDouble("totalGrossPnl"),
                totalExchangeFees = obj.getDouble("totalExchangeFees"),
                totalTds = obj.getDouble("totalTds"),
                totalTaxEstimate = obj.getDouble("totalTaxEstimate"),
                totalNetPnl = obj.getDouble("totalNetPnl")
            )
        } catch (e: Exception) {
            // Corrupt or old-format data -- start fresh rather than crash the service.
        }
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
