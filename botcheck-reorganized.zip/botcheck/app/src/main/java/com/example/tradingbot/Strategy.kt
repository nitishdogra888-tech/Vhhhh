package com.example.tradingbot

import kotlin.math.abs
import kotlin.math.max
import org.json.JSONArray
import com.example.tradingbot.scanner.TechnicalIndicators

enum class Signal { BUY, SELL, HOLD }
enum class ExitReason { STOP_LOSS, TAKE_PROFIT, TRAILING_STOP, REVERSAL_SIGNAL, MANUAL_CLOSE, NONE }

/** Everything needed to resume an open position across a service restart. */
data class PendingOrderSnapshot(
    val symbol: String,
    val side: String,
    val quantity: Double,
    val clientOrderId: String,
    val createdAtMs: Long
)

data class PositionSnapshot(
    val entryPrice: Double,
    val quantity: Double,
    val entryTimestampMs: Long,
    val peakProfitPercent: Double,
    val stopLossPercent: Double = 0.012,
    val takeProfitPercent: Double = 0.025,
    val trailingActivationPercent: Double = 0.026,
    val manualTrade: Boolean = false
)

/** Daily risk fields that must survive process death. Same calendar day only. */
data class DailyRiskSnapshot(
    val tradingDay: String,
    val dayStartEquity: Double,
    val remainingBudgetUsd: Double,
    val dailyStopLocked: Boolean,
    val consecutiveLosses: Int,
    val tradesToday: Int,
    val lastExitMs: Long,
    val dailyNotionalUsedUsd: Double = 0.0
)

data class SessionRiskSnapshot(
    val windowStartMs: Long,
    val windowNetPnl: Double,
    val windowNotionalUsedUsd: Double,
    val windowLockReason: String?
)

/**
 * A strategy signal plus a plain-English explanation of why it fired,
 * so the dashboard can show "why" instead of just the raw BUY/SELL/HOLD
 * label. Purely descriptive -- carrying the numbers that drove the
 * decision doesn't change the decision itself.
 */
data class StrategyDecision(
    val signal: Signal,
    val reason: String,
    val shortSma: Double = 0.0,
    val longSma: Double = 0.0,
    val rsi: Double = 50.0,
    val bullishScore: Int = 0,
    val bearishScore: Int = 0,
    val signalQuality: Int = 0
)

/**
 * Common contract every entry strategy implements. TradingService only
 * depends on this interface, so swapping which strategy runs is a matter
 * of picking a different id in StrategyCatalog -- no changes needed to
 * the service, risk manager, or position tracker.
 */
interface TradingStrategy {
    fun evaluate(klines: JSONArray): StrategyDecision
}

/**
 * SMA crossover for ENTRY timing, confirmed by RSI, with a coarse regime
 * filter and a FRESH momentum kicker (fires only on the first candle the
 * threshold is crossed, not every cycle while it remains true).
 */
class SmaCrossoverStrategy(
    private val shortPeriod: Int = 3,
    private val longPeriod: Int = 10,
    private val rsiPeriod: Int = 14,
    private val momentumLookback: Int = 3,
    private val momentumThresholdPercent: Double = 0.15,
    private val regimePeriod: Int = 100
) : TradingStrategy {
    private var lastShortAboveLong: Boolean? = null
    private var momentumWasTrue: Boolean = false

    override fun evaluate(klines: JSONArray): StrategyDecision {
        val neededCandles = maxOf(longPeriod, regimePeriod) + 1
        if (klines.length() < neededCandles + 1) {
            return StrategyDecision(
                Signal.HOLD,
                "Not enough closed-candle history yet (need $neededCandles candles) — waiting to build up data before evaluating any signal."
            )
        }
        val closes = (0 until klines.length() - 1).map { index ->
            klines.getJSONArray(index).getString(4).toDouble()
        }

        val shortSma = closes.takeLast(shortPeriod).average()
        val longSma = closes.takeLast(longPeriod).average()
        val shortAboveLong = shortSma > longSma
        val rsi = calculateRsi(closes, rsiPeriod)

        val crossedUp = lastShortAboveLong == false && shortAboveLong
        val crossedDown = lastShortAboveLong == true && !shortAboveLong
        lastShortAboveLong = shortAboveLong

        val risePercent = if (closes.size > momentumLookback) {
            val past = closes[closes.size - 1 - momentumLookback]
            val now = closes.last()
            (now - past) / past * 100.0
        } else 0.0
        val momentumNow = risePercent >= momentumThresholdPercent && rsi < 75.0
        // Fresh-setup gate: do not re-fire BUY every 15s while the 2% rise remains true.
        val momentumBuy = momentumNow && !momentumWasTrue
        momentumWasTrue = momentumNow

        val regimeSma = if (regimePeriod > 0 && closes.size >= regimePeriod) closes.takeLast(regimePeriod).average() else null
        val regimeUptrend = regimeSma == null || closes.last() >= regimeSma
        val regimeDowntrend = regimeSma == null || closes.last() <= regimeSma
        val regimeNote = if (regimeSma != null)
            " Regime filter (SMA$regimePeriod = ${"%.2f".format(regimeSma)}): price is ${if (regimeUptrend) "above" else "below"} it."
        else ""

        return when {
            crossedUp && rsi < 70.0 && regimeUptrend -> StrategyDecision(
                Signal.BUY,
                "Short-term average ($shortPeriod candles: ${"%.2f".format(shortSma)}) crossed above the long-term average " +
                    "($longPeriod candles: ${"%.2f".format(longSma)}), and RSI ${"%.0f".format(rsi)} is below the 70 " +
                    "overbought line — upward momentum with room to run.$regimeNote",
                shortSma, longSma, rsi
            )
            momentumBuy && regimeUptrend -> StrategyDecision(
                Signal.BUY,
                "Price rose ${"%.2f".format(risePercent)}% over the last $momentumLookback candles, past the " +
                    "${"%.2f".format(momentumThresholdPercent)}% momentum threshold (fresh cross) — buying instead of " +
                    "waiting for the averages to cross. RSI ${"%.0f".format(rsi)} confirms it isn't overbought yet.$regimeNote",
                shortSma, longSma, rsi
            )
            crossedDown && rsi > 30.0 && regimeDowntrend -> StrategyDecision(
                Signal.SELL,
                "Short-term average (${"%.2f".format(shortSma)}) crossed below the long-term average " +
                    "(${"%.2f".format(longSma)}), and RSI ${"%.0f".format(rsi)} is above the 30 oversold line — " +
                    "downward momentum confirmed.$regimeNote",
                shortSma, longSma, rsi
            )
            else -> StrategyDecision(Signal.HOLD, holdReason(shortAboveLong, shortSma, longSma, rsi, risePercent) + regimeNote, shortSma, longSma, rsi)
        }
    }

    private fun holdReason(shortAboveLong: Boolean, shortSma: Double, longSma: Double, rsi: Double, risePercent: Double): String {
        val trendPart = if (shortAboveLong)
            "Short average (${"%.2f".format(shortSma)}) is already above the long average (${"%.2f".format(longSma)}) — no fresh crossover to trade on."
        else
            "Short average (${"%.2f".format(shortSma)}) is still below the long average (${"%.2f".format(longSma)}) — no upward crossover yet."
        val rsiPart = when {
            rsi >= 70.0 -> "RSI ${"%.0f".format(rsi)} is overbought, so a BUY crossover would be blocked anyway."
            rsi <= 30.0 -> "RSI ${"%.0f".format(rsi)} is oversold, so a SELL crossover would be blocked anyway."
            else -> "RSI ${"%.0f".format(rsi)} is neutral."
        }
        val momentumPart = if (momentumThresholdPercent > 0)
            "Recent ${momentumLookback}-candle move is ${"%.2f".format(risePercent)}%, below the ${"%.2f".format(momentumThresholdPercent)}% momentum threshold (or already consumed)."
        else ""
        return listOf(trendPart, rsiPart, momentumPart).filter { part -> part.isNotBlank() }.joinToString(" ")
    }

    private fun calculateRsi(closes: List<Double>, period: Int): Double {
        if (closes.size < period + 1) return 50.0

        var avgGain = 0.0
        var avgLoss = 0.0
        for (i in 1..period) {
            val change = closes[i] - closes[i - 1]
            if (change > 0) avgGain += change else avgLoss += -change
        }
        avgGain /= period
        avgLoss /= period

        for (i in (period + 1) until closes.size) {
            val change = closes[i] - closes[i - 1]
            val gain = if (change > 0) change else 0.0
            val loss = if (change < 0) -change else 0.0
            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }
}

/** Small shared indicator math so the strategies below don't each re-derive it. */
private object Indicators {
    fun wilderRsi(closes: List<Double>, period: Int): Double {
        if (closes.size < period + 1) return 50.0
        var avgGain = 0.0
        var avgLoss = 0.0
        for (i in 1..period) {
            val change = closes[i] - closes[i - 1]
            if (change > 0) avgGain += change else avgLoss += -change
        }
        avgGain /= period
        avgLoss /= period
        for (i in (period + 1) until closes.size) {
            val change = closes[i] - closes[i - 1]
            val gain = if (change > 0) change else 0.0
            val loss = if (change < 0) -change else 0.0
            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    /** Full EMA series over `closes`, seeded with an SMA of the first `period` values. */
    fun emaSeries(closes: List<Double>, period: Int): List<Double> {
        if (closes.size < period) return emptyList()
        val k = 2.0 / (period + 1)
        val out = ArrayList<Double>(closes.size)
        var prevEma = closes.take(period).average()
        out.add(prevEma)
        for (i in period until closes.size) {
            prevEma = closes[i] * k + prevEma * (1 - k)
            out.add(prevEma)
        }
        return out
    }
}

/**
 * Mean-reversion on RSI: buys when RSI dips into oversold territory and
 * turns back up, sells when it pokes into overbought territory and turns
 * back down. A SMA regime filter keeps it from fighting a strong trend.
 * Fires only on the fresh cross (first candle back over the threshold),
 * not on every candle while still oversold/overbought.
 */
class RsiReversionStrategy(
    private val rsiPeriod: Int = 14,
    private val oversold: Double = 30.0,
    private val overbought: Double = 70.0,
    private val regimePeriod: Int = 100
) : TradingStrategy {
    private var wasOversold = false
    private var wasOverbought = false

    override fun evaluate(klines: JSONArray): StrategyDecision {
        val neededCandles = maxOf(rsiPeriod, regimePeriod) + 2
        if (klines.length() < neededCandles + 1) {
            return StrategyDecision(
                Signal.HOLD,
                "Not enough closed-candle history yet (need $neededCandles candles) — waiting to build up data before evaluating any signal."
            )
        }
        val closes = (0 until klines.length() - 1).map { index ->
            klines.getJSONArray(index).getString(4).toDouble()
        }
        val rsi = TechnicalIndicators.rsi(closes, rsiPeriod).lastOrNull() ?: 50.0
        val regimeSma = if (regimePeriod > 0 && closes.size >= regimePeriod) closes.takeLast(regimePeriod).average() else null
        val regimeUptrend = regimeSma == null || closes.last() >= regimeSma
        val regimeDowntrend = regimeSma == null || closes.last() <= regimeSma
        val regimeNote = if (regimeSma != null)
            " Regime filter (SMA$regimePeriod = ${"%.2f".format(regimeSma)}): price is ${if (regimeUptrend) "above" else "below"} it."
        else ""

        val nowOversold = rsi <= oversold
        val nowOverbought = rsi >= overbought
        val buyOnBounce = wasOversold && !nowOversold
        val sellOnFade = wasOverbought && !nowOverbought
        wasOversold = nowOversold
        wasOverbought = nowOverbought

        return when {
            buyOnBounce && regimeUptrend -> StrategyDecision(
                Signal.BUY,
                "RSI ${"%.0f".format(rsi)} just bounced back up out of oversold (<= ${"%.0f".format(oversold)}) — " +
                    "buying the reversal.$regimeNote",
                rsi = rsi
            )
            sellOnFade && regimeDowntrend -> StrategyDecision(
                Signal.SELL,
                "RSI ${"%.0f".format(rsi)} just faded back down out of overbought (>= ${"%.0f".format(overbought)}) — " +
                    "selling the reversal.$regimeNote",
                rsi = rsi
            )
            else -> StrategyDecision(
                Signal.HOLD,
                "RSI ${"%.0f".format(rsi)} — waiting for a fresh bounce below ${"%.0f".format(oversold)} or fade above " +
                    "${"%.0f".format(overbought)}.$regimeNote",
                rsi = rsi
            )
        }
    }
}

/**
 * EMA crossover: faster-reacting cousin of the SMA crossover strategy
 * above, using exponential moving averages so recent candles carry more
 * weight. Same fresh-cross gating and RSI/regime confirmation.
 */
class EmaCrossoverStrategy(
    private val shortPeriod: Int = 8,
    private val longPeriod: Int = 21,
    private val rsiPeriod: Int = 14,
    private val regimePeriod: Int = 100
) : TradingStrategy {
    private var lastShortAboveLong: Boolean? = null

    override fun evaluate(klines: JSONArray): StrategyDecision {
        val neededCandles = maxOf(longPeriod, regimePeriod) + 1
        if (klines.length() < neededCandles + 1) {
            return StrategyDecision(
                Signal.HOLD,
                "Not enough closed-candle history yet (need $neededCandles candles) — waiting to build up data before evaluating any signal."
            )
        }
        val closes = (0 until klines.length() - 1).map { index ->
            klines.getJSONArray(index).getString(4).toDouble()
        }
        val shortEma = Indicators.emaSeries(closes, shortPeriod).last()
        val longEma = Indicators.emaSeries(closes, longPeriod).last()
        val shortAboveLong = shortEma > longEma
        val rsi = TechnicalIndicators.rsi(closes, rsiPeriod).lastOrNull() ?: 50.0

        val crossedUp = lastShortAboveLong == false && shortAboveLong
        val crossedDown = lastShortAboveLong == true && !shortAboveLong
        lastShortAboveLong = shortAboveLong

        val regimeSma = if (regimePeriod > 0 && closes.size >= regimePeriod) closes.takeLast(regimePeriod).average() else null
        val regimeUptrend = regimeSma == null || closes.last() >= regimeSma
        val regimeDowntrend = regimeSma == null || closes.last() <= regimeSma
        val regimeNote = if (regimeSma != null)
            " Regime filter (SMA$regimePeriod = ${"%.2f".format(regimeSma)}): price is ${if (regimeUptrend) "above" else "below"} it."
        else ""

        return when {
            crossedUp && rsi < 70.0 && regimeUptrend -> StrategyDecision(
                Signal.BUY,
                "EMA$shortPeriod (${"%.2f".format(shortEma)}) crossed above EMA$longPeriod (${"%.2f".format(longEma)}), " +
                    "RSI ${"%.0f".format(rsi)} is below overbought.$regimeNote",
                shortEma, longEma, rsi
            )
            crossedDown && rsi > 30.0 && regimeDowntrend -> StrategyDecision(
                Signal.SELL,
                "EMA$shortPeriod (${"%.2f".format(shortEma)}) crossed below EMA$longPeriod (${"%.2f".format(longEma)}), " +
                    "RSI ${"%.0f".format(rsi)} is above oversold.$regimeNote",
                shortEma, longEma, rsi
            )
            else -> StrategyDecision(
                Signal.HOLD,
                (if (shortAboveLong) "EMA$shortPeriod is above EMA$longPeriod — no fresh crossover to trade on."
                 else "EMA$shortPeriod is below EMA$longPeriod — no upward crossover yet.") + regimeNote,
                shortEma, longEma, rsi
            )
        }
    }
}

/**
 * Donchian-channel breakout: buys when price closes above the highest
 * high of the lookback window (a fresh breakout), sells when it closes
 * below the lowest low. Simple trend-following style, distinct from the
 * mean-reverting and crossover strategies above.
 */
class BreakoutStrategy(
    private val lookback: Int = 20,
    private val rsiPeriod: Int = 14
) : TradingStrategy {
    private var wasAboveUpper = false
    private var wasBelowLower = false

    override fun evaluate(klines: JSONArray): StrategyDecision {
        val neededCandles = lookback + 2
        if (klines.length() < neededCandles + 1) {
            return StrategyDecision(
                Signal.HOLD,
                "Not enough closed-candle history yet (need $neededCandles candles) — waiting to build up data before evaluating any signal."
            )
        }
        val closes = (0 until klines.length() - 1).map { index ->
            klines.getJSONArray(index).getString(4).toDouble()
        }
        val window = closes.dropLast(1).takeLast(lookback)
        val upper = window.max()
        val lower = window.min()
        val last = closes.last()
        val rsi = TechnicalIndicators.rsi(closes, rsiPeriod).lastOrNull() ?: 50.0

        val aboveUpper = last > upper
        val belowLower = last < lower
        val freshBreakUp = aboveUpper && !wasAboveUpper
        val freshBreakDown = belowLower && !wasBelowLower
        wasAboveUpper = aboveUpper
        wasBelowLower = belowLower

        return when {
            freshBreakUp -> StrategyDecision(
                Signal.BUY,
                "Price ${"%.2f".format(last)} broke above the $lookback-candle high (${"%.2f".format(upper)}) — " +
                    "fresh upside breakout. RSI ${"%.0f".format(rsi)}.",
                rsi = rsi
            )
            freshBreakDown -> StrategyDecision(
                Signal.SELL,
                "Price ${"%.2f".format(last)} broke below the $lookback-candle low (${"%.2f".format(lower)}) — " +
                    "fresh downside breakout. RSI ${"%.0f".format(rsi)}.",
                rsi = rsi
            )
            else -> StrategyDecision(
                Signal.HOLD,
                "Price ${"%.2f".format(last)} is inside the $lookback-candle range (${"%.2f".format(lower)} – " +
                    "${"%.2f".format(upper)}) — no fresh breakout.",
                rsi = rsi
            )
        }
    }
}


/**
 * Multi-indicator confluence strategy intended for short-term BTC trading.
 * It combines trend, momentum, volatility and volume rather than allowing
 * any one indicator to trigger a trade on its own.
 *
 * IMPORTANT: the strategy uses the latest CLOSED candle. The live Binance
 * WebSocket remains responsible for real-time price/exit monitoring; this
 * avoids acting on an incomplete candle that can change direction repeatedly.
 */
class IndicatorConfluenceStrategy(
    private val emaFastPeriod: Int = 20,
    private val emaSlowPeriod: Int = 50,
    private val rsiPeriod: Int = 14,
    private val bbPeriod: Int = 20,
    private val macdFast: Int = 12,
    private val macdSlow: Int = 26,
    private val macdSignal: Int = 9,
    private val stochRsiPeriod: Int = 14,
    private val atrPeriod: Int = 14,
    private val minimumScore: Int = 5
) : TradingStrategy {
    private var lastBullishReady = false
    private var lastBearishReady = false

    override fun evaluate(klines: JSONArray): StrategyDecision {
        if (klines.length() < 80) {
            return StrategyDecision(Signal.HOLD, "Building indicator history — need at least 80 candles before confluence trading is enabled.")
        }

        val endExclusive = klines.length() - 1 // drop current/incomplete candle
        val highs = ArrayList<Double>(endExclusive)
        val lows = ArrayList<Double>(endExclusive)
        val closes = ArrayList<Double>(endExclusive)
        val volumes = ArrayList<Double>(endExclusive)
        for (i in 0 until endExclusive) {
            val k = klines.getJSONArray(i)
            highs += k.getString(2).toDouble()
            lows += k.getString(3).toDouble()
            closes += k.getString(4).toDouble()
            volumes += k.getString(5).toDouble()
        }
        if (closes.size < 80) return StrategyDecision(Signal.HOLD, "Waiting for enough closed-candle history.")

        val emaFast = TechnicalIndicators.ema(closes, emaFastPeriod).lastOrNull() ?: return StrategyDecision(Signal.HOLD, "EMA${emaFastPeriod} history is not ready yet.")
        val emaSlow = TechnicalIndicators.ema(closes, emaSlowPeriod).lastOrNull() ?: return StrategyDecision(Signal.HOLD, "EMA${emaSlowPeriod} history is not ready yet.")
        val rsi = TechnicalIndicators.rsi(closes, rsiPeriod).lastOrNull() ?: 50.0
        val macd = TechnicalIndicators.macd(closes, macdFast, macdSlow, macdSignal)
        val bb = TechnicalIndicators.bollingerBands(closes, bbPeriod, 2.0)
        val stoch = TechnicalIndicators.stochRsi(closes, rsiPeriod, stochRsiPeriod)
        val atr = TechnicalIndicators.atr(highs, lows, closes, atrPeriod)
        val volumeRatio = TechnicalIndicators.volumeRatio(volumes, 20)

        val last = closes.last()
        val macdNow = macd.macdLine.lastOrNull() ?: 0.0
        val macdSignalNow = macd.signalLine.lastOrNull() ?: 0.0
        val histNow = macd.histogram.lastOrNull() ?: 0.0
        val histPrev = macd.histogram.dropLast(1).lastOrNull() ?: 0.0
        val bbMid = bb.middle.lastOrNull() ?: last
        val bbUpper = bb.upper.lastOrNull() ?: last
        val bbLower = bb.lower.lastOrNull() ?: last
        val stochNow = stoch.lastOrNull() ?: 0.5
        val atrNow = atr.lastOrNull() ?: 0.0
        val atrPct = if (last > 0) atrNow / last * 100.0 else 0.0

        var bullish = 0
        var bearish = 0
        val bull = mutableListOf<String>()
        val bear = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        if (emaFast > emaSlow) { bullish++; bull += "EMA20 above EMA50" } else { bearish++; bear += "EMA20 below EMA50" }
        if (last > emaFast) { bullish++; bull += "price above EMA20" } else { bearish++; bear += "price below EMA20" }

        if (rsi in 50.0..68.0) { bullish++; bull += "RSI ${"%.1f".format(rsi)} supports momentum" }
        else if (rsi < 35.0) { bullish++; bull += "RSI ${"%.1f".format(rsi)} is deeply oversold" }
        else if (rsi >= 70.0) { warnings += "RSI is overbought (${"%.1f".format(rsi)})" }
        else if (rsi in 32.0..50.0) { bearish++; bear += "RSI ${"%.1f".format(rsi)} weak" }

        if (macdNow > macdSignalNow && histNow >= histPrev) { bullish++; bull += "MACD momentum rising" }
        else if (macdNow < macdSignalNow && histNow <= histPrev) { bearish++; bear += "MACD momentum falling" }

        val bbPercent = if (bbUpper > bbLower) (last - bbLower) / (bbUpper - bbLower) else 0.5
        if (last > bbMid && bbPercent < 0.9) { bullish++; bull += "price in healthy upper half of Bollinger range" }
        else if (last < bbMid && bbPercent > 0.1) { bearish++; bear += "price in lower half of Bollinger range" }
        else if (last >= bbUpper) warnings += "Price is at/above the upper Bollinger Band"
        else if (last <= bbLower) warnings += "Price is at/below the lower Bollinger Band"

        if (stochNow > 0.5 && stochNow < 0.9) { bullish++; bull += "StochRSI supports upside without extreme overheating" }
        else if (stochNow < 0.2) { bullish++; bull += "StochRSI is oversold" }
        else if (stochNow < 0.5) { bearish++; bear += "StochRSI weak" }

        when {
            volumeRatio >= 1.20 -> { bullish++; bull += "volume ${"%.1f".format(volumeRatio)}× recent average" }
            volumeRatio <= 0.80 -> warnings += "volume is below recent average"
            else -> warnings += "volume is near average"
        }

        if (atrPct > 2.5) warnings += "high volatility (${"%.2f".format(atrPct)}% ATR)"
        if (atrPct > 4.0) { bullish = max(0, bullish - 1); bearish = max(0, bearish - 1) }

        val bullishReady = bullish >= minimumScore && bullish > bearish + 1 && rsi < 72.0 && last < bbUpper * 1.003
        val bearishReady = bearish >= minimumScore && bearish > bullish + 1 && rsi > 28.0 && last > bbLower * 0.997
        val quality = maxOf(0, minOf(100, maxOf(bullish, bearish) * 12 + abs(bullish - bearish) * 8))
        val freshBuy = bullishReady && !lastBullishReady
        val freshSell = bearishReady && !lastBearishReady
        lastBullishReady = bullishReady
        lastBearishReady = bearishReady

        val common = "Confluence score: bullish $bullish / bearish $bearish. RSI ${"%.1f".format(rsi)}, " +
            "StochRSI ${"%.2f".format(stochNow)}, MACD hist ${"%.4f".format(histNow)}, " +
            "BB position ${"%.0f".format(bbPercent * 100)}%, volume ${"%.1f".format(volumeRatio)}×, ATR ${"%.2f".format(atrPct)}%."

        return when {
            freshBuy -> StrategyDecision(
                Signal.BUY,
                "BUY confluence on closed candle. ${bull.joinToString(", ")}. " +
                    (if (warnings.isEmpty()) "No major warning. " else "Warnings: ${warnings.joinToString("; ")}. ") + common,
                emaFast, emaSlow, rsi, bullishScore = bullish, bearishScore = bearish, signalQuality = quality
            )
            freshSell -> StrategyDecision(
                Signal.SELL,
                "SELL confluence on closed candle. ${bear.joinToString(", ")}. " +
                    (if (warnings.isEmpty()) "No major warning. " else "Warnings: ${warnings.joinToString("; ")}. ") + common,
                emaFast, emaSlow, rsi, bullishScore = bullish, bearishScore = bearish, signalQuality = quality
            )
            else -> StrategyDecision(
                Signal.HOLD,
                "No fresh high-quality confluence. ${common} " +
                    "Bullish factors: ${bull.joinToString(", ").ifBlank { "none" }}. " +
                    "Bearish factors: ${bear.joinToString(", ").ifBlank { "none" }}." +
                    if (warnings.isEmpty()) "" else " Warnings: ${warnings.joinToString("; ")}. ",
                emaFast, emaSlow, rsi
            )
        }
    }
}

/**
 * Every strategy the app can run, plus the metadata the picker UI needs.
 * To add a new built-in strategy: implement TradingStrategy, then add one
 * line here -- the picker menu and TradingService pick it up automatically.
 */
enum class StrategyId(val displayName: String, val description: String) {
    SMA_CROSSOVER(
        "SMA Crossover + Momentum",
        "SMA(5/20) crossover confirmed by RSI, plus a fresh 2% momentum kicker. Regime-filtered by SMA100."
    ),
    RSI_REVERSION(
        "RSI Mean Reversion",
        "Buys a fresh bounce out of oversold RSI, sells a fresh fade out of overbought RSI. Regime-filtered."
    ),
    EMA_CROSSOVER(
        "EMA Crossover",
        "EMA(8/21) crossover confirmed by RSI. Reacts faster than the SMA version since EMAs weight recent candles more."
    ),
    BREAKOUT(
        "Donchian Breakout",
        "Buys a fresh close above the 20-candle high, sells a fresh close below the 20-candle low. Trend-following."
    ),
    INDICATOR_CONFLUENCE(
        "Indicator Confluence",
        "EMA20/50 + RSI14 + MACD(12,26,9) + Bollinger Bands + StochRSI + volume + ATR. Signals only on fresh closed-candle confluence."
    ),
    CUSTOM_RULE(
        "Custom Rule",
        "User-defined buy/sell conditions (RSI, EMA, SMA, PRICE comparisons combined with AND/OR) written in Dashboard > Custom Rule. See RuleEngine.kt for syntax."
    );

    companion object {
        fun fromStorageKey(key: String?): StrategyId =
            entries.firstOrNull { strategyId -> strategyId.name == key } ?: INDICATOR_CONFLUENCE
    }
}

object StrategyCatalog {
    /**
     * `context` is only needed for StrategyId.CUSTOM_RULE, to read the
     * saved buy/sell rule text out of SecureStorage at strategy-creation
     * time (TradingService creates the strategy once per service start,
     * not per evaluate() call, so the rule text is snapshotted here).
     */
    fun create(id: StrategyId, context: android.content.Context? = null): TradingStrategy = when (id) {
        StrategyId.SMA_CROSSOVER -> SmaCrossoverStrategy(
            shortPeriod = 5,
            longPeriod = 20,
            rsiPeriod = 14,
            momentumLookback = 5,
            momentumThresholdPercent = 2.0,
            regimePeriod = 100
        )
        StrategyId.RSI_REVERSION -> RsiReversionStrategy()
        StrategyId.EMA_CROSSOVER -> EmaCrossoverStrategy()
        StrategyId.BREAKOUT -> BreakoutStrategy()
        StrategyId.INDICATOR_CONFLUENCE -> IndicatorConfluenceStrategy()
        StrategyId.CUSTOM_RULE -> {
            val storage = context?.let { ctx -> SecureStorage(ctx) }
            CustomRuleStrategy(
                buyRule = storage?.getCustomBuyRule() ?: "",
                sellRule = storage?.getCustomSellRule() ?: ""
            )
        }
    }
}

/**
 * Entry strategy driven entirely by the user's RuleEngine expressions
 * (Dashboard > Custom Rule). Fires only on a fresh cross into "true",
 * same fresh-signal gating as the built-in strategies, so it doesn't
 * re-fire BUY every ~4s poll while the condition stays true.
 */
class CustomRuleStrategy(
    private val buyRule: String,
    private val sellRule: String
) : TradingStrategy {
    private var buyWasTrue = false
    private var sellWasTrue = false

    override fun evaluate(klines: JSONArray): StrategyDecision {
        if (buyRule.isBlank() && sellRule.isBlank()) {
            return StrategyDecision(
                Signal.HOLD,
                "No custom rule configured yet — add a buy and/or sell rule in Dashboard > Custom Rule."
            )
        }
        val buyNow = buyRule.isNotBlank() && RuleEngine.evaluate(buyRule, klines)
        val sellNow = sellRule.isNotBlank() && RuleEngine.evaluate(sellRule, klines)
        val freshBuy = buyNow && !buyWasTrue
        val freshSell = sellNow && !sellWasTrue
        buyWasTrue = buyNow
        sellWasTrue = sellNow

        return when {
            freshBuy -> StrategyDecision(Signal.BUY, "Custom buy rule matched: \"$buyRule\".")
            freshSell -> StrategyDecision(Signal.SELL, "Custom sell rule matched: \"$sellRule\".")
            else -> StrategyDecision(
                Signal.HOLD,
                "Waiting — buy rule (\"${buyRule.ifBlank { "none set" }}\") and sell rule " +
                    "(\"${sellRule.ifBlank { "none set" }}\") not currently matched."
            )
        }
    }
}

/**
 * Tracks an open position and decides EXITS independently of the entry
 * strategy. Trailing is cost-aware: it will not fire below modeled net
 * break-even (fees + TDS + tax), so a +2.0% peak / 0.8pp giveback cannot
 * lock in a net loss under the bot's own cost model.
 */
class PositionTracker(
    private var stopLossPercent: Double = 0.007,
    private var takeProfitPercent: Double = 0.025,
    private var trailingActivationPercent: Double = 0.005,
    private val trailingGivebackPercent: Double = 0.003,
    private val minNetExitPercent: Double = CostModel.breakEvenMoveFraction()
) {
    var inPosition: Boolean = false
        private set
    var entryPrice: Double = 0.0
        private set
    var quantity: Double = 0.0
        private set
    private var peakProfitPercent: Double = 0.0
    private var entryTimestampMs: Long = 0L
    private var manualTrade: Boolean = false

    fun open(price: Double, qty: Double, nowMs: Long = System.currentTimeMillis()) {
        manualTrade = false
        inPosition = true
        entryPrice = price
        quantity = qty
        peakProfitPercent = 0.0
        entryTimestampMs = nowMs
    }

    fun openWithTargets(
        price: Double,
        qty: Double,
        stopLossPercent: Double,
        takeProfitPercent: Double,
        nowMs: Long = System.currentTimeMillis(),
        manualTrade: Boolean = true
    ) {
        this.stopLossPercent = stopLossPercent.coerceIn(0.001, 0.50)
        this.takeProfitPercent = takeProfitPercent.coerceIn(0.0, 2.0)
        this.manualTrade = manualTrade
        this.inPosition = true
        this.entryPrice = price
        this.quantity = qty
        this.peakProfitPercent = 0.0
        this.entryTimestampMs = nowMs
    }

    fun close() {
        inPosition = false
        entryPrice = 0.0
        quantity = 0.0
        peakProfitPercent = 0.0
        entryTimestampMs = 0L
        manualTrade = false
    }

    fun reduceQuantity(newQuantity: Double) {
        quantity = newQuantity
        if (quantity <= 0.0) close()
    }

    fun snapshot(): PositionSnapshot? =
        if (inPosition) PositionSnapshot(entryPrice, quantity, entryTimestampMs, peakProfitPercent, stopLossPercent, takeProfitPercent, trailingActivationPercent, manualTrade) else null

    fun restore(snap: PositionSnapshot) {
        inPosition = true
        entryPrice = snap.entryPrice
        quantity = snap.quantity
        entryTimestampMs = snap.entryTimestampMs
        peakProfitPercent = snap.peakProfitPercent
        stopLossPercent = snap.stopLossPercent
        takeProfitPercent = snap.takeProfitPercent
        trailingActivationPercent = snap.trailingActivationPercent
        manualTrade = snap.manualTrade
    }

    fun holdDurationMs(nowMs: Long = System.currentTimeMillis()): Long =
        if (inPosition) nowMs - entryTimestampMs else 0L

    /** Raw entry timestamp (ms since epoch), 0 if no open position. */
    fun entryTimeMs(): Long = if (inPosition) entryTimestampMs else 0L

    fun isManualTrade(): Boolean = inPosition && manualTrade

    /** The exact price at which the hard stop-loss will trigger an exit. */
    fun stopLossPriceLevel(): Double =
        if (inPosition && entryPrice > 0) entryPrice * (1 - stopLossPercent) else 0.0

    /** The exact price at which take-profit will trigger an exit. */
    fun takeProfitPriceLevel(): Double =
        if (inPosition && entryPrice > 0) entryPrice * (1 + takeProfitPercent) else 0.0

    /** The exact price at which the trailing stop arms (starts protecting profit). */
    fun trailingArmPriceLevel(): Double =
        if (inPosition && entryPrice > 0) entryPrice * (1 + trailingActivationPercent) else 0.0

    fun checkExit(currentPrice: Double): ExitReason {
        if (!inPosition || entryPrice <= 0) return ExitReason.NONE

        val currentProfitPercent = (currentPrice - entryPrice) / entryPrice
        if (currentProfitPercent > peakProfitPercent) peakProfitPercent = currentProfitPercent

        val givebackFromPeak = peakProfitPercent - currentProfitPercent
        val trailingActive = peakProfitPercent >= trailingActivationPercent
        val aboveModeledBreakEven = currentProfitPercent >= minNetExitPercent

        return when {
            currentProfitPercent <= -stopLossPercent -> ExitReason.STOP_LOSS
            takeProfitPercent > 0.0 && currentProfitPercent >= takeProfitPercent -> ExitReason.TAKE_PROFIT
            trailingActive && givebackFromPeak >= trailingGivebackPercent && aboveModeledBreakEven ->
                ExitReason.TRAILING_STOP
            else -> ExitReason.NONE
        }
    }

    fun statusReason(currentPrice: Double): String {
        if (!inPosition || entryPrice <= 0) return "No open position."
        val currentProfitPercent = (currentPrice - entryPrice) / entryPrice * 100.0
        val peak = peakProfitPercent * 100.0
        val stopAt = -stopLossPercent * 100.0
        val bePct = minNetExitPercent * 100.0
        return if (peakProfitPercent >= trailingActivationPercent) {
            val trailStopLevel = peak - trailingGivebackPercent * 100.0
            val floorNote = if (trailStopLevel / 100.0 < minNetExitPercent)
                " Trail floor is modeled break-even (+${"%.2f".format(bePct)}%) — will not lock a net loss."
            else ""
            "Trailing stop is active: currently ${fmtPct(currentProfitPercent)} vs entry (peak was ${fmtPct(peak)}). " +
                "Will exit if profit falls back to ${"%.2f".format(trailStopLevel)}%.$floorNote Holding while the peak keeps rising."
        } else {
            "Holding: currently ${fmtPct(currentProfitPercent)} vs entry. Trailing stop arms once profit reaches " +
                "+${"%.2f".format(trailingActivationPercent * 100)}%; hard stop-loss exits at ${"%.2f".format(stopAt)}%."
        }
    }

    fun exitReasonText(reason: ExitReason, currentPrice: Double): String {
        if (entryPrice <= 0) return ""
        val currentProfitPercent = (currentPrice - entryPrice) / entryPrice * 100.0
        val peak = peakProfitPercent * 100.0
        return when (reason) {
            ExitReason.STOP_LOSS -> "Hard stop-loss triggered: down ${fmtPct(currentProfitPercent)} vs entry, at or " +
                "beyond the ${"%.2f".format(-stopLossPercent * 100)}% limit. Closing to cap the loss."
            ExitReason.TRAILING_STOP -> "Trailing stop triggered: profit pulled back from a peak of ${fmtPct(peak)} to " +
                "${fmtPct(currentProfitPercent)}, giving back ${"%.2f".format(trailingGivebackPercent * 100)} points " +
                "from the peak (still at/above modeled break-even). Locking in the gain before it erodes further."
            ExitReason.REVERSAL_SIGNAL -> "Strategy signal reversed to SELL after the minimum hold time elapsed — " +
                "closing at ${fmtPct(currentProfitPercent)} vs entry rather than holding against the new signal."
            ExitReason.TAKE_PROFIT -> if (manualTrade) "Manual take-profit target reached at ${fmtPct(currentProfitPercent)} vs entry. Auto-exit is enabled, so the trade is closing now." else "Take-profit target reached at ${fmtPct(currentProfitPercent)} vs entry. Closing automatically."
            ExitReason.MANUAL_CLOSE -> "Position closed manually at ${fmtPct(currentProfitPercent)} vs entry."
            ExitReason.NONE -> ""
        }
    }

    private fun fmtPct(v: Double): String = (if (v >= 0) "+" else "") + "%.2f".format(v) + "%"
}

/**
 * India crypto cost model (planning estimates, not tax advice).
 */
object CostModel {
    const val FEE_RATE_PER_SIDE = 0.001
    const val TDS_RATE_ON_SELL = 0.01
    const val FLAT_TAX_RATE_ON_GAINS = 0.30
    /** Planning assumption for live reporting / trailing floor. Live fills already include real slippage. */
    const val SLIPPAGE_RATE_PER_SIDE = 0.0002

    /**
     * Favorable move (fraction of entry) needed for net P/L >= 0 after
     * 0.1%/side fee, 1% TDS on sell, 30% tax on gain, and assumed slippage.
     */
    fun breakEvenMoveFraction(includeSlippage: Boolean = true): Double {
        var lo = 0.0
        var hi = 0.2
        repeat(48) {
            val mid = (lo + hi) / 2.0
            if (netPnlForUnitCapital(mid, includeSlippage) >= 0.0) hi = mid else lo = mid
        }
        return hi
    }

    fun netPnlForUnitCapital(moveFraction: Double, includeSlippage: Boolean): Double {
        val s = if (includeSlippage) SLIPPAGE_RATE_PER_SIDE else 0.0
        val entry = 1.0 * (1.0 + s)
        val exit = (1.0 + moveFraction) * (1.0 - s)
        val qty = 1.0 / entry
        val gross = (exit - entry) * qty
        val fees = (entry * qty + exit * qty) * FEE_RATE_PER_SIDE
        val tds = exit * qty * TDS_RATE_ON_SELL
        val tax = if (gross > 0) gross * FLAT_TAX_RATE_ON_GAINS else 0.0
        return gross - fees - tds - tax
    }

    /** Pure estimate for the current sell-now display; it never mutates trade statistics. */
    fun previewSellNow(entryPrice: Double, currentPrice: Double, quantity: Double): TradeCost {
        val grossPnl = (currentPrice - entryPrice) * quantity
        val buyValue = entryPrice * quantity
        val sellValue = currentPrice * quantity
        val exchangeFees = (buyValue + sellValue) * FEE_RATE_PER_SIDE
        val tds = sellValue * TDS_RATE_ON_SELL
        val taxOnGain = if (grossPnl > 0) grossPnl * FLAT_TAX_RATE_ON_GAINS else 0.0
        return TradeCost(grossPnl, exchangeFees, tds, taxOnGain, grossPnl - exchangeFees - tds - taxOnGain)
    }
}

data class TradeCost(
    val grossPnl: Double,
    val exchangeFees: Double,
    val tds: Double,
    val taxOnGain: Double,
    val netPnl: Double
)

class TradeStats {
    var totalTrades: Int = 0
        private set
    var wins: Int = 0
        private set
    var losses: Int = 0
        private set
    var totalWinPercent: Double = 0.0
        private set
    var totalLossPercent: Double = 0.0
        private set
    var totalGrossPnl: Double = 0.0
        private set
    var totalExchangeFees: Double = 0.0
        private set
    var totalTds: Double = 0.0
        private set
    var totalTaxEstimate: Double = 0.0
        private set
    var totalNetPnl: Double = 0.0
        private set

    fun restore(
        totalTrades: Int,
        wins: Int,
        losses: Int,
        totalWinPercent: Double,
        totalLossPercent: Double,
        totalGrossPnl: Double,
        totalExchangeFees: Double,
        totalTds: Double,
        totalTaxEstimate: Double,
        totalNetPnl: Double
    ) {
        this.totalTrades = totalTrades
        this.wins = wins
        this.losses = losses
        this.totalWinPercent = totalWinPercent
        this.totalLossPercent = totalLossPercent
        this.totalGrossPnl = totalGrossPnl
        this.totalExchangeFees = totalExchangeFees
        this.totalTds = totalTds
        this.totalTaxEstimate = totalTaxEstimate
        this.totalNetPnl = totalNetPnl
    }

    fun recordTrade(entryPrice: Double, exitPrice: Double, quantity: Double): TradeCost {
        val changePercent = (exitPrice - entryPrice) / entryPrice * 100.0
        totalTrades++
        if (changePercent >= 0) {
            wins++
            totalWinPercent += changePercent
        } else {
            losses++
            totalLossPercent += changePercent
        }

        val cost = CostModel.previewSellNow(entryPrice, exitPrice, quantity)

        totalGrossPnl += cost.grossPnl
        totalExchangeFees += cost.exchangeFees
        totalTds += cost.tds
        totalTaxEstimate += cost.taxOnGain
        totalNetPnl += cost.netPnl

        return cost
    }

    fun winRatePercent(): Double =
        if (totalTrades == 0) 0.0 else (wins.toDouble() / totalTrades) * 100.0

    fun averageWinPercent(): Double = if (wins == 0) 0.0 else totalWinPercent / wins
    fun averageLossPercent(): Double = if (losses == 0) 0.0 else totalLossPercent / losses
}

/**
 * Risk manager with persistent daily state, consecutive-loss pause,
 * and max trades/day. Daily-loss lock does not reset on process restart
 * if the calendar day still matches.
 */
class RiskManager(
    private val dailyTradingBudgetUsd: Double = 10.0,
    private val maxDailyLossPercent: Double = 0.03,
    private val maxConsecutiveLosses: Int = 3,
    private val maxTradesPerDay: Int = 8
) {
    private var dayStartEquity: Double? = null
    private var currentEquity: Double = 0.0
    private var currentFreeCash: Double = 0.0
    private var remainingBudgetUsd: Double = dailyTradingBudgetUsd
    private var dailyNotionalUsedUsd: Double = 0.0
    private var dailyStopLocked: Boolean = false
    private var consecutiveLosses: Int = 0
    private var tradesToday: Int = 0
    var lastExitMs: Long = 0L
        private set

    fun updateBalance(equity: Double, freeCash: Double) {
        if (dayStartEquity == null) {
            dayStartEquity = equity
            remainingBudgetUsd = (dailyTradingBudgetUsd - dailyNotionalUsedUsd).coerceAtLeast(0.0).coerceAtMost(equity)
        }
        currentEquity = equity
        currentFreeCash = freeCash
        if (dailyLossLimitBreached()) dailyStopLocked = true
    }

    fun recordEntryNotional(notionalUsd: Double) {
        if (notionalUsd <= 0.0) return
        dailyNotionalUsedUsd += notionalUsd
        remainingBudgetUsd = (dailyTradingBudgetUsd - dailyNotionalUsedUsd).coerceAtLeast(0.0)
    }

    fun recordTradeResult(netPnl: Double, nowMs: Long = System.currentTimeMillis()) {
        tradesToday++
        lastExitMs = nowMs
        if (netPnl < 0) consecutiveLosses++ else consecutiveLosses = 0
        if (dailyLossLimitBreached()) dailyStopLocked = true
    }

    fun remainingBudget(): Double = remainingBudgetUsd
    fun dailyNotionalUsed(): Double = dailyNotionalUsedUsd
    fun isDailyStopLocked(): Boolean = dailyStopLocked
    fun consecutiveLosses(): Int = consecutiveLosses
    fun tradesToday(): Int = tradesToday
    fun maxTradesPerDayLimit(): Int = maxTradesPerDay
    fun maxConsecutiveLossesLimit(): Int = maxConsecutiveLosses

    fun tradeQuantity(price: Double): Double {
        if (price <= 0.0) return 0.0
        val tradeValue = remainingBudgetUsd.coerceAtMost(currentFreeCash)
        return tradeValue / price
    }

    fun dailyLossLimitBreached(): Boolean {
        val start = dayStartEquity ?: return dailyStopLocked
        if (start <= 0) return dailyStopLocked
        val lossPercent = (start - currentEquity) / start
        return dailyStopLocked || lossPercent >= maxDailyLossPercent
    }

    fun newEntryBlockReason(nowMs: Long, entryCooldownMs: Long): String? {
        if (dailyStopLocked || dailyLossLimitBreached()) return "Daily loss lock is active — new entries blocked until tomorrow's reset."
        if (dailyNotionalUsedUsd >= dailyTradingBudgetUsd - 1e-9) return "Daily trading budget exhausted ($%.2f used of $%.2f).".format(dailyNotionalUsedUsd, dailyTradingBudgetUsd)
        if (consecutiveLosses >= maxConsecutiveLosses) return "Paused after $consecutiveLosses consecutive losses (limit $maxConsecutiveLosses)."
        if (tradesToday >= maxTradesPerDay) return "Max trades for today reached ($tradesToday/$maxTradesPerDay)."
        if (lastExitMs > 0L && nowMs - lastExitMs < entryCooldownMs) {
            val waitSec = (entryCooldownMs - (nowMs - lastExitMs)) / 1000
            return "Entry cooldown after last exit (${waitSec}s remaining)."
        }
        return null
    }

    fun resetDay(equity: Double, freeCash: Double) {
        dayStartEquity = equity
        currentEquity = equity
        currentFreeCash = freeCash
        dailyNotionalUsedUsd = 0.0
        remainingBudgetUsd = dailyTradingBudgetUsd.coerceAtMost(equity)
        dailyStopLocked = false
        consecutiveLosses = 0
        tradesToday = 0
        lastExitMs = 0L
    }

    fun snapshot(tradingDay: String): DailyRiskSnapshot = DailyRiskSnapshot(
        tradingDay = tradingDay,
        dayStartEquity = dayStartEquity ?: currentEquity,
        remainingBudgetUsd = remainingBudgetUsd,
        dailyStopLocked = dailyStopLocked,
        consecutiveLosses = consecutiveLosses,
        tradesToday = tradesToday,
        lastExitMs = lastExitMs,
        dailyNotionalUsedUsd = dailyNotionalUsedUsd
    )

    fun restore(snap: DailyRiskSnapshot, today: String, equity: Double, freeCash: Double) {
        if (snap.tradingDay == today) {
            dayStartEquity = snap.dayStartEquity
            dailyNotionalUsedUsd = if (snap.dailyNotionalUsedUsd.isNaN()) {
                // Backward compatibility: older snapshots stored only remainingBudgetUsd.
                (dailyTradingBudgetUsd - snap.remainingBudgetUsd).coerceAtLeast(0.0)
            } else snap.dailyNotionalUsedUsd.coerceAtLeast(0.0)
            remainingBudgetUsd = (dailyTradingBudgetUsd - dailyNotionalUsedUsd).coerceAtLeast(0.0)
            dailyStopLocked = snap.dailyStopLocked
            consecutiveLosses = snap.consecutiveLosses
            tradesToday = snap.tradesToday
            lastExitMs = snap.lastExitMs
            currentEquity = equity
            currentFreeCash = freeCash
        } else {
            resetDay(equity, freeCash)
        }
    }
}

/**
 * Rolling fixed-size session window (e.g. 2 hours), independent of the calendar-day
 * RiskManager above. Adds its own USD budget and an optional profit target.
 *
 * IMPORTANT: this does NOT force trades to hit the target. It cannot -- no code can
 * guarantee a market outcome. What it does is the safe direction of the idea: once the
 * window nets >= the profit target, new entries pause for the rest of that window so the
 * gain is locked in instead of being risked chasing more. It also pauses new entries if
 * the window's losses reach the session loss cap. It never widens a stop-loss, skips the
 * fill-verification step, or increases position size to "try harder" for profit -- doing
 * that would just mean overriding the exact protections this bot already has.
 *
 * Existing per-trade stop-loss/take-profit and the daily RiskManager still apply on top of
 * this; this class only ever adds an extra, stricter gate.
 */
class SessionRiskManager(
    private val windowMs: Long = 2 * 60 * 60 * 1000L,
    private val sessionBudgetUsd: Double = 10.0,
    private val sessionProfitTargetUsd: Double? = 1.0,
    private val sessionMaxLossUsd: Double = 10.0
) {
    private var windowStartMs: Long = 0L
    private var windowNetPnl: Double = 0.0
    private var windowNotionalUsedUsd: Double = 0.0
    private var windowLockReason: String? = null

    private fun rollWindowIfNeeded(nowMs: Long) {
        if (windowStartMs == 0L || nowMs - windowStartMs >= windowMs) {
            windowStartMs = nowMs
            windowNetPnl = 0.0
            windowNotionalUsedUsd = 0.0
            windowLockReason = null
        }
    }

    fun restore(snapshot: SessionRiskSnapshot, nowMs: Long = System.currentTimeMillis()) {
        if (snapshot.windowStartMs > 0L && nowMs - snapshot.windowStartMs < windowMs) {
            windowStartMs = snapshot.windowStartMs
            windowNetPnl = snapshot.windowNetPnl
            windowNotionalUsedUsd = snapshot.windowNotionalUsedUsd.coerceAtLeast(0.0)
            windowLockReason = snapshot.windowLockReason
        } else {
            rollWindowIfNeeded(nowMs)
        }
    }

    fun snapshot(nowMs: Long = System.currentTimeMillis()): SessionRiskSnapshot {
        rollWindowIfNeeded(nowMs)
        return SessionRiskSnapshot(windowStartMs, windowNetPnl, windowNotionalUsedUsd, windowLockReason)
    }

    fun recordEntryNotional(notionalUsd: Double, nowMs: Long = System.currentTimeMillis()) {
        rollWindowIfNeeded(nowMs)
        if (notionalUsd > 0.0) windowNotionalUsedUsd += notionalUsd
    }

    fun recordTradeResult(netPnl: Double, nowMs: Long = System.currentTimeMillis()) {
        rollWindowIfNeeded(nowMs)
        windowNetPnl += netPnl
        if (windowLockReason == null) {
            windowLockReason = when {
                sessionProfitTargetUsd != null && windowNetPnl >= sessionProfitTargetUsd ->
                    "Session target hit ($%.2f this window) — entries paused until next %d-min window.".format(windowNetPnl, windowMs / 60000)
                windowNetPnl <= -sessionMaxLossUsd ->
                    "Session loss cap hit ($%.2f this window) — entries paused until next %d-min window.".format(windowNetPnl, windowMs / 60000)
                else -> null
            }
        }
    }

    fun entryBlockReason(nowMs: Long = System.currentTimeMillis()): String? {
        rollWindowIfNeeded(nowMs)
        if (windowLockReason != null) return windowLockReason
        if (windowNotionalUsedUsd >= sessionBudgetUsd - 1e-9) {
            return "Session trading budget exhausted ($%.2f used of $%.2f).".format(windowNotionalUsedUsd, sessionBudgetUsd)
        }
        return null
    }

    fun capTradeValueUsd(proposedUsd: Double, nowMs: Long = System.currentTimeMillis()): Double {
        rollWindowIfNeeded(nowMs)
        val remaining = (sessionBudgetUsd - windowNotionalUsedUsd).coerceAtLeast(0.0)
        return proposedUsd.coerceAtMost(remaining)
    }

    fun windowNetPnl(nowMs: Long = System.currentTimeMillis()): Double { rollWindowIfNeeded(nowMs); return windowNetPnl }
    fun windowRemainingMs(nowMs: Long = System.currentTimeMillis()): Long {
        rollWindowIfNeeded(nowMs)
        return (windowMs - (nowMs - windowStartMs)).coerceAtLeast(0L)
    }
}
