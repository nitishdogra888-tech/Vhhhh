package com.example.tradingbot

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores the Binance API key/secret encrypted-at-rest on the device, using
 * Android's Keystore-backed EncryptedSharedPreferences. This keeps the
 * secret out of plain-text files, but keep in mind: anyone with root access
 * or physical unlocked access to the device could still potentially extract
 * it while the app is running. Don't reuse these keys anywhere sensitive.
 */
class SecureStorage(context: Context) {

    private val prefs: SharedPreferences

    init {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        prefs = EncryptedSharedPreferences.create(
            context,
            "trading_bot_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // Testnet and Live credentials are stored under separate keys so
    // switching TradingMode can never accidentally trade one environment
    // with the other's key. The unqualified methods below default to
    // Testnet for backward compatibility with older call sites.
    private fun keyPrefix(mode: TradingMode): String =
        if (mode == TradingMode.LIVE) "live_" else "api_"

    fun saveCredentials(apiKey: String, apiSecret: String, mode: TradingMode = TradingMode.TESTNET) {
        prefs.edit()
            .putString("${keyPrefix(mode)}key", apiKey)
            .putString("${keyPrefix(mode)}secret", apiSecret)
            .apply()
    }

    fun getApiKey(mode: TradingMode = TradingMode.TESTNET): String =
        prefs.getString("${keyPrefix(mode)}key", "") ?: ""

    fun getApiSecret(mode: TradingMode = TradingMode.TESTNET): String =
        prefs.getString("${keyPrefix(mode)}secret", "") ?: ""

    fun clearCredentials(mode: TradingMode = TradingMode.TESTNET) {
        prefs.edit()
            .remove("${keyPrefix(mode)}key")
            .remove("${keyPrefix(mode)}secret")
            .remove("xai_api_key")
            .apply()
    }

    /**
     * Alpaca market data credentials for the scanner feature, stored the
     * same way as the Binance keys above — encrypted at rest, never
     * hardcoded in source.
     */
    fun saveAlpacaCredentials(keyId: String, secretKey: String) {
        prefs.edit()
            .putString("alpaca_key_id", keyId)
            .putString("alpaca_secret_key", secretKey)
            .apply()
    }

    fun getAlpacaKeyId(): String = prefs.getString("alpaca_key_id", "") ?: ""

    fun getAlpacaSecretKey(): String = prefs.getString("alpaca_secret_key", "") ?: ""

    fun hasAlpacaCredentials(): Boolean =
        getAlpacaKeyId().isNotBlank() && getAlpacaSecretKey().isNotBlank()

    fun clearAlpacaCredentials() {
        prefs.edit()
            .remove("alpaca_key_id")
            .remove("alpaca_secret_key")
            .apply()
    }

    /**
     * User-adjustable trading settings (daily budget + risk thresholds).
     * Not secrets, but kept in the same encrypted store for simplicity and
     * so they survive app restarts alongside the credentials. Defaults here
     * mirror TradingService's built-in defaults so a first-ever launch (no
     * saved settings yet) behaves exactly as before this screen existed.
     */
    fun saveTradingSettings(
        dailyBudgetUsd: Double,
        stopLossPercent: Double,
        trailingActivationPercent: Double,
        takeProfitPercent: Double = TradingService.DEFAULT_TAKE_PROFIT_PERCENT
    ) {
        prefs.edit()
            .putFloat("daily_budget_usd", dailyBudgetUsd.toFloat())
            .putFloat("stop_loss_percent", stopLossPercent.toFloat())
            .putFloat("trailing_activation_percent", trailingActivationPercent.toFloat())
            .putFloat("take_profit_percent", takeProfitPercent.toFloat())
            .apply()
    }

    fun getDailyBudgetUsd(): Double =
        prefs.getFloat("daily_budget_usd", TradingService.DAILY_TRADING_BUDGET_USD.toFloat()).toDouble()

    fun getStopLossPercent(): Double =
        prefs.getFloat("stop_loss_percent", TradingService.DEFAULT_STOP_LOSS_PERCENT.toFloat()).toDouble()

    fun getTrailingActivationPercent(): Double =
        prefs.getFloat("trailing_activation_percent", TradingService.DEFAULT_TRAILING_ACTIVATION_PERCENT.toFloat()).toDouble()

    fun saveTakeProfitPercent(value: Double) = prefs.edit().putFloat("take_profit_percent", value.toFloat()).apply()

    fun getTakeProfitPercent(): Double =
        prefs.getFloat("take_profit_percent", TradingService.DEFAULT_TAKE_PROFIT_PERCENT.toFloat()).toDouble()

    /**
     * Rolling-window session risk gate (see SessionRiskManager in
     * Strategy.kt). Independent of the daily budget above -- this caps
     * how much of that budget can move within one 2-hour window and pauses
     * new AUTO-BUY entries once the window's net P&L clears the profit
     * target or breaches the loss cap. Defaults mirror TradingService's
     * built-in constants so an upgrade with no saved value yet behaves
     * exactly as before this screen existed.
     */
    fun saveSessionRiskSettings(
        sessionBudgetUsd: Double,
        sessionProfitTargetUsd: Double,
        sessionMaxLossUsd: Double
    ) {
        prefs.edit()
            .putFloat("session_budget_usd", sessionBudgetUsd.toFloat())
            .putFloat("session_profit_target_usd", sessionProfitTargetUsd.toFloat())
            .putFloat("session_max_loss_usd", sessionMaxLossUsd.toFloat())
            .apply()
    }

    fun getSessionBudgetUsd(): Double =
        prefs.getFloat("session_budget_usd", TradingService.SESSION_BUDGET_USD.toFloat()).toDouble()

    fun getSessionProfitTargetUsd(): Double =
        prefs.getFloat("session_profit_target_usd", TradingService.SESSION_PROFIT_TARGET_USD.toFloat()).toDouble()

    fun getSessionMaxLossUsd(): Double =
        prefs.getFloat("session_max_loss_usd", TradingService.SESSION_MAX_LOSS_USD.toFloat()).toDouble()

    fun saveManualTradeAmountUsd(value: Double) = prefs.edit().putFloat("manual_trade_amount_usd", value.toFloat()).apply()

    fun getManualTradeAmountUsd(): Double =
        prefs.getFloat("manual_trade_amount_usd", TradingService.DAILY_TRADING_BUDGET_USD.toFloat()).toDouble()

    fun saveAutoMode(enabled: Boolean) = prefs.edit().putBoolean("auto_mode", enabled).apply()

    fun getAutoMode(): Boolean = prefs.getBoolean("auto_mode", true)

    fun saveProtectOpenTrade(enabled: Boolean) = prefs.edit().putBoolean("auto_exit", enabled).apply()

    fun getProtectOpenTrade(): Boolean = prefs.getBoolean("auto_exit", true)

    /**
     * Which built-in entry strategy (see StrategyId in Strategy.kt) the bot
     * should run. Stored by enum name so adding new strategies later never
     * breaks an old saved value -- fromStorageKey() falls back to the
     * default if the stored name is missing or unrecognized.
     */
    fun saveStrategyId(id: StrategyId) {
        prefs.edit().putString("strategy_id", id.name).apply()
    }

    fun getStrategyId(): StrategyId =
        StrategyId.fromStorageKey(prefs.getString("strategy_id", null))

    /**
     * User-authored buy/sell conditions for StrategyId.CUSTOM_RULE, parsed
     * and evaluated by RuleEngine (see RuleEngine.kt). Stored as plain
     * text; DashboardActivity validates with RuleEngine.validate() before
     * ever calling these save methods, but an empty/invalid string is
     * still safe here -- CustomRuleStrategy treats a blank rule as "never
     * fires" rather than crashing.
     */
    fun saveCustomBuyRule(rule: String) {
        prefs.edit().putString("custom_buy_rule", rule).apply()
    }

    fun getCustomBuyRule(): String = prefs.getString("custom_buy_rule", "") ?: ""

    fun saveCustomSellRule(rule: String) {
        prefs.edit().putString("custom_sell_rule", rule).apply()
    }

    fun getCustomSellRule(): String = prefs.getString("custom_sell_rule", "") ?: ""

    fun saveXaiApiKey(apiKey: String) {
        prefs.edit().putString("xai_api_key", apiKey.trim()).apply()
    }

    fun getXaiApiKey(): String = prefs.getString("xai_api_key", "") ?: ""

    fun hasXaiApiKey(): Boolean = getXaiApiKey().isNotBlank()

    fun clearXaiApiKey() {
        prefs.edit().remove("xai_api_key").apply()
    }

    /**
     * Keys/settings for the AI vision-analysis subsystem (AiSignalAdvisor).
     * OpenAI is the primary provider for the automated capture cycle; xAI,
     * Anthropic, and a custom OpenAI-compatible endpoint are optional
     * fallbacks tried in order by evaluateWithFallback() when the manual
     * "upload a chart" or automated-event paths run.
     */
    fun saveOpenAiApiKey(apiKey: String) {
        prefs.edit().putString("openai_api_key", apiKey.trim()).apply()
    }

    fun getOpenAiApiKey(): String = prefs.getString("openai_api_key", "") ?: ""

    fun saveAnthropicApiKey(apiKey: String) {
        prefs.edit().putString("anthropic_api_key", apiKey.trim()).apply()
    }

    fun getAnthropicApiKey(): String = prefs.getString("anthropic_api_key", "") ?: ""

    fun saveCustomVisionEndpoint(url: String) {
        prefs.edit().putString("custom_vision_endpoint", url.trim()).apply()
    }

    fun getCustomVisionEndpoint(): String = prefs.getString("custom_vision_endpoint", "") ?: ""

    fun saveAiAutoSignalEnabled(enabled: Boolean) =
        prefs.edit().putBoolean("ai_auto_signal_enabled", enabled).apply()

    fun getAiAutoSignalEnabled(): Boolean = prefs.getBoolean("ai_auto_signal_enabled", false)

    /** Minimum confidence (0-100) before the auto-signal path raises a notification. */
    fun saveAiAutoSignalThreshold(percent: Double) =
        prefs.edit().putFloat("ai_auto_signal_threshold", percent.toFloat()).apply()

    fun getAiAutoSignalThreshold(): Double =
        prefs.getFloat("ai_auto_signal_threshold", 85f).toDouble()

    /**
     * Which provider most recently answered a vision-analysis request, and
     * any warning collected along the way (e.g. other configured providers
     * that failed before the one that succeeded). Shown on the AI tab's
     * status line so the user knows what actually answered.
     */
    fun saveAiProviderStatus(provider: String, state: String, warning: String = "") {
        prefs.edit()
            .putString("ai_provider_status", "$provider — $state")
            .putString("ai_credit_warning", warning)
            .apply()
    }

    fun getAiProviderStatus(): String = prefs.getString("ai_provider_status", "None yet") ?: "None yet"

    fun getAiCreditWarning(): String = prefs.getString("ai_credit_warning", "") ?: ""

    // Separate from the existing notification-only AI Auto-Signal switch.
    // This gate is opt-in and can only approve a strategy BUY; hard risk
    // controls remain authoritative.
    fun saveAiTradeGateEnabled(enabled: Boolean) =
        prefs.edit().putBoolean("ai_trade_gate_enabled", enabled).apply()

    fun getAiTradeGateEnabled(): Boolean = prefs.getBoolean("ai_trade_gate_enabled", false)

    fun saveAiTradeGateThreshold(percent: Double) =
        prefs.edit().putFloat("ai_trade_gate_threshold", percent.toFloat()).apply()

    fun getAiTradeGateThreshold(): Double = prefs.getFloat("ai_trade_gate_threshold", 70f).toDouble()

    fun saveTradingViewGateEnabled(enabled: Boolean) =
        prefs.edit().putBoolean("tradingview_gate_enabled", enabled).apply()

    fun getTradingViewGateEnabled(): Boolean = prefs.getBoolean("tradingview_gate_enabled", false)

    fun saveTradingViewRelayUrl(url: String) =
        prefs.edit().putString("tradingview_relay_url", url.trim()).apply()

    fun getTradingViewRelayUrl(): String = prefs.getString("tradingview_relay_url", "") ?: ""

    fun saveTradingViewRelayToken(token: String) =
        prefs.edit().putString("tradingview_relay_token", token.trim()).apply()

    fun getTradingViewRelayToken(): String = prefs.getString("tradingview_relay_token", "") ?: ""

    fun saveTradingViewMaxAgeMinutes(minutes: Int) =
        prefs.edit().putInt("tradingview_max_age_minutes", minutes.coerceIn(1, 120)).apply()

    fun getTradingViewMaxAgeMinutes(): Int = prefs.getInt("tradingview_max_age_minutes", 5)
}
