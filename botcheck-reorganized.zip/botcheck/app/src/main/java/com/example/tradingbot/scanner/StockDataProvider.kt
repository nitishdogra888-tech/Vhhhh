package com.example.tradingbot.scanner

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

/**
 * A single daily/intraday price bar.
 */
data class Bar(
    val timestamp: Long, // epoch seconds
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

/**
 * Abstraction over a market data source so the scanner can work against
 * Alpaca (with an API key) or fall back to Yahoo Finance's free chart API.
 */
interface StockDataProvider {
    /**
     * Fetch the most recent [limit] daily bars for [symbol], oldest first.
     */
    suspend fun getDailyBars(symbol: String, limit: Int = 100): List<Bar>
}

/**
 * Alpaca Market Data v2 provider. Requires a free/paid Alpaca account.
 * Docs: https://docs.alpaca.markets/reference/stockbars
 *
 * Store keyId/secretKey using the app's existing SecureStorage class
 * rather than hardcoding them.
 */
class AlpacaDataProvider(
    private val keyId: String,
    private val secretKey: String,
    private val client: OkHttpClient = OkHttpClient()
) : StockDataProvider {

    override suspend fun getDailyBars(symbol: String, limit: Int): List<Bar> {
        val url = "https://data.alpaca.markets/v2/stocks/$symbol/bars" +
            "?timeframe=1Day&limit=$limit&adjustment=raw"

        val request = Request.Builder()
            .url(url)
            .addHeader("APCA-API-KEY-ID", keyId)
            .addHeader("APCA-API-SECRET-KEY", secretKey)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw ScannerDataException(
                    "Alpaca request failed for $symbol: HTTP ${response.code}"
                )
            }
            val body = response.body?.string() ?: return emptyList()
            val json = JSONObject(body)
            val barsArray: JSONArray = json.optJSONArray("bars") ?: return emptyList()

            return (0 until barsArray.length()).map { i ->
                val b = barsArray.getJSONObject(i)
                Bar(
                    timestamp = Instant.parse(b.getString("t")).epochSecond,
                    open = b.getDouble("o"),
                    high = b.getDouble("h"),
                    low = b.getDouble("l"),
                    close = b.getDouble("c"),
                    volume = b.getDouble("v")
                )
            }
        }
    }
}

/**
 * Yahoo Finance chart endpoint. No API key required, useful as a free
 * fallback or for quick prototyping before wiring up Alpaca keys.
 */
class YahooFinanceProvider(
    private val client: OkHttpClient = OkHttpClient()
) : StockDataProvider {

    override suspend fun getDailyBars(symbol: String, limit: Int): List<Bar> {
        val range = rangeForLimit(limit)
        val url = "https://query1.finance.yahoo.com/v8/finance/chart/$symbol" +
            "?interval=1d&range=$range"

        val request = Request.Builder()
            .url(url)
            .addHeader("User-Agent", "Mozilla/5.0")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw ScannerDataException(
                    "Yahoo Finance request failed for $symbol: HTTP ${response.code}"
                )
            }
            val body = response.body?.string() ?: return emptyList()
            val root = JSONObject(body)
            val result = root.getJSONObject("chart")
                .getJSONArray("result")
                .getJSONObject(0)

            val timestamps = result.getJSONArray("timestamp")
            val quote = result.getJSONObject("indicators")
                .getJSONArray("quote")
                .getJSONObject(0)

            val opens = quote.getJSONArray("open")
            val highs = quote.getJSONArray("high")
            val lows = quote.getJSONArray("low")
            val closes = quote.getJSONArray("close")
            val volumes = quote.getJSONArray("volume")

            val bars = mutableListOf<Bar>()
            for (i in 0 until timestamps.length()) {
                // Yahoo can return nulls for non-trading timestamps; skip those.
                if (closes.isNull(i)) continue
                bars.add(
                    Bar(
                        timestamp = timestamps.getLong(i),
                        open = opens.optDouble(i, closes.getDouble(i)),
                        high = highs.optDouble(i, closes.getDouble(i)),
                        low = lows.optDouble(i, closes.getDouble(i)),
                        close = closes.getDouble(i),
                        volume = volumes.optDouble(i, 0.0)
                    )
                )
            }
            return bars.takeLast(limit)
        }
    }

    private fun rangeForLimit(limit: Int): String = when {
        limit <= 30 -> "3mo"
        limit <= 100 -> "6mo"
        limit <= 250 -> "1y"
        else -> "2y"
    }
}

class ScannerDataException(message: String) : Exception(message)
