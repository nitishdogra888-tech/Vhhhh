package com.example.tradingbot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/**
 * Restarts the foreground trading service after device reboot when the user
 * previously left AUTO mode enabled. Missing credentials simply means no
 * restart; no secret is bundled in the APK.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val secure = SecureStorage(context)
        if (!secure.getAutoMode()) return
        val mode = AppPreferences.getTradingMode(context)
        val key = secure.getApiKey(mode)
        val secret = secure.getApiSecret(mode)
        if (key.isBlank() || secret.isBlank()) return
        val market = AppPreferences.getSelectedMarket(context)
        if (!AppPreferences.canTrade(context, market)) return
        val serviceIntent = Intent(context, TradingService::class.java).apply {
            putExtra("apiKey", key)
            putExtra("apiSecret", secret)
            putExtra(TradingService.EXTRA_SYMBOL, market.symbol)
            putExtra(TradingService.EXTRA_LIVE_MODE, mode == TradingMode.LIVE)
            putExtra(TradingService.EXTRA_DAILY_BUDGET_USD, secure.getDailyBudgetUsd())
            putExtra(TradingService.EXTRA_STOP_LOSS_PERCENT, secure.getStopLossPercent())
            putExtra(TradingService.EXTRA_TRAILING_ACTIVATION_PERCENT, secure.getTrailingActivationPercent())
            putExtra(TradingService.EXTRA_TAKE_PROFIT_PERCENT, secure.getTakeProfitPercent())
            putExtra(TradingService.EXTRA_AUTO_MODE, secure.getAutoMode())
            putExtra(TradingService.EXTRA_AUTO_EXIT, secure.getProtectOpenTrade())
            putExtra(TradingService.EXTRA_STRATEGY_ID, secure.getStrategyId().name)
            putExtra(TradingService.EXTRA_SESSION_BUDGET_USD, secure.getSessionBudgetUsd())
            putExtra(TradingService.EXTRA_SESSION_PROFIT_TARGET_USD, secure.getSessionProfitTargetUsd())
            putExtra(TradingService.EXTRA_SESSION_MAX_LOSS_USD, secure.getSessionMaxLossUsd())
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
