package com.example.tradingbot.scanner

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.tradingbot.R
import com.example.tradingbot.databinding.ItemScanResultBinding
import java.util.Locale

class ScanResultAdapter : RecyclerView.Adapter<ScanResultAdapter.ViewHolder>() {

    private var results: List<ScanResult> = emptyList()

    fun submitList(newResults: List<ScanResult>) {
        results = newResults
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemScanResultBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(results[position])
    }

    override fun getItemCount(): Int = results.size

    class ViewHolder(private val binding: ItemScanResultBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(result: ScanResult) {
            binding.symbolText.text = result.symbol
            binding.priceText.text = String.format(Locale.US, "$%.2f", result.lastClose)

            val rsiText = result.rsi?.let { String.format(Locale.US, "RSI %.1f", it) } ?: "RSI n/a"
            val crossText = when (result.maCrossover) {
                TechnicalIndicators.Crossover.GOLDEN -> "Golden cross"
                TechnicalIndicators.Crossover.DEATH -> "Death cross"
                TechnicalIndicators.Crossover.NONE -> "No crossover"
            }
            binding.detailText.text = "$rsiText · $crossText"

            val context = binding.root.context
            val (label, colorRes) = when (result.overallSignal) {
                OverallSignal.BUY -> "BUY" to R.color.positive
                OverallSignal.SELL -> "SELL" to R.color.negative
                OverallSignal.WATCH -> "WATCH" to R.color.warning
                OverallSignal.NONE -> "—" to R.color.text_secondary
            }
            binding.signalText.text = label
            binding.signalText.setTextColor(ContextCompat.getColor(context, colorRes))
        }
    }
}
