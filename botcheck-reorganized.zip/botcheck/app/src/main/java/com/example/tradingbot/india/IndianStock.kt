package com.example.tradingbot.india

/**
 * One NSE-listed equity. `token` is Angel One's numeric instrument token
 * (needed for order placement and market data -- NSE doesn't address
 * symbols by ticker alone the way Binance does).
 */
data class IndianStock(
    val tradingSymbol: String,   // e.g. "RELIANCE-EQ"
    val displayName: String,     // e.g. "Reliance Industries"
    val token: String,           // Angel One instrument token, e.g. "2885"
    val exchange: String = "NSE",
    val accentColor: String
)

/**
 * A small curated shortlist shown by default (mirrors the crypto/bStocks
 * picker). This is NOT the full NSE universe -- there are ~2,000 listed
 * equities alone, before F&O/commodities/currency. The full universe is
 * reached via IndianInstrumentSearch, which is backed by Angel One's
 * downloadable instrument master rather than a hardcoded list like this one.
 */
object IndianMarkets {
    val NIFTY_SHORTLIST: List<IndianStock> = listOf(
        IndianStock("RELIANCE-EQ", "Reliance Industries", "2885", accentColor = "#0F1B3C"),
        IndianStock("TCS-EQ", "Tata Consultancy Services", "11536", accentColor = "#3C1053"),
        IndianStock("HDFCBANK-EQ", "HDFC Bank", "1333", accentColor = "#004C8F"),
        IndianStock("INFY-EQ", "Infosys", "1594", accentColor = "#007CC3"),
        IndianStock("ICICIBANK-EQ", "ICICI Bank", "4963", accentColor = "#F58220"),
        IndianStock("SBIN-EQ", "State Bank of India", "3045", accentColor = "#22409A"),
        IndianStock("TATAMOTORS-EQ", "Tata Motors", "3456", accentColor = "#495B70"),
        IndianStock("ITC-EQ", "ITC", "1660", accentColor = "#A6192E"),
        IndianStock("BHARTIARTL-EQ", "Bharti Airtel", "10604", accentColor = "#E40521"),
        IndianStock("LT-EQ", "Larsen & Toubro", "11483", accentColor = "#00549A")
    )
}
