package com.example.tradingbot.india

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/**
 * NSE equity trading is a fixed IST window on weekdays, unlike Binance's
 * always-on crypto market -- crypto's RiskManager never had to ask "is the
 * exchange even open right now?" This is the India-specific equivalent of
 * that question.
 *
 * IMPORTANT limitation: this only knows the *weekly* Mon-Fri pattern and the
 * regular 09:15-15:30 session. It does NOT know NSE's ~14-15 annual trading
 * holidays (Republic Day, Diwali/Muhurat timing, etc.) -- there is no
 * built-in holiday calendar here. A holiday will look like a normal weekday
 * to this class, so it will incorrectly report the market as open. Wire in
 * NSE's published holiday list (https://www.nseindia.com/resources/exchange-communication-holidays)
 * before relying on this for unattended trading; until then treat
 * `isMarketOpen` as necessary-but-not-sufficient.
 *
 * All calculations are pinned to Asia/Kolkata regardless of the device's
 * timezone, because the exchange's day boundary is IST, not local time.
 */
object IndiaMarketCalendar {

    val IST: ZoneId = ZoneId.of("Asia/Kolkata")

    val SESSION_OPEN: LocalTime = LocalTime.of(9, 15)
    val SESSION_CLOSE: LocalTime = LocalTime.of(15, 30)

    /**
     * Intraday (MIS) positions must be flat before the close -- brokers run
     * their own auto square-off a few minutes before 15:30, and manual/bot
     * exits need a safety margin ahead of that. This is deliberately a bit
     * earlier than Angel One's own auto square-off window so the bot's own
     * exit fires first rather than racing the broker's forced square-off.
     */
    val INTRADAY_SQUARE_OFF_CUTOFF: LocalTime = LocalTime.of(15, 15)

    private val DAY_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    fun nowIst(nowMs: Long = System.currentTimeMillis()): ZonedDateTime =
        Instant.ofEpochMilli(nowMs).atZone(IST)

    /** IST calendar-day string (e.g. "2026-09-16"), used as the RiskManager's daily-reset key. */
    fun tradingDayKey(nowMs: Long = System.currentTimeMillis()): String =
        nowIst(nowMs).format(DAY_FORMAT)

    private fun isWeekday(zdt: ZonedDateTime): Boolean =
        zdt.dayOfWeek != DayOfWeek.SATURDAY && zdt.dayOfWeek != DayOfWeek.SUNDAY

    /** True during the regular 09:15-15:30 IST session on a weekday. Holidays are NOT excluded -- see class doc. */
    fun isMarketOpen(nowMs: Long = System.currentTimeMillis()): Boolean {
        val zdt = nowIst(nowMs)
        if (!isWeekday(zdt)) return false
        val t = zdt.toLocalTime()
        return !t.isBefore(SESSION_OPEN) && t.isBefore(SESSION_CLOSE)
    }

    /** True once it's too late in the session to open a fresh INTRADAY position. */
    fun isPastIntradayEntryCutoff(nowMs: Long = System.currentTimeMillis()): Boolean {
        val zdt = nowIst(nowMs)
        if (!isWeekday(zdt)) return true
        return zdt.toLocalTime().isAfter(INTRADAY_SQUARE_OFF_CUTOFF)
    }

    /** True once an open INTRADAY position must be force-closed regardless of its signal/stop levels. */
    fun isPastIntradaySquareOffDeadline(nowMs: Long = System.currentTimeMillis()): Boolean =
        isPastIntradayEntryCutoff(nowMs)

    /** Null if the market is open for new entries right now; otherwise a human-readable reason it isn't. */
    fun marketClosedReason(nowMs: Long = System.currentTimeMillis()): String? {
        val zdt = nowIst(nowMs)
        if (!isWeekday(zdt)) {
            return "NSE is closed for the weekend (IST). Regular session is Mon-Fri, 09:15-15:30 IST."
        }
        val t = zdt.toLocalTime()
        if (t.isBefore(SESSION_OPEN)) {
            return "NSE hasn't opened yet today (opens 09:15 IST, currently ${t.format(DateTimeFormatter.ofPattern("HH:mm"))} IST)."
        }
        if (!t.isBefore(SESSION_CLOSE)) {
            return "NSE has closed for the day (closes 15:30 IST, currently ${t.format(DateTimeFormatter.ofPattern("HH:mm"))} IST)."
        }
        return null
    }
}
