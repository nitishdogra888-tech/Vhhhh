package com.example.tradingbot

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.FormBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.floor
import kotlin.math.pow

fun isPlausiblePrice(candidate: Double, previousPrice: Double?, maxJumpPercent: Double = 15.0): Boolean {
    if (candidate.isNaN() || candidate.isInfinite() || candidate <= 0.0) return false
    if (previousPrice == null || previousPrice <= 0.0) return true
    val jumpPercent = kotlin.math.abs(candidate - previousPrice) / previousPrice * 100.0
    return jumpPercent <= maxJumpPercent
}

data class SymbolRules(
    val stepSize: Double,
    val minQty: Double,
    val minNotional: Double
)

class UnknownOrderStateException(message: String, cause: Throwable? = null) : RuntimeException(message, cause)


data class PositionCostBasis(
    val quantity: Double,
    val averageEntryPrice: Double
)

data class OrderFill(
    val avgPrice: Double,
    val executedQty: Double,
    val fullyFilled: Boolean,
    val status: String,
    val clientOrderId: String = "",
    val orderId: Long = 0L
)

class BinanceApiClient(
    private val apiKey: String,
    private val apiSecret: String,
    private val useTestnet: Boolean = true
) {
    private val baseUrl = if (useTestnet)
        "https://testnet.binance.vision"
    else
        "https://api.binance.com"

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val symbolRulesCache = mutableMapOf<String, SymbolRules>()

    private var cooldownUntilMs: Long = 0L
    private var serverTimeOffsetMs: Long = 0L
    private var lastServerTimeSyncMs: Long = 0L

    private fun cooldownRemainingMs(): Long = (cooldownUntilMs - System.currentTimeMillis()).coerceAtLeast(0L)

    private fun activateCooldown(durationMs: Long) {
        val until = System.currentTimeMillis() + durationMs
        if (until > cooldownUntilMs) cooldownUntilMs = until
    }

    private fun syncServerTimeIfNeeded() {
        val now = System.currentTimeMillis()
        if (now - lastServerTimeSyncMs < 60_000L) return
        val url = "$baseUrl/api/v3/time"
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string() ?: "{}"
            if (!response.isSuccessful) throw RuntimeException("Server time request failed (${response.code}): $body")
            val serverTime = JSONObject(body).optLong("serverTime", 0L)
            if (serverTime <= 0L) throw RuntimeException("Binance returned an invalid server time")
            serverTimeOffsetMs = serverTime - System.currentTimeMillis()
            lastServerTimeSyncMs = System.currentTimeMillis()
        }
    }

    private fun signedTimestamp(): Long {
        syncServerTimeIfNeeded()
        return System.currentTimeMillis() + serverTimeOffsetMs
    }

    private fun sign(queryString: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(apiSecret.toByteArray(), "HmacSHA256"))
        val hash = mac.doFinal(queryString.toByteArray())
        return hash.joinToString("") { byte -> "%02x".format(byte) }
    }

    private fun <T> withRetry(maxAttempts: Int = 3, block: () -> T): T {
        val remaining = cooldownRemainingMs()
        if (remaining > 0) {
            throw RuntimeException("Binance cooldown active for ${remaining / 1000}s after rate-limit response")
        }

        var lastError: Exception? = null
        for (attempt in 1..maxAttempts) {
            try {
                return block()
            } catch (e: Exception) {
                lastError = e
                val message = e.message ?: ""
                val isRateLimited = message.contains("429") || message.contains("418")
                if (isRateLimited) {
                    activateCooldown(60_000L)
                    throw e
                }
                val isClientError = message.contains("400") ||
                    message.contains("401") ||
                    message.contains("insufficient", ignoreCase = true)
                if (isClientError || attempt == maxAttempts) throw e
                Thread.sleep((1000L * 2.0.pow(attempt - 1)).toLong())
            }
        }
        throw lastError ?: RuntimeException("Request failed after $maxAttempts attempts")
    }

    /** Public market-data endpoint. Kept on mainnet even when trading uses testnet. */
    fun getMainnetKlines(symbol: String, interval: String = "1m", limit: Int = 200): JSONArray = withRetry {
        val url = "https://api.binance.com/api/v3/klines?symbol=$symbol&interval=$interval&limit=$limit"
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string() ?: "[]"
            if (!response.isSuccessful) throw RuntimeException("Mainnet klines request failed (${response.code}): $body")
            JSONArray(body)
        }
    }

    fun getKlines(symbol: String, interval: String = "1m", limit: Int = 50): JSONArray = withRetry {
        val url = "$baseUrl/api/v3/klines?symbol=$symbol&interval=$interval&limit=$limit"
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string() ?: "[]"
            if (!response.isSuccessful) throw RuntimeException("Klines request failed (${response.code}): $body")
            JSONArray(body)
        }
    }

    /**
     * Returns the user's recent spot trades for a symbol. Used only for safe
     * reconciliation of an exchange-held position; the bot refuses to invent
     * an entry price when the returned trade history cannot explain the full
     * current balance.
     */
    fun getMyTrades(symbol: String, limit: Int = 1000): JSONArray = withRetry {
        val timestamp = signedTimestamp()
        val safeLimit = limit.coerceIn(1, 1000)
        val query = "symbol=$symbol&limit=$safeLimit&timestamp=$timestamp&recvWindow=10000"
        val signature = sign(query)
        val url = "$baseUrl/api/v3/myTrades?$query&signature=$signature"
        val request = Request.Builder().url(url).get().addHeader("X-MBX-APIKEY", apiKey).build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string() ?: "[]"
            if (!response.isSuccessful) throw RuntimeException("My trades request failed (${response.code}): $body")
            JSONArray(body)
        }
    }

    /**
     * Derive a FIFO cost basis from the supplied trade history. A null result
     * means the history is incomplete or otherwise cannot explain targetQty,
     * so callers should keep reconciliation locked rather than fabricate P&L.
     */
    fun derivePositionCostBasis(trades: JSONArray, targetQty: Double, tolerance: Double = 1e-8): PositionCostBasis? {
        data class Lot(var qty: Double, val price: Double)
        val lots = java.util.ArrayDeque<Lot>()
        for (i in 0 until trades.length()) {
            val t = trades.getJSONObject(i)
            val qty = t.optString("qty", "0").toDoubleOrNull() ?: 0.0
            val price = t.optString("price", "0").toDoubleOrNull() ?: 0.0
            if (qty <= 0.0 || price <= 0.0) continue
            if (t.optBoolean("isBuyer", false)) {
                lots.addLast(Lot(qty, price))
            } else {
                var remaining = qty
                while (remaining > tolerance && lots.isNotEmpty()) {
                    val lot = lots.first()
                    val used = minOf(remaining, lot.qty)
                    lot.qty -= used
                    remaining -= used
                    if (lot.qty <= tolerance) lots.removeFirst()
                }
                if (remaining > tolerance) return null
            }
        }
        var totalQty = 0.0
        var totalCost = 0.0
        for (lot in lots) {
            if (lot.qty > tolerance) {
                totalQty += lot.qty
                totalCost += lot.qty * lot.price
            }
        }
        if (totalQty <= tolerance || kotlin.math.abs(totalQty - targetQty) > maxOf(tolerance, targetQty * 0.001)) return null
        return PositionCostBasis(totalQty, totalCost / totalQty)
    }

    fun getAccountInfo(): JSONObject = withRetry {
        val timestamp = signedTimestamp()
        val query = "timestamp=$timestamp&recvWindow=10000"
        val signature = sign(query)
        val url = "$baseUrl/api/v3/account?$query&signature=$signature"
        val request = Request.Builder()
            .url(url)
            .get()
            .addHeader("X-MBX-APIKEY", apiKey)
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string() ?: "{}"
            if (!response.isSuccessful) throw RuntimeException("Account request failed (${response.code}): $body")
            JSONObject(body)
        }
    }

    fun getSymbolRules(symbol: String): SymbolRules {
        symbolRulesCache[symbol]?.let { cachedRules -> return cachedRules }

        val url = "$baseUrl/api/v3/exchangeInfo?symbol=$symbol"
        val request = Request.Builder().url(url).get().build()
        val rules = withRetry {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: "{}"
                if (!response.isSuccessful) throw RuntimeException("ExchangeInfo request failed (${response.code}): $body")
                val json = JSONObject(body)
                val symbolInfo = json.getJSONArray("symbols").getJSONObject(0)
                val filters = symbolInfo.getJSONArray("filters")

                var stepSize = 0.00001
                var minQty = 0.0
                var minNotional = 0.0

                for (i in 0 until filters.length()) {
                    val filter = filters.getJSONObject(i)
                    when (filter.getString("filterType")) {
                        "LOT_SIZE" -> {
                            stepSize = filter.getString("stepSize").toDouble()
                            minQty = filter.getString("minQty").toDouble()
                        }
                        "MIN_NOTIONAL", "NOTIONAL" -> {
                            minNotional = filter.optString("minNotional", filter.optString("minNotional", "0")).toDoubleOrNull() ?: 0.0
                        }
                    }
                }
                SymbolRules(stepSize, minQty, minNotional)
            }
        }
        symbolRulesCache[symbol] = rules
        return rules
    }

    fun roundToStepSize(quantity: Double, rules: SymbolRules): Double {
        if (rules.stepSize <= 0) return quantity
        val steps = floor(quantity / rules.stepSize)
        return steps * rules.stepSize
    }

    fun placeMarketOrder(symbol: String, side: String, quantity: String, clientOrderId: String? = null): JSONObject =
        withRetry(maxAttempts = 1) {
            val timestamp = signedTimestamp()
            var query = "symbol=$symbol&side=$side&type=MARKET&quantity=$quantity&timestamp=$timestamp&recvWindow=10000"
            if (clientOrderId != null) query += "&newClientOrderId=$clientOrderId"
            val signature = sign(query)
            val fullQuery = "$query&signature=$signature"

            val url = "$baseUrl/api/v3/order"
            val body = FormBody.Builder().build()

            val request = Request.Builder()
                .url("$url?$fullQuery")
                .post(body)
                .addHeader("X-MBX-APIKEY", apiKey)
                .build()

            client.newCall(request).execute().use { response ->
                val respBody = response.body?.string() ?: "{}"
                if (!response.isSuccessful) throw RuntimeException("Order failed (${response.code}): $respBody")
                JSONObject(respBody)
            }
        }

    fun getOrderStatus(symbol: String, clientOrderId: String): JSONObject = withRetry {
        val timestamp = signedTimestamp()
        val query = "symbol=$symbol&origClientOrderId=$clientOrderId&timestamp=$timestamp&recvWindow=10000"
        val signature = sign(query)
        val url = "$baseUrl/api/v3/order?$query&signature=$signature"
        val request = Request.Builder()
            .url(url)
            .get()
            .addHeader("X-MBX-APIKEY", apiKey)
            .build()
        client.newCall(request).execute().use { response ->
            val respBody = response.body?.string() ?: "{}"
            if (!response.isSuccessful) throw RuntimeException("Order status lookup failed (${response.code}): $respBody")
            JSONObject(respBody)
        }
    }

    fun cancelOrder(symbol: String, clientOrderId: String): JSONObject = withRetry(maxAttempts = 1) {
        val timestamp = signedTimestamp()
        val query = "symbol=$symbol&origClientOrderId=$clientOrderId&timestamp=$timestamp&recvWindow=10000"
        val signature = sign(query)
        val url = "$baseUrl/api/v3/order?$query&signature=$signature"
        val request = Request.Builder()
            .url(url)
            .delete()
            .addHeader("X-MBX-APIKEY", apiKey)
            .build()
        client.newCall(request).execute().use { response ->
            val respBody = response.body?.string() ?: "{}"
            if (!response.isSuccessful) throw RuntimeException("Cancel failed (${response.code}): $respBody")
            JSONObject(respBody)
        }
    }

    fun placeOrderIdempotent(symbol: String, side: String, quantity: String, clientOrderId: String = "bot-$side-${System.currentTimeMillis()}"): JSONObject {
        return try {
            placeMarketOrder(symbol, side, quantity, clientOrderId)
        } catch (firstError: Exception) {
            // A timed-out/unknown submission must NEVER be blindly re-submitted.
            // First resolve the original clientOrderId on the exchange.
            val existing = try {
                getOrderStatus(symbol, clientOrderId)
            } catch (lookupError: Exception) {
                throw UnknownOrderStateException(
                    "Order submission is in an UNKNOWN state (clientOrderId=$clientOrderId). " +
                        "Exchange status lookup also failed; refusing a duplicate order.",
                    lookupError
                )
            }
            val existingStatus = existing.optString("status")
            if (existingStatus in setOf("FILLED", "PARTIALLY_FILLED", "NEW")) {
                existing
            } else {
                throw RuntimeException(
                    "Original order was not accepted (status=$existingStatus, clientOrderId=$clientOrderId): ${firstError.message}",
                    firstError
                )
            }
        }
    }

    /**
     * Prefer exchange-reported fills. If executedQty is 0, query order status
     * once more. NEVER substitute requested qty as a fill.
     */
    fun resolveFill(symbol: String, order: JSONObject, requestedQty: Double, fallbackPrice: Double): OrderFill {
        var fill = parseFill(order, requestedQty, fallbackPrice)
        if (fill.executedQty <= 0.0) {
            val cid = fill.clientOrderId.ifBlank { order.optString("clientOrderId", "") }
            if (cid.isNotBlank()) {
                try {
                    Thread.sleep(400)
                    val refreshed = getOrderStatus(symbol, cid)
                    fill = parseFill(refreshed, requestedQty, fallbackPrice)
                } catch (_: Exception) {
                    // keep original zero fill
                }
            }
        }
        if (!fill.fullyFilled && fill.executedQty > 0.0 && fill.clientOrderId.isNotBlank() &&
            fill.status in setOf("NEW", "PARTIALLY_FILLED")
        ) {
            try {
                cancelOrder(symbol, fill.clientOrderId)
            } catch (_: Exception) {
                // remainder may already be gone on a market order
            }
        }
        return fill
    }

    fun parseFill(order: JSONObject, requestedQty: Double, fallbackPrice: Double): OrderFill {
        val executedQty = order.optString("executedQty", "0").toDoubleOrNull() ?: 0.0
        val cumulativeQuote = order.optString("cummulativeQuoteQty", "0").toDoubleOrNull() ?: 0.0
        val status = order.optString("status", "UNKNOWN")
        val clientOrderId = order.optString("clientOrderId", order.optString("origClientOrderId", ""))
        val orderId = order.optLong("orderId", 0L)

        val avgFromFills = run {
            val fills = order.optJSONArray("fills")
            if (fills == null || fills.length() == 0) return@run null
            var totalQty = 0.0
            var totalQuote = 0.0
            for (i in 0 until fills.length()) {
                val f = fills.getJSONObject(i)
                val p = f.getString("price").toDouble()
                val q = f.getString("qty").toDouble()
                totalQty += q
                totalQuote += p * q
            }
            if (totalQty > 0) totalQuote / totalQty else null
        }

        val avgPrice = avgFromFills
            ?: (if (executedQty > 0 && cumulativeQuote > 0) cumulativeQuote / executedQty else null)
            ?: if (executedQty > 0) fallbackPrice else 0.0

        val fullyFilled = executedQty >= requestedQty * 0.999
        return OrderFill(avgPrice, executedQty, fullyFilled, status, clientOrderId, orderId)
    }

    fun getAssetTotal(account: JSONObject, asset: String): Double {
        val balances = account.optJSONArray("balances") ?: return 0.0
        for (i in 0 until balances.length()) {
            val entry = balances.getJSONObject(i)
            if (entry.getString("asset") == asset) {
                val free = entry.optString("free", "0").toDoubleOrNull() ?: 0.0
                val locked = entry.optString("locked", "0").toDoubleOrNull() ?: 0.0
                return free + locked
            }
        }
        return 0.0
    }
}
