package com.example.tradingbot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import java.io.ByteArrayOutputStream
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView
import android.widget.CompoundButton
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.text.TextWatcher
import android.text.Editable
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.isActive
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Validated values from the Controls tab's "Session risk" card — see DashboardActivity.readSessionRiskSettings(). */
private data class DashSessionRiskSettings(
    val sessionBudgetUsd: Double,
    val sessionProfitTargetUsd: Double,
    val sessionMaxLossUsd: Double
)

class DashboardActivity : AppCompatActivity() {
    // Which market this dashboard/session is driving. Chosen on
    // MarketSelectionActivity; everything below (chart symbol, TradingService
    // extras, balance labels) reads from this instead of a hardcoded BTC pair.
    private lateinit var market: Market
    private val tradingMode: TradingMode get() = AppPreferences.getTradingMode(this)
    private lateinit var secureStorage: SecureStorage
    private lateinit var balanceText: TextView
    private lateinit var pnlText: TextView
    private lateinit var pnlArrow: android.widget.ImageView
    private lateinit var lastPriceText: TextView
    private lateinit var signalText: TextView
    private lateinit var reasonText: TextView
    private lateinit var manualBuyButton: Button
    private lateinit var manualSellButton: Button
    private lateinit var activityLogScroll: ScrollView
    private lateinit var activityLogText: TextView
    private var lastLoggedReason: String = ""
    private lateinit var winRateText: TextView
    private lateinit var costsText: TextView
    private lateinit var netPnlText: TextView
    private lateinit var sparkline: SparklineView
    private lateinit var waitingBanner: TextView
    private lateinit var fixedTradeText: TextView
    private lateinit var positionText: TextView
    private lateinit var entryValueText: TextView
    private lateinit var currentValueText: TextView
    private lateinit var currentTradePnlText: TextView
    private lateinit var tradeHistoryContainer: LinearLayout
    private lateinit var grokAdviceText: TextView
    private lateinit var dashXaiApiKeyInput: EditText
    private lateinit var dashApiKeyInput: EditText
    private lateinit var dashApiSecretInput: EditText
    private lateinit var dashApiKeysSavedText: TextView
    // AI tab (screenshot + vision verdict, taken on market events)
    private lateinit var tabAiScroll: View
    private lateinit var aiLatestThumbnail: android.widget.ImageView
    private lateinit var aiLatestPlaceholder: TextView
    private lateinit var aiLatestSignalText: TextView
    private lateinit var aiLatestReasoningText: TextView
    private lateinit var aiLatestTimeText: TextView
    private lateinit var aiLatestOutlookBox: View
    private lateinit var aiLatestOutlookText: TextView
    private lateinit var aiLatestProfitText: TextView
    private lateinit var aiLatestLevelsText: TextView
    private lateinit var aiLatestRiskBadge: TextView
    private lateinit var aiHistoryContainer: LinearLayout
    private val aiCaptureHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var aiCaptureRunnable: Runnable? = null
    private var aiCaptureInFlight = false
    private lateinit var aiAutoSignalSwitch: com.google.android.material.switchmaterial.SwitchMaterial
    private lateinit var aiAutoSignalKeyInput: EditText
    private lateinit var aiAutoSignalStatusText: TextView
    private lateinit var aiProviderStatusText: TextView
    private lateinit var aiTradeGateSwitch: com.google.android.material.switchmaterial.SwitchMaterial
    private lateinit var aiTradeGateThresholdInput: EditText
    private lateinit var aiTradeGateStatusText: TextView
    private lateinit var tradingViewGateSwitch: com.google.android.material.switchmaterial.SwitchMaterial
    private lateinit var tradingViewRelayUrlInput: EditText
    private lateinit var tradingViewRelayTokenInput: EditText
    private lateinit var tradingViewMaxAgeInput: EditText
    private lateinit var tradingViewGateStatusText: TextView
    // Compact, read-only Home-tab summary. The full switches/inputs above now
    // live on the AI & Profile tab; this just tells the user in one place
    // what the bot will and won't do on its own, without needing to visit
    // settings to find out.
    private lateinit var homeAutomationSummaryText: TextView
    private lateinit var goToAiSettingsButton: Button
    private lateinit var aiUploadButton: Button
    private lateinit var openPositionCard: View
    private lateinit var noOpenPositionText: TextView
    private lateinit var openEntryPriceText: TextView
    private lateinit var openEntryTimeText: TextView
    private lateinit var openQtyText: TextView
    private lateinit var openHoldDurationText: TextView
    private lateinit var openCurrentPriceText: TextView
    private lateinit var openPnlVsEntryText: TextView
    private lateinit var openStopLossPriceText: TextView
    private lateinit var openTrailArmPriceText: TextView
    private lateinit var openTakeProfitPriceText: TextView
    private lateinit var openProtectionStatusText: TextView
    private lateinit var sellNowNetText: TextView
    private lateinit var sellNowGrossText: TextView
    private lateinit var sellNowFeesText: TextView
    private lateinit var sellNowTdsTaxText: TextView
    private lateinit var botDecisionBadgeText: TextView
    private lateinit var botDecisionModeText: TextView
    private lateinit var botDecisionReasonText: TextView
    private lateinit var tradeModeStatusText: TextView
    private lateinit var manualAmountInput: EditText
    private lateinit var manualStopInput: EditText
    private lateinit var manualTakeProfitInput: EditText
    private lateinit var dashSessionBudgetInput: EditText
    private lateinit var dashSessionProfitTargetInput: EditText
    private lateinit var dashSessionMaxLossInput: EditText
    private lateinit var autoModeSwitch: CompoundButton
    private lateinit var autoExitSwitch: CompoundButton
    private lateinit var openPositionStatusText: TextView
    private lateinit var liveIndicator: LinearLayout
    private lateinit var liveStatusText: TextView
    private lateinit var sessionHighText: TextView
    private lateinit var sessionLowText: TextView
    private lateinit var tradesTodayText: TextView
    private lateinit var consecutiveLossesText: TextView
    private lateinit var btcPriceChart: BinanceCandlestickChartView
    private lateinit var btcCurrentPriceText: TextView
    private lateinit var btcChangeText: TextView
    private lateinit var btcRangeLabel: TextView
    private lateinit var reconcileCard: View
    private lateinit var reconcileFab: View
    private lateinit var reconcileReasonText: TextView
    private lateinit var controlsLockBanner: View
    private lateinit var controlsLockReasonText: TextView
    // Whether the exchange/local mismatch is currently locked, and whether
    // the popup is currently expanded (card) vs collapsed (floating pill).
    private var reconcileLocked = false
    private var reconcileExpanded = false
    private lateinit var circuitBreakerCard: View
    private lateinit var circuitBreakerReasonText: TextView
    private lateinit var availableBalanceText: TextView
    private lateinit var inPositionValueText: TextView
    private lateinit var equitySubtitleText: TextView
    private lateinit var orderStatusText: TextView
    private lateinit var liveTradeHeaderPnlText: TextView
    private lateinit var tradeHistoryHeaderStatsText: TextView
    private lateinit var tabHomeScroll: View
    private lateinit var tabPositionScroll: View
    private lateinit var tabControlsScroll: View
    private lateinit var tabHistoryScroll: View
    private lateinit var bottomNav: com.google.android.material.bottomnavigation.BottomNavigationView
    private lateinit var dashStrategySpinner: Spinner
    private lateinit var dashStrategyDescriptionText: TextView
    private lateinit var dashActiveStrategyText: TextView
    private lateinit var dashCustomBuyRuleInput: EditText
    private lateinit var dashCustomSellRuleInput: EditText
    private lateinit var dashCustomBuyRuleError: TextView
    private lateinit var dashCustomSellRuleError: TextView
    private var pendingOrderSide: String? = null
    private var lastKnownPositionOpen = false
    private val orderStatusHideHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var orderStatusHideRunnable: Runnable? = null
    private var btcMarketWebSocket: WebSocket? = null
    private var btcMarketClient: OkHttpClient? = null
    private var btcReconnectJob: Job? = null
    private var lastBtcChartUiUpdateMs: Long = 0L
    private var btcLoadJob: Job? = null
    private val btc10mParts = linkedMapOf<Long, ChartCandle>()
    private var btcSelectedInterval: String = "5m"
    private var btcSelectedRangeLabel: String = "5 min"
    private var btcWindowReferencePrice: Double = 0.0
    private var lastSnap = GrokAdvisor.MarketSnapshot(
        price = 0.0,
        signal = "HOLD",
        reason = "",
        positionOpen = false,
        entry = 0.0,
        qty = 0.0,
        dailyPnlPercent = 0.0,
        remainingBudget = 0.0,
        tradingLocked = false
    )
    private var grokBusy = false
    // Latest values from the last dashboard broadcast, kept around purely so
    // the once-a-minute AI screenshot capture (see runAiCaptureCycle) has the
    // same track-record context the numeric AI Auto-Signal pass uses,
    // without re-deriving it from scratch.
    private var lastWinRatePercent = 0.0
    private var lastTotalTrades = 0
    private var lastConsecutiveLosses = 0
    private var lastRecentCloses: List<Double> = emptyList()
    // Real strategy indicators from the most recent broadcast, threaded into
    // the hourly AI vision capture so the model reasons over actual numbers
    // (not just the screenshot) -- see runAiCaptureCycle.
    private var lastBullishScore = 0
    private var lastBearishScore = 0
    private var lastSignalQuality = 0
    private var lastRsi = 0.0
    private var lastEmaFast = 0.0
    private var lastEmaSlow = 0.0
    private var lastAtrPercent = 0.0
    private var lastTrendStrength = 0.0
    private var hasReceivedUpdate = false
    private var lastRenderedTradesJson: String? = null

    private fun color(resId: Int): Int = ContextCompat.getColor(this, resId)
    private fun money(v: Double): String = String.format(Locale.US, "$%,.2f", v)
    private fun price(v: Double): String = String.format(Locale.US, "$%,.2f", v)
    private fun formatDuration(ms: Long): String {
        if (ms <= 0) return "—"
        val totalSec = ms / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return when {
            h > 0 -> String.format(Locale.US, "%dh %02dm", h, m)
            m > 0 -> String.format(Locale.US, "%dm %02ds", m, s)
            else -> String.format(Locale.US, "%ds", s)
        }
    }
    private fun formatEntryTime(ms: Long): String {
        if (ms <= 0) return "—"
        return "Bought " + SimpleDateFormat("h:mm:ss a · MMM d", Locale.US).format(Date(ms))
    }

    companion object {
        // Same cap MainActivity uses for its own log -- keeps the TextView
        // (and this Activity's memory) bounded during a long-running session.
        private const val MAX_ACTIVITY_LOG_LINES = 300
        // "Screenshot on market events" per the AI tab's brief -- independent of
        // TradingService's own numeric AI Auto-Signal cadence.
    }

    /**
     * Scrollable running history of the bot's own "why" explanation, fed by
     * every dashboard broadcast (so it works whether TradingService.onLog's
     * single global listener is currently pointed at this screen or not).
     * Only appends on an actual change so a HOLD cycle that repeats the same
     * reason every 4s doesn't spam identical lines.
     */
    private fun appendActivityLog(reason: String) {
        val text = reason.ifBlank { return }
        if (text == lastLoggedReason) return
        lastLoggedReason = text
        val stamp = SimpleDateFormat("h:mm:ss a", Locale.US).format(Date())
        val lines = activityLogText.text.split("\n").toMutableList()
        if (lines.size == 1 && lines[0] == "Waiting for the bot's first evaluation…") lines.clear()
        lines.add("[$stamp] $text")
        if (lines.size > MAX_ACTIVITY_LOG_LINES) {
            val trimmed = lines.takeLast(MAX_ACTIVITY_LOG_LINES).toMutableList()
            trimmed[0] = "… (older entries trimmed)"
            activityLogText.text = trimmed.joinToString("\n")
        } else {
            activityLogText.text = lines.joinToString("\n")
        }
        activityLogScroll.post { activityLogScroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            if (intent.getBooleanExtra(TradingService.EXTRA_AI_EVENT, false)) {
                aiCaptureHandler.post { runAutomatedAiVisionAnalysis() }
                refreshAiProviderStatus()
            }
            try {
                val balance = intent.getDoubleExtra(TradingService.EXTRA_BALANCE, 0.0)
                val equity = intent.getDoubleExtra(TradingService.EXTRA_EQUITY, 0.0)
                val pnlPercent = intent.getDoubleExtra(TradingService.EXTRA_PNL_PERCENT, 0.0)
                val lastPrice = intent.getDoubleExtra(TradingService.EXTRA_LAST_PRICE, 0.0)
                val signal = intent.getStringExtra(TradingService.EXTRA_SIGNAL) ?: "HOLD"
                val historyStr = intent.getStringExtra(TradingService.EXTRA_PRICE_HISTORY) ?: ""
                val winRate = intent.getDoubleExtra(TradingService.EXTRA_WIN_RATE, 0.0)
                val totalTrades = intent.getIntExtra(TradingService.EXTRA_TOTAL_TRADES, 0)
                val netPnl = intent.getDoubleExtra(TradingService.EXTRA_NET_PNL, 0.0)
                val feesPlusTds = intent.getDoubleExtra(TradingService.EXTRA_FEES_PLUS_TDS, 0.0)
                val taxEstimate = intent.getDoubleExtra(TradingService.EXTRA_TAX_ESTIMATE, 0.0)
                val fixedTrade = intent.getDoubleExtra(TradingService.EXTRA_FIXED_TRADE_AMOUNT, TradingService.DAILY_TRADING_BUDGET_USD)
                val open = intent.getBooleanExtra(TradingService.EXTRA_POSITION_OPEN, false)
                val entry = intent.getDoubleExtra(TradingService.EXTRA_ENTRY_PRICE, 0.0)
                val qty = intent.getDoubleExtra(TradingService.EXTRA_QUANTITY, 0.0)
                val reason = intent.getStringExtra(TradingService.EXTRA_SIGNAL_REASON) ?: ""
                val isLocked = intent.getBooleanExtra(TradingService.EXTRA_TRADING_LOCKED, false)
                val openPath = parseDoubles(intent.getStringExtra(TradingService.EXTRA_OPEN_TRADE_PATH) ?: "")
                val tradesJson = intent.getStringExtra(TradingService.EXTRA_TRADE_HISTORY) ?: "[]"
                val entryTimestampMs = intent.getLongExtra(TradingService.EXTRA_ENTRY_TIMESTAMP_MS, 0L)
                val stopLossPrice = intent.getDoubleExtra(TradingService.EXTRA_STOP_LOSS_PRICE, 0.0)
                val trailingArmPrice = intent.getDoubleExtra(TradingService.EXTRA_TRAILING_ARM_PRICE, 0.0)
                val takeProfitPrice = intent.getDoubleExtra(TradingService.EXTRA_TAKE_PROFIT_PRICE, 0.0)
                val autoMode = intent.getBooleanExtra(TradingService.EXTRA_AUTO_MODE, secureStorage.getAutoMode())
                val autoExit = intent.getBooleanExtra(TradingService.EXTRA_AUTO_EXIT, secureStorage.getProtectOpenTrade())
                val positionStatusText = intent.getStringExtra(TradingService.EXTRA_POSITION_STATUS_TEXT) ?: ""
                val protectionStatus = intent.getStringExtra(TradingService.EXTRA_PROTECTION_STATUS) ?: "NONE"
                val protectionOrderListId = intent.getLongExtra(TradingService.EXTRA_PROTECTION_ORDER_LIST_ID, 0L)
                val protectionStopPrice = intent.getDoubleExtra(TradingService.EXTRA_PROTECTION_STOP_PRICE, 0.0)
                val protectionTpPrice = intent.getDoubleExtra(TradingService.EXTRA_PROTECTION_TP_PRICE, 0.0)
                val protectionError = intent.getStringExtra(TradingService.EXTRA_PROTECTION_ERROR) ?: ""
                val bullishScore = intent.getIntExtra(TradingService.EXTRA_BULLISH_SCORE, 0)
                val bearishScore = intent.getIntExtra(TradingService.EXTRA_BEARISH_SCORE, 0)
                val signalQuality = intent.getIntExtra(TradingService.EXTRA_SIGNAL_QUALITY, 0)
                val rsi = intent.getDoubleExtra(TradingService.EXTRA_RSI, 0.0)
                val emaFast = intent.getDoubleExtra(TradingService.EXTRA_EMA_FAST, 0.0)
                val emaSlow = intent.getDoubleExtra(TradingService.EXTRA_EMA_SLOW, 0.0)
                val atrPercent = intent.getDoubleExtra(TradingService.EXTRA_ATR_PERCENT, 0.0)
                val trendStrength = intent.getDoubleExtra(TradingService.EXTRA_TREND_STRENGTH, 0.0)
                val sessionHigh = intent.getDoubleExtra(TradingService.EXTRA_SESSION_HIGH, 0.0)
                val sessionLow = intent.getDoubleExtra(TradingService.EXTRA_SESSION_LOW, 0.0)
                val streamStale = intent.getBooleanExtra(TradingService.EXTRA_STREAM_STALE, false)
                val connectionState = intent.getStringExtra(TradingService.EXTRA_CONNECTION_STATE) ?: TradingService.CONNECTION_CONNECTED
                val tradesToday = intent.getIntExtra(TradingService.EXTRA_TRADES_TODAY, 0)
                val maxTradesPerDay = intent.getIntExtra(TradingService.EXTRA_MAX_TRADES_PER_DAY, 8)
                val consecutiveLosses = intent.getIntExtra(TradingService.EXTRA_CONSECUTIVE_LOSSES, 0)
                val maxConsecutiveLosses = intent.getIntExtra(TradingService.EXTRA_MAX_CONSECUTIVE_LOSSES, 3)

                // "Total equity" always shows Available + In-position value + unrealized P&L,
                // and is the only figure that moves on every price tick. Available balance and
                // In-open-position only actually change the moment an order fills — they are
                // derived here, not recomputed independently, so they can never disagree with equity.
                val equityValue = if (equity > 0) equity else balance
                balanceText.text = money(equityValue)
                availableBalanceText.text = money(balance)
                inPositionValueText.text = money((equityValue - balance).coerceAtLeast(0.0))
                equitySubtitleText.visibility = if (open) View.VISIBLE else View.GONE
                val pnlBasis = equityValue
                val pnlDollar = pnlBasis * (pnlPercent / 100.0)
                val isProfit = pnlPercent >= 0
                pnlText.text = String.format(Locale.US, "%s$%,.2f (%.2f%%)", if (isProfit) "+" else "-", kotlin.math.abs(pnlDollar), kotlin.math.abs(pnlPercent))
                pnlText.setTextColor(if (isProfit) color(R.color.positive) else color(R.color.negative))
                pnlArrow.setImageResource(if (isProfit) R.drawable.ic_arrow_up else R.drawable.ic_arrow_down)
                lastPriceText.text = price(lastPrice)
                signalText.text = when (signal) { "BUY" -> "Buy"; "SELL" -> "Sell"; else -> "Hold" }
                signalText.setTextColor(when (signal) { "BUY" -> color(R.color.positive); "SELL" -> color(R.color.negative); else -> color(R.color.text_primary) })
                reasonText.text = reason.ifBlank { "Waiting for the bot's first evaluation…" }
                appendActivityLog(reason)
                val history = parseDoubles(historyStr)
                if (history.size >= 2) sparkline.setData(history, history.last() >= history.first())
                sparkline.setReferencePrice(if (open && entry > 0) entry else null, "Entry")
                winRateText.text = if (totalTrades == 0) "No trades yet" else String.format(Locale.US, "%.0f%% (%d trades)", winRate, totalTrades)
                tradeHistoryHeaderStatsText.text = if (totalTrades == 0) "0 trades" else
                    String.format(Locale.US, "%d trades · %s$%,.2f", totalTrades, if (netPnl >= 0) "+" else "-", kotlin.math.abs(netPnl))
                tradeHistoryHeaderStatsText.setTextColor(if (totalTrades == 0) color(R.color.text_secondary) else if (netPnl >= 0) color(R.color.positive) else color(R.color.negative))
                val totalCosts = feesPlusTds + taxEstimate
                costsText.text = String.format(Locale.US, "-$%,.2f  (fees+TDS $%,.2f, tax est. $%,.2f)", totalCosts, feesPlusTds, taxEstimate)
                netPnlText.text = String.format(Locale.US, "%s$%,.2f", if (netPnl >= 0) "+" else "-", kotlin.math.abs(netPnl))
                netPnlText.setTextColor(if (netPnl >= 0) color(R.color.positive) else color(R.color.negative))

                fixedTradeText.text = money(fixedTrade)
                positionText.text = if (open) "BUY / OPEN" else "FLAT"
                // Reflect real position state every cycle so a stuck/failed order can never
                // leave both buttons stranded disabled -- this also doubles as the double-tap
                // guard, since a tap disables both immediately and only the correct one comes
                // back once the next broadcast confirms what actually happened.
                manualBuyButton.isEnabled = !open && !isLocked
                manualSellButton.isEnabled = open
                positionText.setTextColor(if (open) color(R.color.positive) else color(R.color.text_primary))
                entryValueText.text = if (open) "${price(entry)}  ×  ${formatQty(qty)} BTC" else "—"
                currentValueText.text = if (open) "${price(lastPrice * qty)}  (${price(lastPrice)} × ${formatQty(qty)})" else "—"
                val openPnl = if (open && entry > 0) (lastPrice - entry) * qty else 0.0
                currentTradePnlText.text = String.format(Locale.US, "%s$%.4f", if (openPnl >= 0) "+" else "-", kotlin.math.abs(openPnl))
                currentTradePnlText.setTextColor(if (openPnl >= 0) color(R.color.positive) else color(R.color.negative))

                // Live Trade section header: mirrors the section's own P&L, never another section's.
                liveTradeHeaderPnlText.text = if (open) String.format(Locale.US, "%s$%.4f", if (openPnl >= 0) "+" else "-", kotlin.math.abs(openPnl)) else "FLAT"
                liveTradeHeaderPnlText.setTextColor(if (!open) color(R.color.text_secondary) else if (openPnl >= 0) color(R.color.positive) else color(R.color.negative))

                // Real-time order tracking: Submitted -> Filled/Closed -> Rejected, driven by
                // the actual open/reason state coming back from the exchange each cycle —
                // not just the moment the button was tapped.
                if (pendingOrderSide != null) {
                    when {
                        pendingOrderSide == "BUY" && open && !lastKnownPositionOpen -> {
                            showOrderStatus("Order filled — position opened @ ${price(entry)}", color(R.color.positive))
                            pendingOrderSide = null
                        }
                        pendingOrderSide == "SELL" && !open && lastKnownPositionOpen -> {
                            showOrderStatus("Order filled — position closed", color(R.color.positive))
                            pendingOrderSide = null
                        }
                        reason.contains("blocked", true) || reason.contains("failed", true) || reason.contains("ignored", true) -> {
                            showOrderStatus("Order rejected — $reason", color(R.color.negative))
                            pendingOrderSide = null
                        }
                        else -> {
                            showOrderStatus("Order submitted — waiting for exchange confirmation…", color(R.color.text_secondary))
                        }
                    }
                }
                lastKnownPositionOpen = open

                // Dedicated Open Position card — hidden entirely while flat.
                openPositionCard.visibility = if (open) View.VISIBLE else View.GONE
                noOpenPositionText.visibility = if (open) View.GONE else View.VISIBLE
                if (open) {
                    openEntryPriceText.text = price(entry)
                    openEntryTimeText.text = formatEntryTime(entryTimestampMs)
                    openQtyText.text = "${formatQty(qty)} ${market.baseAsset}"
                    openHoldDurationText.text = formatDuration(System.currentTimeMillis() - entryTimestampMs)
                    openCurrentPriceText.text = price(lastPrice)
                    val openPnlPercent = if (entry > 0) (lastPrice - entry) / entry * 100.0 else 0.0
                    val pnlUp = openPnlPercent >= 0
                    openPnlVsEntryText.text = String.format(
                        Locale.US, "%s$%.4f (%.2f%%)",
                        if (pnlUp) "+" else "-", kotlin.math.abs(openPnl), kotlin.math.abs(openPnlPercent)
                    )
                    openPnlVsEntryText.setTextColor(if (pnlUp) color(R.color.positive) else color(R.color.negative))
                    if (entry > 0 && qty > 0 && lastPrice > 0) {
                        val sellNow = CostModel.previewSellNow(entry, lastPrice, qty)
                        sellNowNetText.text = String.format(Locale.US, "%s$%.4f", if (sellNow.netPnl >= 0) "+" else "-", kotlin.math.abs(sellNow.netPnl))
                        sellNowNetText.setTextColor(if (sellNow.netPnl >= 0) color(R.color.positive) else color(R.color.negative))
                        sellNowGrossText.text = String.format(Locale.US, "Gross: %s$%.4f", if (sellNow.grossPnl >= 0) "+" else "-", kotlin.math.abs(sellNow.grossPnl))
                        sellNowFeesText.text = String.format(Locale.US, "Exchange fees: -$%.4f", sellNow.exchangeFees)
                        sellNowTdsTaxText.text = String.format(Locale.US, "TDS + tax estimate: -$%.4f", sellNow.tds + sellNow.taxOnGain)
                    }
                    openStopLossPriceText.text = price(stopLossPrice)
                    openTrailArmPriceText.text = price(trailingArmPrice)
                    openTakeProfitPriceText.text = price(takeProfitPrice)
                    when (protectionStatus) {
                        "EXCHANGE_PROTECTED" -> {
                            openProtectionStatusText.text = "Protection: 🟢 EXCHANGE PROTECTED" +
                                if (protectionOrderListId > 0) " (order #$protectionOrderListId, stop ${price(protectionStopPrice)} / target ${price(protectionTpPrice)})" else ""
                            openProtectionStatusText.setTextColor(color(R.color.positive))
                        }
                        "LOCAL_ONLY" -> {
                            openProtectionStatusText.text = "Protection: 🟡 LOCAL ONLY — internet required"
                            openProtectionStatusText.setTextColor(color(R.color.warning))
                        }
                        "UNPROTECTED", "PROTECTION_FAILED" -> {
                            openProtectionStatusText.text = "Protection: 🔴 UNPROTECTED" +
                                if (protectionError.isNotBlank()) " — $protectionError" else " — exchange-side order missing or failed"
                            openProtectionStatusText.setTextColor(color(R.color.negative))
                        }
                        else -> {
                            openProtectionStatusText.text = "Protection: 🟡 LOCAL ONLY — internet required"
                            openProtectionStatusText.setTextColor(color(R.color.warning))
                        }
                    }
                    openPositionStatusText.text = positionStatusText
                }

                // Feed the same trade levels to the compact chart and the fullscreen
                // mirror. entry is BTC/USDT price, not the manual-trade toggle above.
                val levelEntry = if (open) entry else null
                val levelStop = if (open) stopLossPrice else null
                val levelTake = if (open) takeProfitPrice else null
                val levelTrail = if (open) trailingArmPrice else null
                btcPriceChart.setLevels(levelEntry, levelStop, levelTake, levelTrail)
                ChartDataBus.updateLevels(levelEntry, levelStop, levelTake, levelTrail)

                // Live/delayed indicator: a live tick always reports fresh;
                // only the REST-poll path can flag the stream as stale.
                // Live/delayed/reconnecting indicator. connectionState comes straight
                // from the WebSocket's own onOpen/onFailure/onClosed callbacks, so a
                // dropped socket shows up immediately -- streamStale is a separate,
                // slower signal (REST poll noticing ticks stopped) and is only checked
                // once the socket itself reports healthy.
                val apiDegraded = intent.getBooleanExtra(TradingService.EXTRA_API_DEGRADED, false)
                val apiRetryAttempt = intent.getIntExtra(TradingService.EXTRA_API_RETRY_ATTEMPT, 0)
                when {
                    connectionState == TradingService.CONNECTION_RECONNECTING -> {
                        liveIndicator.backgroundTintList = android.content.res.ColorStateList.valueOf(color(R.color.negative_bg))
                        liveStatusText.text = "Reconnecting"
                        liveStatusText.setTextColor(color(R.color.negative))
                    }
                    apiDegraded -> {
                        // REST API calls (balance/orders/klines) are failing repeatedly --
                        // distinct from the live WebSocket price stream's own state above.
                        liveIndicator.backgroundTintList = android.content.res.ColorStateList.valueOf(color(R.color.negative_bg))
                        liveStatusText.text = "Degraded — retrying (attempt $apiRetryAttempt)"
                        liveStatusText.setTextColor(color(R.color.negative))
                    }
                    connectionState == TradingService.CONNECTION_CONNECTING -> {
                        liveIndicator.backgroundTintList = android.content.res.ColorStateList.valueOf(color(R.color.warning_bg))
                        liveStatusText.text = "Connecting"
                        liveStatusText.setTextColor(color(R.color.text_secondary))
                    }
                    streamStale -> {
                        liveIndicator.backgroundTintList = android.content.res.ColorStateList.valueOf(color(R.color.warning_bg))
                        liveStatusText.text = "Delayed"
                        liveStatusText.setTextColor(color(R.color.text_secondary))
                    }
                    else -> {
                        liveIndicator.backgroundTintList = android.content.res.ColorStateList.valueOf(color(R.color.positive_bg))
                        liveStatusText.text = "Live"
                        liveStatusText.setTextColor(color(R.color.positive_bright))
                    }
                }

                if (sessionHigh > 0) sessionHighText.text = price(sessionHigh)
                if (sessionLow > 0) sessionLowText.text = price(sessionLow)
                tradesTodayText.text = "$tradesToday / $maxTradesPerDay"
                consecutiveLossesText.text = "$consecutiveLosses / $maxConsecutiveLosses"
                consecutiveLossesText.setTextColor(if (consecutiveLosses > 0) color(R.color.negative) else color(R.color.text_primary))
                reconcileLocked = isLocked
                if (isLocked) {
                    reconcileReasonText.text = reason.ifBlank { "Exchange balance and local position do not match." }
                    controlsLockReasonText.text = reconcileReasonText.text
                }
                updateReconcileVisibility()

                botDecisionBadgeText.text = signal
                botDecisionBadgeText.setTextColor(when (signal) { "BUY" -> color(R.color.positive); "SELL" -> color(R.color.negative); else -> color(R.color.text_secondary) })
                botDecisionModeText.text = when {
                    isLocked -> "Trading locked - reconcile before opening a position"
                    open -> "Position open - bot is monitoring its exit rules"
                    autoMode -> "Auto mode - waiting for the next strategy signal"
                    else -> "Manual mode - waiting for your decision"
                }
                botDecisionReasonText.text = reason.ifBlank { "Waiting for the bot's first evaluation..." }

                val autoBuyCircuitPaused = intent.getBooleanExtra(TradingService.EXTRA_AUTO_BUY_CIRCUIT_PAUSED, false)
                circuitBreakerCard.visibility = if (autoBuyCircuitPaused) View.VISIBLE else View.GONE
                if (autoBuyCircuitPaused) {
                    circuitBreakerReasonText.text = "$apiRetryAttempt consecutive Binance API failures. New automatic entries are blocked; any open position is still managed normally."
                }
                lastWinRatePercent = winRate
                lastTotalTrades = totalTrades
                lastConsecutiveLosses = consecutiveLosses
                if (history.size >= 2) lastRecentCloses = history.takeLast(20)
                // Only overwrite once we see a genuine (non-zero-quality) readout,
                // so a degraded/warmup cycle's defaults don't blow away the last
                // real indicator snapshot the AI vision capture relies on.
                if (signalQuality > 0 || bullishScore > 0 || bearishScore > 0) {
                    lastBullishScore = bullishScore
                    lastBearishScore = bearishScore
                    lastSignalQuality = signalQuality
                    lastRsi = rsi
                    lastEmaFast = emaFast
                    lastEmaSlow = emaSlow
                    lastAtrPercent = atrPercent
                    lastTrendStrength = trendStrength
                }
                lastSnap = GrokAdvisor.MarketSnapshot(
                    price = lastPrice,
                    signal = signal,
                    reason = reason,
                    positionOpen = open,
                    entry = entry,
                    qty = qty,
                    dailyPnlPercent = pnlPercent,
                    remainingBudget = fixedTrade,
                    tradingLocked = isLocked
                )
                // Trade history only actually changes when a trade opens/closes,
                // not on every live price tick. Skip the removeAllViews() + rebuild
                // (up to 20 cards, each with its own canvas chart) when the JSON is
                // byte-for-byte the same as what's already on screen.
                if (tradesJson != lastRenderedTradesJson) {
                    lastRenderedTradesJson = tradesJson
                    renderTradeHistory(JSONArray(tradesJson))
                }


                autoModeSwitch.isChecked = autoMode
                autoExitSwitch.isChecked = autoExit
                tradeModeStatusText.text = if (autoMode) "AUTO · strategy controls entries" else "MANUAL · you control entries"
                val activeStrategyName = intent.getStringExtra(TradingService.EXTRA_ACTIVE_STRATEGY_NAME)
                if (!activeStrategyName.isNullOrBlank()) {
                    dashActiveStrategyText.text = "Currently running: $activeStrategyName"
                }
                if (!hasReceivedUpdate) { hasReceivedUpdate = true; waitingBanner.visibility = View.GONE }
            } catch (e: Exception) {
                TradingService.onLog?.invoke("Dashboard update skipped (bad data): ${e.message}")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
        val requestedSymbol = intent.getStringExtra(MarketSelectionActivity.EXTRA_SYMBOL)
        market = requestedSymbol?.let { Markets.bySymbol(it) } ?: AppPreferences.getSelectedMarket(this)
        AppPreferences.setSelectedMarket(this, market)
        secureStorage = SecureStorage(this)
        balanceText = findViewById(R.id.balanceText)
        reconcileCard = findViewById(R.id.reconcileCard)
        reconcileFab = findViewById(R.id.reconcileFab)
        reconcileReasonText = findViewById(R.id.reconcileReasonText)
        controlsLockBanner = findViewById(R.id.controlsLockBanner)
        controlsLockReasonText = findViewById(R.id.controlsLockReasonText)
        circuitBreakerCard = findViewById(R.id.circuitBreakerCard)
        circuitBreakerReasonText = findViewById(R.id.circuitBreakerReasonText)
        availableBalanceText = findViewById(R.id.availableBalanceText)
        inPositionValueText = findViewById(R.id.inPositionValueText)
        equitySubtitleText = findViewById(R.id.equitySubtitleText)
        orderStatusText = findViewById(R.id.orderStatusText)
        liveTradeHeaderPnlText = findViewById(R.id.liveTradeHeaderPnlText)
        tradeHistoryHeaderStatsText = findViewById(R.id.tradeHistoryHeaderStatsText)
        findViewById<Button>(R.id.reconcileAdoptButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            confirmReconcile(adopt = true)
        }
        findViewById<Button>(R.id.reconcileClearButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            confirmReconcile(adopt = false)
        }
        // Floating pill -> tap to reopen the popup.
        reconcileFab.setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            reconcileExpanded = true
            updateReconcileVisibility()
        }
        controlsLockBanner.setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            reconcileExpanded = true
            updateReconcileVisibility()
        }
        // Popup's own close (✕) -> collapse back to the floating pill.
        findViewById<View>(R.id.reconcileCloseButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            reconcileExpanded = false
            updateReconcileVisibility()
        }
        findViewById<Button>(R.id.circuitBreakerResumeButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            resumeAutoBuyAfterCircuitBreaker()
        }
        pnlText = findViewById(R.id.pnlText)
        pnlArrow = findViewById(R.id.pnlArrow)
        lastPriceText = findViewById(R.id.lastPriceText)
        signalText = findViewById(R.id.signalText)
        reasonText = findViewById(R.id.reasonText)
        activityLogScroll = findViewById(R.id.activityLogScroll)
        activityLogText = findViewById(R.id.activityLogText)
        winRateText = findViewById(R.id.winRateText)
        costsText = findViewById(R.id.costsText)
        netPnlText = findViewById(R.id.netPnlText)
        sparkline = findViewById(R.id.sparkline)
        waitingBanner = findViewById(R.id.waitingBanner)
        fixedTradeText = findViewById(R.id.fixedTradeText)
        positionText = findViewById(R.id.positionText)
        entryValueText = findViewById(R.id.entryValueText)
        currentValueText = findViewById(R.id.currentValueText)
        currentTradePnlText = findViewById(R.id.currentTradePnlText)
        tradeHistoryContainer = findViewById(R.id.tradeHistoryContainer)
        grokAdviceText = findViewById(R.id.grokAdviceText)
        dashXaiApiKeyInput = findViewById(R.id.dashXaiApiKeyInput)
        aiAutoSignalSwitch = findViewById(R.id.aiAutoSignalSwitch)
        aiAutoSignalKeyInput = findViewById(R.id.aiAutoSignalKeyInput)
        aiAutoSignalStatusText = findViewById(R.id.aiAutoSignalStatusText)
        aiProviderStatusText = findViewById(R.id.aiProviderStatusText)
        aiTradeGateSwitch = findViewById(R.id.aiTradeGateSwitch)
        aiTradeGateThresholdInput = findViewById(R.id.aiTradeGateThresholdInput)
        aiTradeGateStatusText = findViewById(R.id.aiTradeGateStatusText)
        tradingViewGateSwitch = findViewById(R.id.tradingViewGateSwitch)
        tradingViewRelayUrlInput = findViewById(R.id.tradingViewRelayUrlInput)
        tradingViewRelayTokenInput = findViewById(R.id.tradingViewRelayTokenInput)
        tradingViewMaxAgeInput = findViewById(R.id.tradingViewMaxAgeInput)
        tradingViewGateStatusText = findViewById(R.id.tradingViewGateStatusText)
        homeAutomationSummaryText = findViewById(R.id.homeAutomationSummaryText)
        goToAiSettingsButton = findViewById(R.id.goToAiSettingsButton)
        goToAiSettingsButton.setOnClickListener {
            bottomNav.selectedItemId = R.id.navAi
        }
        aiUploadButton = findViewById(R.id.aiUploadButton)
        openPositionCard = findViewById(R.id.openPositionCard)
        noOpenPositionText = findViewById(R.id.noOpenPositionText)
        openEntryPriceText = findViewById(R.id.openEntryPriceText)
        openEntryTimeText = findViewById(R.id.openEntryTimeText)
        openQtyText = findViewById(R.id.openQtyText)
        openHoldDurationText = findViewById(R.id.openHoldDurationText)
        openCurrentPriceText = findViewById(R.id.openCurrentPriceText)
        openPnlVsEntryText = findViewById(R.id.openPnlVsEntryText)
        openStopLossPriceText = findViewById(R.id.openStopLossPriceText)
        openTrailArmPriceText = findViewById(R.id.openTrailArmPriceText)
        openTakeProfitPriceText = findViewById(R.id.openTakeProfitPriceText)
        openProtectionStatusText = findViewById(R.id.openProtectionStatusText)
        sellNowNetText = findViewById(R.id.sellNowNetText)
        sellNowGrossText = findViewById(R.id.sellNowGrossText)
        sellNowFeesText = findViewById(R.id.sellNowFeesText)
        sellNowTdsTaxText = findViewById(R.id.sellNowTdsTaxText)
        botDecisionBadgeText = findViewById(R.id.botDecisionBadgeText)
        botDecisionModeText = findViewById(R.id.botDecisionModeText)
        botDecisionReasonText = findViewById(R.id.botDecisionReasonText)
        openPositionStatusText = findViewById(R.id.openPositionStatusText)
        liveIndicator = findViewById(R.id.liveIndicator)
        liveStatusText = findViewById(R.id.liveStatusText)
        sessionHighText = findViewById(R.id.sessionHighText)
        sessionLowText = findViewById(R.id.sessionLowText)
        tradesTodayText = findViewById(R.id.tradesTodayText)
        consecutiveLossesText = findViewById(R.id.consecutiveLossesText)
        btcPriceChart = findViewById(R.id.btcPriceChart)
        findViewById<android.widget.ImageButton>(R.id.btcChartExpandButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            startActivity(Intent(this, FullscreenChartActivity::class.java))
        }
        btcCurrentPriceText = findViewById(R.id.btcCurrentPriceText)
        btcChangeText = findViewById(R.id.btcChangeText)
        btcRangeLabel = findViewById(R.id.btcRangeLabel)
        btcRangeLabel.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            startActivity(Intent(this, MarketSelectionActivity::class.java))
        }
        tradeModeStatusText = findViewById(R.id.tradeModeStatusText)
        manualAmountInput = findViewById(R.id.manualAmountInput)
        manualStopInput = findViewById(R.id.manualStopInput)
        manualTakeProfitInput = findViewById(R.id.manualTakeProfitInput)
        dashSessionBudgetInput = findViewById(R.id.dashSessionBudgetInput)
        dashSessionProfitTargetInput = findViewById(R.id.dashSessionProfitTargetInput)
        dashSessionMaxLossInput = findViewById(R.id.dashSessionMaxLossInput)
        manualBuyButton = findViewById(R.id.manualBuyButton)
        manualSellButton = findViewById(R.id.manualSellButton)
        autoModeSwitch = findViewById(R.id.autoModeSwitch)
        autoExitSwitch = findViewById(R.id.autoExitSwitch)
        autoModeSwitch.isChecked = secureStorage.getAutoMode()
        autoExitSwitch.isChecked = secureStorage.getProtectOpenTrade()
        manualAmountInput.setText(String.format(Locale.US, "%.2f", secureStorage.getManualTradeAmountUsd()))
        manualStopInput.setText(String.format(Locale.US, "%.2f", secureStorage.getStopLossPercent() * 100.0))
        manualTakeProfitInput.setText(String.format(Locale.US, "%.2f", secureStorage.getTakeProfitPercent() * 100.0))
        dashSessionBudgetInput.setText(String.format(Locale.US, "%.2f", secureStorage.getSessionBudgetUsd()))
        dashSessionProfitTargetInput.setText(String.format(Locale.US, "%.2f", secureStorage.getSessionProfitTargetUsd()))
        dashSessionMaxLossInput.setText(String.format(Locale.US, "%.2f", secureStorage.getSessionMaxLossUsd()))
        setupManualControls()
        setupBitcoinRangeButtons()
        dashXaiApiKeyInput.setText(secureStorage.getXaiApiKey())
        setupAiAutoSignalControls()
        setupAiTradingGateControls()
        setupManualAiUpload()
        refreshAiProviderStatus()

        findViewById<Button>(R.id.askGrokButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            val typed = dashXaiApiKeyInput.text.toString().trim()
            if (typed.isNotEmpty()) secureStorage.saveXaiApiKey(typed)
            askGrok()
        }

        // Binance Testnet API key/secret, editable from AI & Profile so the
        // person doesn't have to go back to the launcher screen to update them.
        dashApiKeyInput = findViewById(R.id.dashApiKeyInput)
        dashApiSecretInput = findViewById(R.id.dashApiSecretInput)
        dashApiKeysSavedText = findViewById(R.id.dashApiKeysSavedText)
        dashApiKeyInput.setText(secureStorage.getApiKey(tradingMode))
        dashApiSecretInput.setText(secureStorage.getApiSecret(tradingMode))
        val dashRestartBotButton = findViewById<Button>(R.id.dashRestartBotButton)
        findViewById<Button>(R.id.dashSaveApiKeysButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            val newKey = dashApiKeyInput.text.toString().trim()
            val newSecret = dashApiSecretInput.text.toString().trim()
            if (newKey.isEmpty() || newSecret.isEmpty()) {
                dashApiKeysSavedText.text = "Enter both API Key and API Secret before saving."
                dashApiKeysSavedText.setTextColor(getColor(R.color.negative))
                dashRestartBotButton.visibility = View.GONE
            } else {
                secureStorage.saveCredentials(newKey, newSecret, tradingMode)
                dashApiKeysSavedText.text = "Saved. Restart the bot for the new keys to take effect."
                dashApiKeysSavedText.setTextColor(getColor(R.color.positive))
                dashRestartBotButton.visibility = View.VISIBLE
            }
        }

        dashRestartBotButton.setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            stopService(Intent(this, TradingService::class.java))
            val strategyId = secureStorage.getStrategyId()
            val intent = Intent(this, TradingService::class.java).apply {
                putExtra("apiKey", secureStorage.getApiKey(tradingMode))
                putExtra("apiSecret", secureStorage.getApiSecret(tradingMode))
                putExtra(TradingService.EXTRA_SYMBOL, market.symbol)
                putExtra(TradingService.EXTRA_LIVE_MODE, tradingMode == TradingMode.LIVE)
                putExtra(TradingService.EXTRA_DAILY_BUDGET_USD, secureStorage.getDailyBudgetUsd())
                putExtra(TradingService.EXTRA_STOP_LOSS_PERCENT, secureStorage.getStopLossPercent())
                putExtra(TradingService.EXTRA_TRAILING_ACTIVATION_PERCENT, secureStorage.getTrailingActivationPercent())
                putExtra(TradingService.EXTRA_TAKE_PROFIT_PERCENT, secureStorage.getTakeProfitPercent())
                putExtra(TradingService.EXTRA_AUTO_MODE, secureStorage.getAutoMode())
                putExtra(TradingService.EXTRA_AUTO_EXIT, secureStorage.getProtectOpenTrade())
                putExtra(TradingService.EXTRA_STRATEGY_ID, strategyId.name)
            }
            startForegroundService(intent)
            dashApiKeysSavedText.text = "Bot restarted with the new keys."
            dashApiKeysSavedText.setTextColor(getColor(R.color.positive))
            dashRestartBotButton.visibility = View.GONE
        }

        // Trade history and cumulative stats are persisted to disk by the
        // service on every closed trade, independent of whether the bot is
        // currently running. Load them immediately on open instead of
        // waiting for a live broadcast (which only ever arrives while
        // TradingService is actively looping) — otherwise reopening the
        // dashboard after the bot has stopped, or before its next poll
        // cycle, showed an empty "no trades yet" chart even though trades
        // had already completed.
        loadPersistedState()

        setupBottomTabs()
        setupStrategyPicker()

        findViewById<Button>(R.id.dashRefreshButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            val sessionSettings = readSessionRiskSettings() ?: return@setOnClickListener
            secureStorage.saveSessionRiskSettings(
                sessionBudgetUsd = sessionSettings.sessionBudgetUsd,
                sessionProfitTargetUsd = sessionSettings.sessionProfitTargetUsd,
                sessionMaxLossUsd = sessionSettings.sessionMaxLossUsd
            )
            // Manual refresh is still available even though market prices are
            // now streamed live. It asks TradingService for an immediate full
            // REST/account/strategy snapshot rather than waiting 15 seconds.
            startForegroundService(Intent(this, TradingService::class.java).apply {
                action = TradingService.ACTION_MANUAL_REFRESH
                putExtra("apiKey", secureStorage.getApiKey(tradingMode))
                putExtra("apiSecret", secureStorage.getApiSecret(tradingMode))
                putExtra(TradingService.EXTRA_SYMBOL, market.symbol)
                putExtra(TradingService.EXTRA_LIVE_MODE, tradingMode == TradingMode.LIVE)
                putExtra(TradingService.EXTRA_DAILY_BUDGET_USD, secureStorage.getDailyBudgetUsd())
                putExtra(TradingService.EXTRA_STOP_LOSS_PERCENT, secureStorage.getStopLossPercent())
                putExtra(TradingService.EXTRA_TRAILING_ACTIVATION_PERCENT, secureStorage.getTrailingActivationPercent())
                putExtra(TradingService.EXTRA_TAKE_PROFIT_PERCENT, secureStorage.getTakeProfitPercent())
                putExtra(TradingService.EXTRA_AUTO_MODE, secureStorage.getAutoMode())
                putExtra(TradingService.EXTRA_AUTO_EXIT, secureStorage.getProtectOpenTrade())
                putExtra(TradingService.EXTRA_SESSION_BUDGET_USD, sessionSettings.sessionBudgetUsd)
                putExtra(TradingService.EXTRA_SESSION_PROFIT_TARGET_USD, sessionSettings.sessionProfitTargetUsd)
                putExtra(TradingService.EXTRA_SESSION_MAX_LOSS_USD, sessionSettings.sessionMaxLossUsd)
            })
        }

        findViewById<Button>(R.id.dashStartButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            if (!AppPreferences.canTrade(this, market)) {
                android.widget.Toast.makeText(
                    this,
                    "${market.baseAsset} isn't available on Testnet. Switch to Live mode from the market picker to trade it.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            val sessionSettings = readSessionRiskSettings() ?: return@setOnClickListener
            secureStorage.saveSessionRiskSettings(
                sessionBudgetUsd = sessionSettings.sessionBudgetUsd,
                sessionProfitTargetUsd = sessionSettings.sessionProfitTargetUsd,
                sessionMaxLossUsd = sessionSettings.sessionMaxLossUsd
            )
            startForegroundService(Intent(this, TradingService::class.java).apply {
                putExtra("apiKey", secureStorage.getApiKey(tradingMode))
                putExtra("apiSecret", secureStorage.getApiSecret(tradingMode))
                putExtra(TradingService.EXTRA_SYMBOL, market.symbol)
                putExtra(TradingService.EXTRA_LIVE_MODE, tradingMode == TradingMode.LIVE)
                putExtra(TradingService.EXTRA_DAILY_BUDGET_USD, secureStorage.getDailyBudgetUsd())
                putExtra(TradingService.EXTRA_STOP_LOSS_PERCENT, secureStorage.getStopLossPercent())
                putExtra(TradingService.EXTRA_TRAILING_ACTIVATION_PERCENT, secureStorage.getTrailingActivationPercent())
                putExtra(TradingService.EXTRA_TAKE_PROFIT_PERCENT, secureStorage.getTakeProfitPercent())
                putExtra(TradingService.EXTRA_AUTO_MODE, secureStorage.getAutoMode())
                putExtra(TradingService.EXTRA_AUTO_EXIT, secureStorage.getProtectOpenTrade())
                putExtra(TradingService.EXTRA_SESSION_BUDGET_USD, sessionSettings.sessionBudgetUsd)
                putExtra(TradingService.EXTRA_SESSION_PROFIT_TARGET_USD, sessionSettings.sessionProfitTargetUsd)
                putExtra(TradingService.EXTRA_SESSION_MAX_LOSS_USD, sessionSettings.sessionMaxLossUsd)
            })
        }
        findViewById<Button>(R.id.dashHistoryButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<Button>(R.id.dashStopButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            stopService(Intent(this, TradingService::class.java))
        }
    }

    // Parses + validates the three session-risk fields on the Controls tab's
    // "Session risk" card. Returns null (after showing an explanatory dialog)
    // if anything is missing or not a positive number — same validation
    // pattern as MainActivity.readSessionRiskSettings().
    private fun readSessionRiskSettings(): DashSessionRiskSettings? {
        val budget = dashSessionBudgetInput.text.toString().toDoubleOrNull()
        val profitTarget = dashSessionProfitTargetInput.text.toString().toDoubleOrNull()
        val maxLoss = dashSessionMaxLossInput.text.toString().toDoubleOrNull()

        val error = when {
            budget == null || budget <= 0.0 -> "Session budget must be a number greater than 0."
            profitTarget == null || profitTarget <= 0.0 -> "Pause-after-profit must be a number greater than 0."
            maxLoss == null || maxLoss <= 0.0 -> "Pause-after-loss must be a number greater than 0."
            else -> null
        }
        if (error != null) {
            AlertDialog.Builder(this)
                .setTitle("Check session risk settings")
                .setMessage(error)
                .setPositiveButton("OK", null)
                .show()
            return null
        }
        // Safe: all three passed the null/range checks above.
        return DashSessionRiskSettings(budget!!, profitTarget!!, maxLoss!!)
    }

    private fun setupManualControls() {
        fun percentFrom(view: EditText, fallback: Double): Double =
            (view.text.toString().trim().toDoubleOrNull() ?: fallback).coerceAtLeast(0.0) / 100.0

        fun persistSettings() {
            val amount = (manualAmountInput.text.toString().trim().toDoubleOrNull() ?: secureStorage.getManualTradeAmountUsd()).coerceAtLeast(1.0)
            val stop = percentFrom(manualStopInput, secureStorage.getStopLossPercent())
            val target = percentFrom(manualTakeProfitInput, secureStorage.getTakeProfitPercent())
            secureStorage.saveManualTradeAmountUsd(amount)
            secureStorage.saveTradingSettings(secureStorage.getDailyBudgetUsd(), stop, secureStorage.getTrailingActivationPercent(), target)
            secureStorage.saveAutoMode(autoModeSwitch.isChecked)
            secureStorage.saveProtectOpenTrade(autoExitSwitch.isChecked)
        }

        autoModeSwitch.setOnCheckedChangeListener { _, checked ->
            secureStorage.saveAutoMode(checked)
            tradeModeStatusText.text = if (checked) "AUTO · strategy controls entries" else "MANUAL · you control entries"
            startTradingService(TradingService.ACTION_SET_MODE)
            updateHomeAutomationSummary()
        }
        autoExitSwitch.setOnCheckedChangeListener { _, checked ->
            secureStorage.saveProtectOpenTrade(checked)
            startTradingService(TradingService.ACTION_SET_MODE)
        }
        findViewById<Button>(R.id.manualBuyButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            if (!AppPreferences.canTrade(this, market)) {
                android.widget.Toast.makeText(
                    this,
                    "${market.baseAsset} isn't available on Testnet. Switch to Live mode to trade it.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            persistSettings()
            pendingOrderSide = "BUY"
            manualBuyButton.isEnabled = false
            manualSellButton.isEnabled = false
            showOrderStatus("Order submitted — waiting for exchange confirmation…", color(R.color.text_secondary))
            startTradingService(TradingService.ACTION_MANUAL_BUY)
        }
        findViewById<Button>(R.id.manualSellButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            pendingOrderSide = "SELL"
            manualBuyButton.isEnabled = false
            manualSellButton.isEnabled = false
            showOrderStatus("Order submitted — waiting for exchange confirmation…", color(R.color.text_secondary))
            startTradingService(TradingService.ACTION_MANUAL_SELL)
        }
    }

    private fun startTradingService(action: String) {
        val amount = (manualAmountInput.text.toString().trim().toDoubleOrNull() ?: secureStorage.getManualTradeAmountUsd()).coerceAtLeast(1.0)
        val stop = (manualStopInput.text.toString().trim().toDoubleOrNull() ?: secureStorage.getStopLossPercent() * 100.0).coerceAtLeast(0.0) / 100.0
        val target = (manualTakeProfitInput.text.toString().trim().toDoubleOrNull() ?: secureStorage.getTakeProfitPercent() * 100.0).coerceAtLeast(0.0) / 100.0
        val intent = Intent(this, TradingService::class.java).apply {
            this.action = action
            putExtra("apiKey", secureStorage.getApiKey(tradingMode))
            putExtra("apiSecret", secureStorage.getApiSecret(tradingMode))
                putExtra(TradingService.EXTRA_SYMBOL, market.symbol)
                putExtra(TradingService.EXTRA_LIVE_MODE, tradingMode == TradingMode.LIVE)
            putExtra(TradingService.EXTRA_DAILY_BUDGET_USD, secureStorage.getDailyBudgetUsd())
            putExtra(TradingService.EXTRA_STOP_LOSS_PERCENT, stop)
            putExtra(TradingService.EXTRA_TRAILING_ACTIVATION_PERCENT, secureStorage.getTrailingActivationPercent())
            putExtra(TradingService.EXTRA_TAKE_PROFIT_PERCENT, target)
            putExtra(TradingService.EXTRA_TRADE_AMOUNT_USD, amount)
            putExtra(TradingService.EXTRA_AUTO_MODE, autoModeSwitch.isChecked)
            putExtra(TradingService.EXTRA_AUTO_EXIT, autoExitSwitch.isChecked)
        }
        startForegroundService(intent)
    }

    private fun showOrderStatus(message: String, textColor: Int) {
        orderStatusText.visibility = View.VISIBLE
        orderStatusText.text = message
        orderStatusText.setTextColor(textColor)
        orderStatusHideRunnable?.let { orderStatusHideHandler.removeCallbacks(it) }
        val runnable = Runnable { orderStatusText.visibility = View.GONE }
        orderStatusHideRunnable = runnable
        // Keep the final Filled/Rejected result visible for a few seconds, then clear —
        // "Submitted" (no auto-hide scheduled below) stays up until it resolves.
        if (!message.startsWith("Order submitted")) {
            orderStatusHideHandler.postDelayed(runnable, 6000L)
        }
    }

    // Card visible only while locked AND expanded; floating pill visible
    // while locked AND collapsed; both hidden once unlocked.
    private fun updateReconcileVisibility() {
        if (reconcileLocked && reconcileExpanded) {
            reconcileCard.visibility = View.VISIBLE
            reconcileFab.visibility = View.GONE
            controlsLockBanner.visibility = View.VISIBLE
        } else if (reconcileLocked) {
            reconcileCard.visibility = View.GONE
            reconcileFab.visibility = View.VISIBLE
            controlsLockBanner.visibility = View.VISIBLE
        } else {
            reconcileCard.visibility = View.GONE
            reconcileFab.visibility = View.GONE
            controlsLockBanner.visibility = View.GONE
        }
    }

    private fun confirmReconcile(adopt: Boolean) {
        val title = if (adopt) "Adopt exchange balance?" else "Clear the lock?"
        val message = if (adopt)
            "This will set your local open position to match the BTC balance currently shown by the exchange, using the current price as the entry price. Only do this if that BTC is really yours from a trade this app placed or you intend to manage."
        else
            "This clears the trading lock WITHOUT changing your local position record. Only do this if you're sure the exchange's BTC balance is stale data or not something this bot should track (e.g. dust, or funds you manage elsewhere)."
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(if (adopt) "Adopt" else "Clear lock") { _, _ -> startReconcile(adopt) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startReconcile(adopt: Boolean) {
        startForegroundService(Intent(this, TradingService::class.java).apply {
            action = TradingService.ACTION_RECONCILE
            putExtra("apiKey", secureStorage.getApiKey(tradingMode))
            putExtra("apiSecret", secureStorage.getApiSecret(tradingMode))
                putExtra(TradingService.EXTRA_SYMBOL, market.symbol)
                putExtra(TradingService.EXTRA_LIVE_MODE, tradingMode == TradingMode.LIVE)
            putExtra(TradingService.EXTRA_RECONCILE_ADOPT, adopt)
        })
    }

    private fun resumeAutoBuyAfterCircuitBreaker() {
        AlertDialog.Builder(this)
            .setTitle("Resume automatic BUY?")
            .setMessage("Only do this once you've confirmed your connection (or Binance's API) is actually working again. It will take effect on the next successful check, not instantly.")
            .setPositiveButton("Resume") { _, _ ->
                startForegroundService(Intent(this, TradingService::class.java).apply {
                    action = TradingService.ACTION_RESUME_AUTO_BUY
                })
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setupBitcoinRangeButtons() {
        val ranges = listOf(
            R.id.btcRange5m to ("5 min" to "5m"),
            R.id.btcRange10m to ("10 min" to "10m"),
            R.id.btcRange30m to ("30 min" to "30m"),
            R.id.btcRange1h to ("1 hour" to "1h"),
            R.id.btcRange15m to ("15m" to "15m"),
            R.id.btcRange4h to ("4h" to "4h")
        )
        for ((id, range) in ranges) {
            findViewById<Button>(id).setOnClickListener { view ->
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                loadBitcoinInterval(range.first, range.second)
            }
        }
        findViewById<Button>(R.id.btcRange5mCandles).apply {
            text = "1m"
            setOnClickListener { view ->
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                loadBitcoinInterval("1 min", "1m")
            }
        }
        var emaVisible = true
        findViewById<Button>(R.id.btcToggleEma).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            emaVisible = !emaVisible
            btcPriceChart.setShowEma(emaVisible)
            view.findViewById<Button>(R.id.btcToggleEma)
            (view as Button).text = if (emaVisible) "EMA ✓" else "EMA"
        }
        loadBitcoinInterval("5 min", "5m")
    }

    private fun aggregateCustom10m(source: List<ChartCandle>): List<ChartCandle> {
        if (source.isEmpty()) return emptyList()
        val out = mutableListOf<ChartCandle>()
        for (c in source) {
            val bucket = (c.openTime / 600_000L) * 600_000L
            val last = out.lastOrNull()
            if (last == null || last.openTime != bucket) {
                out.add(c.copy(openTime = bucket, closed = true))
            } else {
                out[out.lastIndex] = last.copy(
                    high = maxOf(last.high, c.high),
                    low = minOf(last.low, c.low),
                    close = c.close,
                    volume = last.volume + c.volume,
                    closed = true
                )
            }
        }
        return out
    }

    private fun windowReferencePrice(candles: List<ChartCandle>, interval: String): Double {
        if (candles.size < 2) return 0.0
        val windowMs = when (interval) {
            "1m" -> 60_000L; "3m" -> 180_000L; "5m" -> 300_000L; "10m" -> 600_000L
            "15m" -> 900_000L; "30m" -> 1_800_000L; "1h" -> 3_600_000L; "2h" -> 7_200_000L
            "4h" -> 14_400_000L; "6h" -> 21_600_000L; "8h" -> 28_800_000L; "12h" -> 43_200_000L
            "1d" -> 86_400_000L; "3d" -> 259_200_000L; "1w" -> 604_800_000L; else -> 0L
        }
        val last = candles.last()
        val start = if (windowMs > 0L)
            candles.lastOrNull { candle -> candle.openTime <= last.openTime - windowMs } ?: candles.dropLast(1).first()
        else candles.dropLast(1).first()
        return start.close.takeIf { value -> value > 0.0 } ?: 0.0
    }

    private fun selectedWindowChangePercent(candles: List<ChartCandle>, interval: String): Double {
        val ref = windowReferencePrice(candles, interval)
        val last = candles.lastOrNull()?.close ?: 0.0
        return if (ref > 0.0 && last > 0.0) (last - ref) / ref * 100.0 else 0.0
    }

    private fun updateBtcChange(priceNow: Double) {
        if (btcWindowReferencePrice <= 0.0 || priceNow <= 0.0) return
        val change = (priceNow - btcWindowReferencePrice) / btcWindowReferencePrice * 100.0
        btcChangeText.text = String.format(
            Locale.US,
            "%s%.2f%%  ·  %s",
            if (change >= 0) "+" else "",
            change,
            if (change >= 0) "Up" else "Down"
        )
        btcChangeText.setTextColor(if (change >= 0) color(R.color.positive) else color(R.color.negative))
    }

    private fun loadBitcoinInterval(label: String, interval: String) {
        btcSelectedInterval = interval
        btcSelectedRangeLabel = label
        btcRangeLabel.text = "${market.pairLabel} · $label · Binance connecting…"
        btcChangeText.text = "Loading…"
        btcReconnectJob?.cancel()
        stopBitcoinMarketSocket()
        btc10mParts.clear()
        btcWindowReferencePrice = 0.0
        btcLoadJob?.cancel()
        btcLoadJob = lifecycleScope.launch {
            try {
                val finalCandles = withContext(Dispatchers.IO) {
                    val api = BinanceApiClient("", "", true)
                    val requestInterval = if (interval == "10m") "1m" else interval
                    val candlesJson = api.getMainnetKlines(market.symbol, requestInterval, if (interval == "10m") 1200 else 240)
                    val candles = buildList {
                        for (i in 0 until candlesJson.length()) {
                            val c = candlesJson.getJSONArray(i)
                            val openTime = c.optLong(0)
                            val open = c.optString(1).toDoubleOrNull() ?: continue
                            val high = c.optString(2).toDoubleOrNull() ?: continue
                            val low = c.optString(3).toDoubleOrNull() ?: continue
                            val close = c.optString(4).toDoubleOrNull() ?: continue
                            val volume = c.optString(5).toDoubleOrNull() ?: 0.0
                            add(ChartCandle(openTime, open, high, low, close, volume, true))
                        }
                    }
                    val now = System.currentTimeMillis()
                    val baseMs = when (requestInterval) {
                        "1m" -> 60_000L; "3m" -> 180_000L; "5m" -> 300_000L; "15m" -> 900_000L;
                        "30m" -> 1_800_000L; "1h" -> 3_600_000L; "2h" -> 7_200_000L; "4h" -> 14_400_000L;
                        "6h" -> 21_600_000L; "8h" -> 28_800_000L; "12h" -> 43_200_000L; "1d" -> 86_400_000L;
                        "3d" -> 259_200_000L; "1w" -> 604_800_000L; "1M" -> 0L; else -> 0L
                    }
                    val normalized = if (baseMs > 0L && candles.isNotEmpty()) {
                        candles.mapIndexed { index, c ->
                            val closed = if (index == candles.lastIndex) now >= c.openTime + baseMs else true
                            c.copy(closed = closed)
                        }
                    } else candles
                    if (interval == "10m") {
                        normalized.takeLast(1200).forEach { candle -> btc10mParts[candle.openTime] = candle }
                        aggregateCustom10m(normalized)
                    } else normalized
                }
                if (finalCandles.size >= 2) {
                    val last = finalCandles.last().close
                    val change = selectedWindowChangePercent(finalCandles, interval)
                    btcWindowReferencePrice = windowReferencePrice(finalCandles, interval)
                    btcPriceChart.setCandles(finalCandles)
                    ChartDataBus.updateCandles(finalCandles)
                    ChartDataBus.updateRangeLabel(btcRangeLabel.text.toString())
                    btcCurrentPriceText.text = price(last)
                    btcChangeText.text = String.format(Locale.US, "%s%.2f%%  ·  %s", if (change >= 0) "+" else "", change, if (change >= 0) "Up" else "Down")
                    btcChangeText.setTextColor(if (change >= 0) color(R.color.positive) else color(R.color.negative))
                    startBitcoinMarketSocket(interval)
                } else {
                    btcChangeText.text = "No market data"
                }
            } catch (e: Exception) {
                btcChangeText.text = "Binance market data unavailable"
                TradingService.onLog?.invoke("BTC Binance chart failed: ${e.message}")
            }
        }
    }

    private fun startBitcoinMarketSocket(interval: String) {
        val streamInterval = if (interval == "10m") "1m" else interval
        stopBitcoinMarketSocket()
        btcReconnectJob?.cancel()
        val request = Request.Builder().url("wss://stream.binance.com:9443/ws/${market.symbol.lowercase()}@kline_$streamInterval").build()
        btcMarketClient = OkHttpClient.Builder()
            .pingInterval(20, TimeUnit.SECONDS)
            .build()
        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                runOnUiThread { btcRangeLabel.text = "${market.pairLabel} · $btcSelectedRangeLabel · Binance LIVE" }
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val root = JSONObject(text)
                    val k = root.getJSONObject("k")
                    val candle = ChartCandle(
                        k.getLong("t"),
                        k.getString("o").toDouble(),
                        k.getString("h").toDouble(),
                        k.getString("l").toDouble(),
                        k.getString("c").toDouble(),
                        k.getString("v").toDouble(),
                        k.getBoolean("x")
                    )
                    val displayCandle = if (interval == "10m") {
                        btc10mParts[candle.openTime] = candle
                        while (btc10mParts.size > 1200) btc10mParts.remove(btc10mParts.keys.first())
                        val latestBucket = (candle.openTime / 600_000L) * 600_000L
                        val parts = btc10mParts.values.filter { candle -> (candle.openTime / 600_000L) * 600_000L == latestBucket }.sortedBy { candle -> candle.openTime }
                        if (parts.isEmpty()) candle else ChartCandle(
                            openTime = latestBucket,
                            open = parts.first().open,
                            high = parts.maxOf { candle -> candle.high },
                            low = parts.minOf { candle -> candle.low },
                            close = parts.last().close,
                            volume = parts.sumOf { candle -> candle.volume },
                            closed = parts.all { candle -> candle.closed }
                        )
                    } else candle
                    val nowUi = System.currentTimeMillis()
                    // Binance can deliver multiple kline updates per second.
                    // Keep the feed real-time, but cap chart rendering to ~10 FPS
                    // so the Android UI stays smooth on lower-end devices.
                    if (displayCandle.closed || nowUi - lastBtcChartUiUpdateMs >= 100L) {
                        lastBtcChartUiUpdateMs = nowUi
                        runOnUiThread {
                            btcPriceChart.updateLast(displayCandle)
                            ChartDataBus.updateLastCandle(displayCandle)
                            btcCurrentPriceText.text = price(displayCandle.close)
                            updateBtcChange(displayCandle.close)
                        }
                    }
                } catch (e: Exception) {
                    TradingService.onLog?.invoke("BTC websocket parse failed: ${e.message}")
                }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread { btcRangeLabel.text = "${market.pairLabel} · $btcSelectedRangeLabel · reconnecting…" }
                scheduleBitcoinReconnect(interval)
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) btcRangeLabel.text = "${market.pairLabel} · $btcSelectedRangeLabel · reconnecting…"
                }
                scheduleBitcoinReconnect(interval)
            }
        }
        btcMarketWebSocket = btcMarketClient!!.newWebSocket(request, listener)
    }

    private fun scheduleBitcoinReconnect(interval: String) {
        if (isFinishing || isDestroyed) return
        btcReconnectJob?.cancel()
        btcReconnectJob = lifecycleScope.launch {
            kotlinx.coroutines.delay(2000)
            if (isActive && interval == btcSelectedInterval && !isFinishing && !isDestroyed) {
                startBitcoinMarketSocket(interval)
            }
        }
    }

    private fun stopBitcoinMarketSocket() {
        btcMarketWebSocket?.close(1000, "chart interval changed")
        btcMarketWebSocket = null
        btcMarketClient?.dispatcher?.executorService?.shutdown()
        btcMarketClient = null
        btcReconnectJob?.cancel()
        btcReconnectJob = null
    }

    /**
     * Wires the "AI Auto-Signal" card: a saved OpenAI key + on/off switch that
     * TradingService reads every cycle (see maybeRunAiAutoSignal). Nothing
     * here talks to OpenAI directly -- this screen only persists the key and
     * the toggle, so the background service can act on them on market events.
     * It never places or sizes an order; it only decides whether to notify.
     */
    private fun setupAiTradingGateControls() {
        aiTradeGateThresholdInput.setText(String.format(Locale.US, "%.0f", secureStorage.getAiTradeGateThreshold()))
        aiTradeGateSwitch.isChecked = secureStorage.getAiTradeGateEnabled()
        tradingViewRelayUrlInput.setText(secureStorage.getTradingViewRelayUrl())
        tradingViewRelayTokenInput.setText(secureStorage.getTradingViewRelayToken())
        tradingViewMaxAgeInput.setText(secureStorage.getTradingViewMaxAgeMinutes().toString())
        tradingViewGateSwitch.isChecked = secureStorage.getTradingViewGateEnabled()
        updateAiTradingGateStatus()
        updateTradingViewGateStatus()

        fun saveAiSettings() {
            val threshold = aiTradeGateThresholdInput.text.toString().toDoubleOrNull()
            if (threshold != null && threshold in 1.0..100.0) secureStorage.saveAiTradeGateThreshold(threshold)
        }
        aiTradeGateThresholdInput.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) { saveAiSettings(); updateAiTradingGateStatus() } }
        aiTradeGateSwitch.setOnCheckedChangeListener { view, checked ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            val key = secureStorage.getOpenAiApiKey()
            if (checked && key.isBlank()) {
                aiTradeGateSwitch.isChecked = false
                aiTradeGateStatusText.text = "Add an OpenAI key in the AI Auto-Signal card first."
                return@setOnCheckedChangeListener
            }
            saveAiSettings()
            secureStorage.saveAiTradeGateEnabled(checked)
            updateAiTradingGateStatus()
        }

        fun saveTvSettings() {
            secureStorage.saveTradingViewRelayUrl(tradingViewRelayUrlInput.text.toString())
            secureStorage.saveTradingViewRelayToken(tradingViewRelayTokenInput.text.toString())
            val age = tradingViewMaxAgeInput.text.toString().toIntOrNull()
            if (age != null && age in 1..120) secureStorage.saveTradingViewMaxAgeMinutes(age)
        }
        tradingViewRelayUrlInput.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) { saveTvSettings(); updateTradingViewGateStatus() } }
        tradingViewRelayTokenInput.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) { saveTvSettings(); updateTradingViewGateStatus() } }
        tradingViewMaxAgeInput.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) { saveTvSettings(); updateTradingViewGateStatus() } }
        tradingViewGateSwitch.setOnCheckedChangeListener { view, checked ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            saveTvSettings()
            if (checked && (tradingViewRelayUrlInput.text.toString().isBlank() || tradingViewRelayTokenInput.text.toString().isBlank())) {
                tradingViewGateSwitch.isChecked = false
                tradingViewGateStatusText.text = "Enter the VPS relay URL and token first."
                return@setOnCheckedChangeListener
            }
            secureStorage.saveTradingViewGateEnabled(checked)
            updateTradingViewGateStatus()
        }
    }

    private fun updateAiTradingGateStatus() {
        val threshold = secureStorage.getAiTradeGateThreshold().toInt()
        aiTradeGateStatusText.text = if (secureStorage.getAiTradeGateEnabled())
            "ON. A strategy BUY must pass the deterministic snapshot validator, Bull/Bear debate, structured AI validation, and conservative risk challenge at ${threshold}%+ confidence. AI cannot bypass hard risk controls and cannot place orders."
        else "OFF. Strategy and hard risk controls operate as before. Turn this on only after testing the AI gate on Testnet."
        updateHomeAutomationSummary()
    }

    private fun updateTradingViewGateStatus() {
        tradingViewGateStatusText.text = if (secureStorage.getTradingViewGateEnabled())
            "ON. A new BUY also requires a recent BUY signal from your TradingView → VPS relay. Protective exits are never blocked by this gate."
        else "OFF. TradingView is optional. The relay is an additional confirmation layer, not an order executor."
        updateHomeAutomationSummary()
    }

    /**
     * One plain-language line on Home describing exactly what the bot will
     * decide on its own right now, so the person doesn't have to open
     * settings to know what's active. Called whenever auto mode or either
     * gate changes. Purely informational — never shows a popup and never
     * changes any setting itself.
     */
    private fun updateHomeAutomationSummary() {
        if (!::homeAutomationSummaryText.isInitialized) return
        val autoOn = ::autoModeSwitch.isInitialized && autoModeSwitch.isChecked
        val aiGateOn = secureStorage.getAiTradeGateEnabled()
        val tvGateOn = secureStorage.getTradingViewGateEnabled()
        val aiThreshold = secureStorage.getAiTradeGateThreshold().toInt()
        val tvMaxAge = secureStorage.getTradingViewMaxAgeMinutes()

        homeAutomationSummaryText.text = buildString {
            if (!autoOn) {
                append("MANUAL mode — you place every trade yourself. Turn on AUTO in Position to let the bot decide.")
                return@buildString
            }
            append("AUTO mode — the bot decides entries and exits on its own. ")
            when {
                aiGateOn && tvGateOn -> append(
                    "Before buying, it silently checks: AI approval at ${aiThreshold}%+ confidence, " +
                        "AND a TradingView signal no older than $tvMaxAge min. No popups — it just waits " +
                        "quietly if either check isn't met."
                )
                aiGateOn -> append(
                    "Before buying, it silently requires AI approval at ${aiThreshold}%+ confidence. " +
                        "No TradingView confirmation required."
                )
                tvGateOn -> append(
                    "Before buying, it silently requires a TradingView signal no older than $tvMaxAge min. " +
                        "No AI confidence check required."
                )
                else -> append("No extra AI or TradingView checks — it acts on its own strategy signal alone.")
            }
            append(" Daily/session budgets and the loss circuit breaker always apply and can't be bypassed.")
        }
    }

    private fun setupAiAutoSignalControls() {
        aiAutoSignalKeyInput.setText(secureStorage.getOpenAiApiKey())
        aiAutoSignalSwitch.isChecked = secureStorage.getAiAutoSignalEnabled()
        updateAiAutoSignalStatusText()

        aiAutoSignalKeyInput.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                secureStorage.saveOpenAiApiKey(aiAutoSignalKeyInput.text.toString().trim())
                updateAiAutoSignalStatusText()
            }
        }

        aiAutoSignalSwitch.setOnCheckedChangeListener { view, checked ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            val key = aiAutoSignalKeyInput.text.toString().trim()
            if (checked && key.isBlank()) {
                aiAutoSignalSwitch.isChecked = false
                aiAutoSignalStatusText.text = "Paste your OpenAI API key above first, then turn this on."
                return@setOnCheckedChangeListener
            }
            secureStorage.saveOpenAiApiKey(key)
            secureStorage.saveAiAutoSignalEnabled(checked)
            updateAiAutoSignalStatusText()
        }
    }

    private fun updateAiAutoSignalStatusText() {
        val threshold = secureStorage.getAiAutoSignalThreshold().toInt()
        aiAutoSignalStatusText.text = if (secureStorage.getAiAutoSignalEnabled()) {
            "On. Studying BTC's indicators + this bot's own trade history about on market events. " +
                "You'll only get a notification when it comes back at $threshold% confidence or higher. " +
                "It never places a trade — the bot's own rules and risk locks still decide that."
        } else {
            "Off. Paste your own key (platform.openai.com) and turn this on to get a notification " +
                "whenever the AI reads BTC's indicators + this bot's own trade history and comes back " +
                "at $threshold% confidence or higher. It only alerts you — it never places a trade."
        }
    }

    /**
     * Dedicated "AI" tab: a live feed of what the AI Auto-Signal actually saw
     * and thought, on market events, instead of only surfacing a notification
     * when it clears the 85% threshold. Each entry is a small screenshot of
     * the candlestick chart at capture time plus the model's signal,
     * confidence, and reasoning for that exact frame -- so switching to this
     * tab shows the AI's work, not just its occasional alerts.
     */
    private val manualAiImagePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) runManualAiAnalysis(uri)
    }

    private fun setupManualAiUpload() {
        aiUploadButton.setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            manualAiImagePicker.launch("image/*")
        }
    }

    private fun refreshAiProviderStatus() {
        aiProviderStatusText.text = buildString {
            append("Active provider: ${secureStorage.getAiProviderStatus()}")
            val warning = secureStorage.getAiCreditWarning()
            if (warning.isNotBlank()) append("\n⚠ ${warning.take(180)}")
        }
    }

    private fun runAutomatedAiVisionAnalysis() {
        val bitmap = renderOffscreenChartBitmap() ?: return
        val captureId = AiCaptureStore.startCapture(bitmap, lastSnap.price)
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val output = ByteArrayOutputStream()
                bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 90, output)
                val encoded = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
                val snapshot = AiSignalAdvisor.FullSnapshot(
                    price = lastSnap.price, botSignal = lastSnap.signal, botReason = lastSnap.reason,
                    bullishScore = lastBullishScore, bearishScore = lastBearishScore,
                    ruleQuality = lastSignalQuality, rsi = lastRsi, emaFast = lastEmaFast,
                    emaSlow = lastEmaSlow, atrPercent = lastAtrPercent, trendStrength = lastTrendStrength,
                    positionOpen = lastKnownPositionOpen, entry = 0.0, qty = 0.0,
                    dailyPnlPercent = 0.0, remainingBudgetUsd = 0.0, tradingLocked = false,
                    totalTrades = lastTotalTrades, winRatePercent = lastWinRatePercent,
                    consecutiveLosses = lastConsecutiveLosses, recentClosedPrices = lastRecentCloses
                )
                val result = AiSignalAdvisor.evaluateWithFallback(
                    secureStorage.getOpenAiApiKey(), secureStorage.getXaiApiKey(),
                    secureStorage.getAnthropicApiKey(), secureStorage.getCustomVisionEndpoint(),
                    snapshot, encoded
                )
                AiCaptureStore.completeCapture(captureId, result.verdict)
                TradeHistoryStore(this@DashboardActivity).appendAiAnalysis(
                    timestampMs = System.currentTimeMillis(), source = "AUTOMATED_EVENT_VISION",
                    provider = result.provider, price = snapshot.price, signal = result.verdict.signal.name,
                    probability = result.verdict.probability, reasoning = result.verdict.reasoning,
                    entry = snapshot.price, takeProfit = result.verdict.suggestedTakeProfitPrice,
                    stopLoss = result.verdict.suggestedStopLossPrice, riskReward = result.verdict.riskRewardRatio,
                    horizon = result.verdict.horizon
                )
                secureStorage.saveAiProviderStatus(result.provider, "available", result.warnings.joinToString(" | "))
                withContext(Dispatchers.Main) {
                    refreshAiProviderStatus()
                    refreshAiTabUi()
                }
            } catch (e: Exception) {
                AiCaptureStore.failCapture(captureId, e.message ?: "Vision analysis failed")
                withContext(Dispatchers.Main) { refreshAiProviderStatus(); refreshAiTabUi() }
            }
        }
    }

    private fun runManualAiAnalysis(uri: android.net.Uri) {
        val bitmap = try {
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) { null }

        if (bitmap == null) {
            aiProviderStatusText.text = "Could not read selected image."
            return
        }

        val scaled = bitmap.copy(Bitmap.Config.ARGB_8888, false)
        val captureId = AiCaptureStore.startCapture(scaled, lastSnap.price)
        aiProviderStatusText.text = "Analyzing uploaded chart…"
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val output = ByteArrayOutputStream()
                scaled.compress(android.graphics.Bitmap.CompressFormat.PNG, 90, output)
                val encoded = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
                val snapshot = AiSignalAdvisor.FullSnapshot(
                    price = lastSnap.price,
                    botSignal = lastSnap.signal,
                    botReason = lastSnap.reason,
                    bullishScore = lastBullishScore,
                    bearishScore = lastBearishScore,
                    ruleQuality = lastSignalQuality,
                    rsi = lastRsi,
                    emaFast = lastEmaFast,
                    emaSlow = lastEmaSlow,
                    atrPercent = lastAtrPercent,
                    trendStrength = lastTrendStrength,
                    positionOpen = lastKnownPositionOpen,
                    entry = 0.0,
                    qty = 0.0,
                    dailyPnlPercent = 0.0,
                    remainingBudgetUsd = 0.0,
                    tradingLocked = false,
                    totalTrades = lastTotalTrades,
                    winRatePercent = lastWinRatePercent,
                    consecutiveLosses = lastConsecutiveLosses,
                    recentClosedPrices = lastRecentCloses,
                    indicatorsAvailable = true
                )
                val result = AiSignalAdvisor.evaluateWithFallback(
                    secureStorage.getOpenAiApiKey(),
                    secureStorage.getXaiApiKey(),
                    secureStorage.getAnthropicApiKey(),
                    secureStorage.getCustomVisionEndpoint(),
                    snapshot,
                    encoded
                )
                AiCaptureStore.completeCapture(captureId, result.verdict)
                TradeHistoryStore(this@DashboardActivity).appendAiAnalysis(
                    timestampMs = System.currentTimeMillis(),
                    source = "MANUAL_IMAGE",
                    provider = result.provider,
                    price = snapshot.price,
                    signal = result.verdict.signal.name,
                    probability = result.verdict.probability,
                    reasoning = result.verdict.reasoning,
                    entry = snapshot.price,
                    takeProfit = result.verdict.suggestedTakeProfitPrice,
                    stopLoss = result.verdict.suggestedStopLossPrice,
                    riskReward = result.verdict.riskRewardRatio,
                    horizon = result.verdict.horizon
                )
                secureStorage.saveAiProviderStatus(result.provider, "available", result.warnings.joinToString(" | "))
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    refreshAiProviderStatus()
                    refreshAiTabUi()
                }
            } catch (e: Exception) {
                AiCaptureStore.failCapture(captureId, e.message ?: "Analysis failed")
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    aiProviderStatusText.text = "Analysis failed safely: ${e.message ?: "unknown error"}"
                    refreshAiTabUi()
                }
            } finally {
                // Keep the scaled bitmap alive because AiCaptureStore displays it as a thumbnail.
                if (bitmap !== scaled && !bitmap.isRecycled) bitmap.recycle()
            }
        }
    }

    private fun setupAiTab() {
        aiLatestThumbnail = findViewById(R.id.aiLatestThumbnail)
        aiLatestPlaceholder = findViewById(R.id.aiLatestPlaceholder)
        aiLatestSignalText = findViewById(R.id.aiLatestSignalText)
        aiLatestReasoningText = findViewById(R.id.aiLatestReasoningText)
        aiLatestTimeText = findViewById(R.id.aiLatestTimeText)
        aiLatestOutlookBox = findViewById(R.id.aiLatestOutlookBox)
        aiLatestOutlookText = findViewById(R.id.aiLatestOutlookText)
        aiLatestProfitText = findViewById(R.id.aiLatestProfitText)
        aiLatestLevelsText = findViewById(R.id.aiLatestLevelsText)
        aiLatestRiskBadge = findViewById(R.id.aiLatestRiskBadge)
        aiHistoryContainer = findViewById(R.id.aiHistoryContainer)
        populateGuideCards()
        refreshAiTabUi()
    }

    /**
     * One entry per "Tips & guide" card shown at the bottom of the AI &
     * Profile tab. Previously these 5 cards were duplicated verbatim in
     * activity_dashboard.xml (~35 lines each, identical except for these
     * four fields) -- now there's exactly one place to add, remove, or
     * reword a guide card.
     */
    private data class GuideCardEntry(
        val title: String,
        val imageRes: Int,
        val imageContentDescription: String,
        val description: String
    )

    private val guideCardEntries = listOf(
        GuideCardEntry(
            title = "1. Home - market snapshot",
            imageRes = R.drawable.tip_home,
            imageContentDescription = "Illustration of the Home tab showing equity, price chart, and signal",
            description = "Check total equity, available balance, current BTC price, the bot signal, and its reason together. A green number or BUY signal is context, not a promise; wait for fresh data and your own risk plan."
        ),
        GuideCardEntry(
            title = "2. Position - manage an open trade",
            imageRes = R.drawable.tip_position,
            imageContentDescription = "Illustration of the Position tab showing entry, protection levels, and sell-now net result",
            description = "When a position is open, confirm the entry, quantity, stop-loss, target, and protection status. \u201cIf you sell right now\u201d estimates net P&L after fees, TDS, and tax using the current displayed price - it helps compare outcomes, but the live fill can differ."
        ),
        GuideCardEntry(
            title = "3. Controls - plan risk first",
            imageRes = R.drawable.tip_controls,
            imageContentDescription = "Illustration of the Controls tab workflow from strategy through risk and confirmation",
            description = "Choose a strategy, then set trade amount, stop loss, take profit, and auto-exit before starting. AUTO follows the selected strategy; MANUAL requires BUY NOW. Disabled buttons or a lock banner mean the bot is deliberately preventing a new entry until it is safe to continue."
        ),
        GuideCardEntry(
            title = "4. History - measure net results",
            imageRes = R.drawable.tip_history,
            imageContentDescription = "Illustration of the History tab showing completed trades and cost-adjusted net profit or loss",
            description = "Review completed trades, the win rate, gross P&L, and estimated fees, TDS, and tax. This is where you can see whether a strategy remains useful after costs rather than focusing only on winning trades."
        ),
        GuideCardEntry(
            title = "5. AI & Profile - review and secure setup",
            imageRes = R.drawable.tip_profile,
            imageContentDescription = "Illustration of AI and Profile features including activity, testnet keys, and advisory AI",
            description = "Use Activity to read bot events and lock reasons. Store only Binance Testnet credentials here. AI chart analysis and alerts are optional second opinions; they never place trades and should not override stop-losses, hard locks, or your own judgment."
        )
    )

    private fun populateGuideCards() {
        val container = findViewById<android.widget.LinearLayout>(R.id.guideCardsContainer)
        if (container.childCount > 0) return // avoid duplicating on a second call
        val inflater = layoutInflater
        for (entry in guideCardEntries) {
            val card = inflater.inflate(R.layout.item_guide_card, container, false)
            card.findViewById<TextView>(R.id.guideCardTitle).text = entry.title
            card.findViewById<TextView>(R.id.guideCardDescription).text = entry.description
            val image = card.findViewById<android.widget.ImageView>(R.id.guideCardImage)
            image.setImageResource(entry.imageRes)
            image.contentDescription = entry.imageContentDescription
            container.addView(card)
        }
    }

    /**
     * Renders the current candle data into a brand-new, never-attached
     * BinanceCandlestickChartView and draws *that* to a bitmap, instead of
     * screenshotting the on-screen btcPriceChart directly. That matters
     * because the on-screen chart lives inside the Home tab pane, which sits
     * at View.GONE (zero size, undrawable) whenever you're on any other tab
     * -- capturing it directly would silently stop the "every 1 hour"
     * screenshot the moment you switch to Position/Controls/History/AI.
     * An offscreen render uses the same live candle data (btc10mParts) but
     * never depends on which tab happens to be visible.
     */
    private fun renderOffscreenChartBitmap(): android.graphics.Bitmap? {
        if (btc10mParts.isEmpty()) return null
        return try {
            val offscreen = BinanceCandlestickChartView(this)
            offscreen.setCandles(btc10mParts.values.toList())
            val widthPx = resources.displayMetrics.widthPixels
            val heightPx = dp(310)
            offscreen.measure(
                android.view.View.MeasureSpec.makeMeasureSpec(widthPx, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(heightPx, android.view.View.MeasureSpec.EXACTLY)
            )
            offscreen.layout(0, 0, widthPx, heightPx)
            val bmp = android.graphics.Bitmap.createBitmap(widthPx, heightPx, android.graphics.Bitmap.Config.ARGB_8888)
            offscreen.draw(android.graphics.Canvas(bmp))
            bmp
        } catch (e: Exception) {
            null
        }
    }

    private fun runAiCaptureCycle() {
        if (aiCaptureInFlight) return
        if (!secureStorage.getAiAutoSignalEnabled()) return
        val apiKey = secureStorage.getOpenAiApiKey()
        if (apiKey.isBlank()) return

        val bitmap = renderOffscreenChartBitmap() ?: return

        val thumbnail = android.graphics.Bitmap.createScaledBitmap(bitmap, 240, 150, true)
        val price = lastSnap.price
        val id = AiCaptureStore.startCapture(thumbnail, price)
        refreshAiTabUi()
        aiCaptureInFlight = true

        val snap = AiSignalAdvisor.FullSnapshot(
            price = price,
            botSignal = lastSnap.signal,
            botReason = lastSnap.reason,
            bullishScore = lastBullishScore,
            bearishScore = lastBearishScore,
            ruleQuality = lastSignalQuality,
            rsi = lastRsi,
            emaFast = lastEmaFast,
            emaSlow = lastEmaSlow,
            atrPercent = lastAtrPercent,
            trendStrength = lastTrendStrength,
            positionOpen = lastSnap.positionOpen,
            entry = lastSnap.entry,
            qty = lastSnap.qty,
            dailyPnlPercent = lastSnap.dailyPnlPercent,
            remainingBudgetUsd = lastSnap.remainingBudget,
            tradingLocked = lastSnap.tradingLocked,
            totalTrades = lastTotalTrades,
            winRatePercent = lastWinRatePercent,
            consecutiveLosses = lastConsecutiveLosses,
            recentClosedPrices = lastRecentCloses,
            // True whenever a real strategy readout has come through at least
            // once this session -- lets the vision model reason over the actual
            // indicators alongside the chart image, not just the image alone.
            indicatorsAvailable = lastSignalQuality > 0 || lastBullishScore > 0 || lastBearishScore > 0
        )

        lifecycleScope.launch {
            try {
                val imageBase64 = withContext(Dispatchers.Default) {
                    val out = java.io.ByteArrayOutputStream()
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 90, out)
                    android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
                }
                val verdict = withContext(Dispatchers.IO) {
                    AiSignalAdvisor.evaluateWithImage(apiKey, snap, imageBase64)
                }
                AiCaptureStore.completeCapture(id, verdict)
                val threshold = secureStorage.getAiAutoSignalThreshold()
                if (verdict.signal != AiSignalAdvisor.Signal.HOLD && verdict.probability >= threshold) {
                    // Mirrors TradingService's own notify-above-threshold rule so the
                    // vision pass gets the same courtesy alert as the numeric pass --
                    // it still never places, sizes, or cancels an order.
                    val profitNote = if (verdict.signal == AiSignalAdvisor.Signal.BUY && verdict.suggestedBuyUsd > 0) {
                        " — suggested $%,.2f, est. profit $%,.2f (%.1f%%) over next hour".format(
                            verdict.suggestedBuyUsd, verdict.estimatedProfitUsd, verdict.estimatedProfitPercent
                        )
                    } else ""
                    appendActivityLog("AI (vision) ${verdict.signal} @ ${"%.0f".format(verdict.probability)}% — ${verdict.reasoning}$profitNote")
                }
            } catch (e: Exception) {
                AiCaptureStore.failCapture(id, e.message ?: "Request failed")
            } finally {
                aiCaptureInFlight = false
                refreshAiTabUi()
            }
        }
    }

    private fun refreshAiTabUi() {
        if (!::aiHistoryContainer.isInitialized) return
        val captures = AiCaptureStore.all()
        val latest = captures.firstOrNull()
        if (latest == null) {
            aiLatestPlaceholder.visibility = View.VISIBLE
            aiLatestThumbnail.visibility = View.GONE
            aiLatestSignalText.text = ""
            aiLatestReasoningText.text = ""
            aiLatestTimeText.text = ""
            aiLatestOutlookBox.visibility = View.GONE
        } else {
            aiLatestPlaceholder.visibility = View.GONE
            aiLatestThumbnail.visibility = View.VISIBLE
            aiLatestThumbnail.setImageBitmap(latest.thumbnail)
            aiLatestTimeText.text = formatEntryTime(latest.timestampMs) + " · " + price(latest.price)
            when (latest.status) {
                AiCaptureStore.Status.RUNNING -> {
                    aiLatestSignalText.text = "Thinking…"
                    aiLatestSignalText.setTextColor(color(R.color.text_secondary))
                    aiLatestReasoningText.text = "Studying this screenshot + the bot's own numbers now."
                    aiLatestOutlookBox.visibility = View.GONE
                }
                AiCaptureStore.Status.DONE -> {
                    val sig = latest.signal ?: AiSignalAdvisor.Signal.HOLD
                    aiLatestSignalText.text = "${sig.name} · ${"%.0f".format(latest.probability)}%"
                    aiLatestSignalText.setTextColor(
                        when (sig) {
                            AiSignalAdvisor.Signal.BUY -> color(R.color.positive)
                            AiSignalAdvisor.Signal.SELL -> color(R.color.negative)
                            else -> color(R.color.text_primary)
                        }
                    )
                    aiLatestReasoningText.text = latest.reasoning
                    if (latest.nextHourOutlook.isNotBlank()) {
                        aiLatestOutlookBox.visibility = View.VISIBLE
                        aiLatestOutlookText.text = latest.nextHourOutlook

                        if (latest.riskLevel.isNotBlank()) {
                            aiLatestRiskBadge.visibility = View.VISIBLE
                            aiLatestRiskBadge.text = "${latest.riskLevel} RISK"
                            val riskColor = when (latest.riskLevel) {
                                "LOW" -> color(R.color.positive)
                                "HIGH" -> color(R.color.negative)
                                else -> color(R.color.warning)
                            }
                            aiLatestRiskBadge.setTextColor(riskColor)
                        } else {
                            aiLatestRiskBadge.visibility = View.GONE
                        }

                        val levelParts = mutableListOf<String>()
                        if (latest.keySupport > 0) levelParts += "Support ${price(latest.keySupport)}"
                        if (latest.keyResistance > 0) levelParts += "Resistance ${price(latest.keyResistance)}"
                        if (sig == AiSignalAdvisor.Signal.BUY) {
                            if (latest.suggestedStopLossPrice > 0) levelParts += "Stop ${price(latest.suggestedStopLossPrice)}"
                            if (latest.suggestedTakeProfitPrice > 0) levelParts += "Target ${price(latest.suggestedTakeProfitPrice)}"
                            if (latest.riskRewardRatio > 0) levelParts += "R:R ${"%.1f".format(latest.riskRewardRatio)}"
                        }
                        if (levelParts.isNotEmpty()) {
                            aiLatestLevelsText.visibility = View.VISIBLE
                            aiLatestLevelsText.text = levelParts.joinToString("  ·  ")
                        } else {
                            aiLatestLevelsText.visibility = View.GONE
                        }

                        if (sig == AiSignalAdvisor.Signal.BUY && latest.suggestedBuyUsd > 0) {
                            aiLatestProfitText.visibility = View.VISIBLE
                            aiLatestProfitText.text = "Suggested buy: $%,.2f  →  est. profit $%,.2f (%.1f%%)".format(
                                latest.suggestedBuyUsd, latest.estimatedProfitUsd, latest.estimatedProfitPercent
                            )
                        } else {
                            aiLatestProfitText.visibility = View.GONE
                        }
                    } else {
                        aiLatestOutlookBox.visibility = View.GONE
                    }
                }
                AiCaptureStore.Status.FAILED -> {
                    aiLatestSignalText.text = "Failed"
                    aiLatestSignalText.setTextColor(color(R.color.negative))
                    aiLatestReasoningText.text = latest.error ?: "Request failed."
                    aiLatestOutlookBox.visibility = View.GONE
                }
            }
        }

        // Rebuild the history list below the latest card. Bounded to 40
        // entries by AiCaptureStore, so this rebuild is always cheap.
        aiHistoryContainer.removeAllViews()
        for (capture in captures.drop(1)) {
            aiHistoryContainer.addView(buildAiHistoryRow(capture))
        }
    }

    private fun buildAiHistoryRow(capture: AiCaptureStore.Capture): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(10)
            }
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        row.addView(android.widget.ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(35))
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            capture.thumbnail?.let { setImageBitmap(it) }
        })
        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(10)
            }
        }
        val (label, labelColor) = when (capture.status) {
            AiCaptureStore.Status.RUNNING -> "Thinking…" to color(R.color.text_secondary)
            AiCaptureStore.Status.DONE -> "${capture.signal?.name ?: "HOLD"} · ${"%.0f".format(capture.probability)}%" to
                when (capture.signal) {
                    AiSignalAdvisor.Signal.BUY -> color(R.color.positive)
                    AiSignalAdvisor.Signal.SELL -> color(R.color.negative)
                    else -> color(R.color.text_primary)
                }
            AiCaptureStore.Status.FAILED -> "Failed" to color(R.color.negative)
        }
        textCol.addView(TextView(this).apply {
            text = "${formatEntryTime(capture.timestampMs)} · $label"
            textSize = 12f
            setTextColor(labelColor)
        })
        textCol.addView(TextView(this).apply {
            val reasoningLine = if (capture.status == AiCaptureStore.Status.FAILED) (capture.error ?: "") else capture.reasoning
            val outlookLine = if (capture.status == AiCaptureStore.Status.DONE && capture.nextHourOutlook.isNotBlank()) {
                var line = "\nNext hour: ${capture.nextHourOutlook}"
                if (capture.riskLevel.isNotBlank()) line += "  ·  ${capture.riskLevel} risk"
                if (capture.signal == AiSignalAdvisor.Signal.BUY && capture.suggestedBuyUsd > 0) {
                    line += "  ·  buy $%,.2f → est. profit $%,.2f (%.1f%%)".format(
                        capture.suggestedBuyUsd, capture.estimatedProfitUsd, capture.estimatedProfitPercent
                    )
                }
                if (capture.signal == AiSignalAdvisor.Signal.BUY && capture.suggestedStopLossPrice > 0 && capture.suggestedTakeProfitPrice > 0) {
                    line += "  ·  stop ${price(capture.suggestedStopLossPrice)} / target ${price(capture.suggestedTakeProfitPrice)}"
                }
                line
            } else ""
            text = reasoningLine + outlookLine
            textSize = 11f
            setTextColor(color(R.color.text_secondary))
            maxLines = 5
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        row.addView(textCol)
        return row
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    /** User-initiated only. Grok never places orders. */
    private fun askGrok() {
        if (grokBusy) return
        val key = dashXaiApiKeyInput.text.toString().trim()
        secureStorage.saveXaiApiKey(key)
        grokBusy = true
        grokAdviceText.text = "Asking Grok…"
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    GrokAdvisor.advise(key, lastSnap)
                } catch (e: Exception) {
                    "Grok request failed: ${e.message}"
                }
            }
            grokAdviceText.text = text
            grokBusy = false
        }
    }

    /**
     * Wires the bottom nav (Home / Position / Controls / History / AI) to show
     * exactly one of the independently-scrollable tab panes at a time. The
     * equity card and any active lock/circuit-breaker banners live in the
     * fixed header above this, outside all panes, so they stay visible on
     * every tab.
     *
     * A tab pane sits at View.GONE while hidden, which means Android never
     * measures/lays it out and the custom chart views inside it (candlestick
     * chart, sparkline) can end up drawing against stale/zero bounds from
     * before they were hidden -- that's what showed up as numbers/lines
     * briefly jumping around right after switching tabs. Forcing a fresh
     * requestLayout + invalidate the moment a pane becomes visible again
     * fixes that: it always redraws from the latest data instead of
     * whatever was cached from its last (possibly stale) layout pass.
     */
    private fun setupBottomTabs() {
        tabHomeScroll = findViewById(R.id.tabHomeScroll)
        tabPositionScroll = findViewById(R.id.tabPositionScroll)
        tabControlsScroll = findViewById(R.id.tabControlsScroll)
        tabHistoryScroll = findViewById(R.id.tabHistoryScroll)
        tabAiScroll = findViewById(R.id.tabAiScroll)
        bottomNav = findViewById(R.id.bottomNav)
        setupAiTab()
        findViewById<Button>(R.id.openHelpFromAiButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            startActivity(Intent(this, HelpActivity::class.java))
        }

        val allTabs = listOf(tabHomeScroll, tabPositionScroll, tabControlsScroll, tabHistoryScroll, tabAiScroll)

        bottomNav.setOnItemSelectedListener { item ->
            val selected: View = when (item.itemId) {
                R.id.navHome -> tabHomeScroll
                R.id.navPosition -> tabPositionScroll
                R.id.navControls -> tabControlsScroll
                R.id.navHistory -> tabHistoryScroll
                R.id.navAi -> tabAiScroll
                else -> tabHomeScroll
            }
            for (tab in allTabs) {
                tab.visibility = if (tab === selected) View.VISIBLE else View.GONE
            }
            // Force a clean re-measure + redraw of the pane that just became
            // visible so it never shows a stale frame from before it was hidden.
            selected.requestLayout()
            selected.post {
                btcPriceChart.requestLayout()
                btcPriceChart.invalidate()
                sparkline.requestLayout()
                sparkline.invalidate()
            }
            true
        }
    }

    /**
     * Same picker as MainActivity's, but living on the dashboard so switching
     * strategy doesn't mean leaving the running bot's screen. Saves straight
     * to SecureStorage; TradingService picks the change up on its next poll
     * cycle (see the live-switch check in TradingService's main loop) --
     * no stop/start required.
     */
    private fun setupStrategyPicker() {
        dashStrategySpinner = findViewById(R.id.dashStrategySpinner)
        dashStrategyDescriptionText = findViewById(R.id.dashStrategyDescriptionText)
        dashActiveStrategyText = findViewById(R.id.dashActiveStrategyText)

        val strategyOptions = StrategyId.entries.toList()
        dashStrategySpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            strategyOptions.map { option -> option.displayName }
        )
        val savedStrategyId = secureStorage.getStrategyId()
        dashStrategySpinner.setSelection(strategyOptions.indexOf(savedStrategyId).coerceAtLeast(0))
        dashStrategyDescriptionText.text = savedStrategyId.description
        dashStrategySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selected = strategyOptions[position]
                dashStrategyDescriptionText.text = selected.description
                secureStorage.saveStrategyId(selected)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        setupCustomRuleInputs()
    }

    /**
     * Custom Rule inputs: validates as the person types (RuleEngine.validate,
     * see RuleEngine.kt) so a typo shows up immediately rather than silently
     * doing nothing once saved, and Save writes straight to SecureStorage --
     * TradingService picks up the change on its next poll cycle.
     */
    private fun setupCustomRuleInputs() {
        dashCustomBuyRuleInput = findViewById(R.id.dashCustomBuyRuleInput)
        dashCustomSellRuleInput = findViewById(R.id.dashCustomSellRuleInput)
        dashCustomBuyRuleError = findViewById(R.id.dashCustomBuyRuleError)
        dashCustomSellRuleError = findViewById(R.id.dashCustomSellRuleError)

        dashCustomBuyRuleInput.setText(secureStorage.getCustomBuyRule())
        dashCustomSellRuleInput.setText(secureStorage.getCustomSellRule())

        fun showValidation(input: EditText, errorView: TextView) {
            val error = RuleEngine.validate(input.text.toString().trim())
            errorView.text = error ?: ""
            errorView.visibility = if (error == null) View.GONE else View.VISIBLE
        }

        fun watcherFor(input: EditText, errorView: TextView) = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { showValidation(input, errorView) }
        }
        dashCustomBuyRuleInput.addTextChangedListener(watcherFor(dashCustomBuyRuleInput, dashCustomBuyRuleError))
        dashCustomSellRuleInput.addTextChangedListener(watcherFor(dashCustomSellRuleInput, dashCustomSellRuleError))
        showValidation(dashCustomBuyRuleInput, dashCustomBuyRuleError)
        showValidation(dashCustomSellRuleInput, dashCustomSellRuleError)

        findViewById<Button>(R.id.dashSaveCustomRuleButton).setOnClickListener { view ->
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            val buyRule = dashCustomBuyRuleInput.text.toString().trim()
            val sellRule = dashCustomSellRuleInput.text.toString().trim()
            val buyError = RuleEngine.validate(buyRule)
            val sellError = RuleEngine.validate(sellRule)
            dashCustomBuyRuleError.text = buyError ?: ""
            dashCustomBuyRuleError.visibility = if (buyError == null) View.GONE else View.VISIBLE
            dashCustomSellRuleError.text = sellError ?: ""
            dashCustomSellRuleError.visibility = if (sellError == null) View.GONE else View.VISIBLE
            if (buyError != null || sellError != null) {
                android.widget.Toast.makeText(this, "Fix the highlighted rule before saving.", android.widget.Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            secureStorage.saveCustomBuyRule(buyRule)
            secureStorage.saveCustomSellRule(sellRule)
            val appliesNow = secureStorage.getStrategyId() == StrategyId.CUSTOM_RULE
            android.widget.Toast.makeText(
                this,
                if (appliesNow) "Custom rule saved — applies on the bot's next check (~4s)."
                else "Custom rule saved. Switch Strategy above to \"Custom Rule\" to use it.",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }

    /** Renders whatever is already on disk (trade history + cumulative stats), before any live broadcast arrives. */
    private fun loadPersistedState() {
        try {
            val historyStore = TradeHistoryStore(this)
            val stats = TradeStats()
            historyStore.restoreCumulative(stats)

            winRateText.text = if (stats.totalTrades == 0) "No trades yet"
                else String.format(Locale.US, "%.0f%% (%d trades)", stats.winRatePercent(), stats.totalTrades)
            val totalCosts = stats.totalExchangeFees + stats.totalTds + stats.totalTaxEstimate
            costsText.text = String.format(Locale.US, "-$%,.2f  (fees+TDS $%,.2f, tax est. $%,.2f)", totalCosts, stats.totalExchangeFees + stats.totalTds, stats.totalTaxEstimate)
            netPnlText.text = String.format(Locale.US, "%s$%,.2f", if (stats.totalNetPnl >= 0) "+" else "-", kotlin.math.abs(stats.totalNetPnl))
            netPnlText.setTextColor(if (stats.totalNetPnl >= 0) color(R.color.positive) else color(R.color.negative))

            renderTradeHistory(historyStore.getTrades())

            // The reconcile card was previously driven only by live broadcasts from
            // the running service, so a persisted HARD LOCK became invisible (and its
            // Adopt/Clear buttons unreachable) the moment the service wasn't actively
            // running -- e.g. after tapping STOP BOT, or reopening the app fresh.
            // Seed it here from disk so the card (and its buttons) show up immediately
            // on open whenever a lock is still in effect, service running or not.
            val (persistedLocked, persistedReason) = historyStore.loadTradingLock()
            if (persistedLocked) {
                reconcileLocked = true
                reconcileReasonText.text = persistedReason.ifBlank { "Exchange balance and local position do not match." }
                controlsLockReasonText.text = reconcileReasonText.text
                updateReconcileVisibility()
            }
        } catch (e: Exception) {
            TradingService.onLog?.invoke("Dashboard: failed to load saved trade history: ${e.message}")
        }
    }

    private fun parseDoubles(raw: String): List<Double> = raw.split(",").mapNotNull { value -> value.toDoubleOrNull() }
    private fun formatQty(q: Double): String = String.format(Locale.US, "%.8f", q).trimEnd('0').trimEnd('.')

    private fun renderTradeHistory(array: JSONArray) {
        tradeHistoryContainer.removeAllViews()
        val start = maxOf(0, array.length() - 20)
        if (array.length() == 0) {
            val empty = TextView(this).apply { text = "No completed trades yet. The first trade will appear here automatically."; setTextColor(color(R.color.text_tertiary)); textSize = 12f; setPadding(0, 12, 0, 8) }
            tradeHistoryContainer.addView(empty); return
        }
        for (i in array.length() - 1 downTo start) {
            val obj = array.getJSONObject(i)
            addTradeCard(obj, array.length() - i)
        }
    }

    private fun addTradeCard(obj: org.json.JSONObject, numberFromLatest: Int) {
        val entry = obj.optDouble("entry", 0.0)
        val exit = obj.optDouble("exit", 0.0)
        val qty = obj.optDouble("qty", 0.0)
        val gross = obj.optDouble("gross", (exit - entry) * qty)
        val fees = obj.optDouble("fees", 0.0)
        val tds = obj.optDouble("tds", 0.0)
        val tax = obj.optDouble("tax", 0.0)
        val net = obj.optDouble("net", gross - fees - tds - tax)
        val pathArray = obj.optJSONArray("path")
        val path = mutableListOf<Double>()
        if (pathArray != null) for (i in 0 until pathArray.length()) path.add(pathArray.optDouble(i))
        if (path.size < 2 && entry > 0 && exit > 0) path.addAll(listOf(entry, exit))
        val time = SimpleDateFormat("dd MMM, HH:mm:ss", Locale.US).format(Date(obj.optLong("t", 0L)))
        val profit = net >= 0
        val card = com.google.android.material.card.MaterialCardView(this).apply {
            setCardBackgroundColor(color(R.color.bg_app))
            radius = 22f
            strokeWidth = 1
            strokeColor = color(R.color.card_stroke)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 18 }
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18) }
        val title = TextView(this).apply { text = "Trade #$numberFromLatest  •  ${if (profit) "PROFIT" else "LOSS"}"; textSize = 14f; setTextColor(if (profit) color(R.color.positive) else color(R.color.negative)); setTypeface(typeface, android.graphics.Typeface.BOLD) }
        box.addView(title)
        val chart = TradeChartView(this).apply { layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 105); setPadding(0, 4, 0, 4); setValues(path, profit) }
        box.addView(chart)
        box.addView(row("BUY / entry", price(entry)))
        box.addView(row("SELL / exit", price(exit)))
        box.addView(row("Quantity", "${formatQty(qty)} ${market.baseAsset}  •  ≈ ${price(entry * qty)} position"))
        box.addView(row("Gross P/L", String.format(Locale.US, "%s$%.4f", if (gross >= 0) "+" else "-", kotlin.math.abs(gross))))
        box.addView(row("Costs", String.format(Locale.US, "$%.4f  (fee + TDS + tax)", fees + tds + tax)))
        val netRow = row("NET P/L", String.format(Locale.US, "%s$%.4f", if (net >= 0) "+" else "-", kotlin.math.abs(net)))
        (netRow.getChildAt(1) as? TextView)?.setTextColor(if (profit) color(R.color.positive) else color(R.color.negative))
        box.addView(netRow)
        box.addView(row("Time", time))
        val oid = obj.optLong("orderId", 0L)
        val cid = obj.optString("clientOrderId", "")
        if (oid > 0L || cid.isNotBlank()) {
            box.addView(row("Order", "id $oid  •  $cid"))
        }
        card.addView(box); tradeHistoryContainer.addView(card)
    }

    private fun row(label: String, value: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, 5, 0, 5)
        addView(TextView(this@DashboardActivity).apply { text = label; textSize = 11f; setTextColor(color(R.color.text_secondary)); layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) })
        addView(TextView(this@DashboardActivity).apply { text = value; textSize = 11f; setTextColor(color(R.color.text_primary)); setTypeface(typeface, android.graphics.Typeface.BOLD) })
    }

    override fun onStart() {
        super.onStart()
        hasReceivedUpdate = false
        waitingBanner.visibility = View.VISIBLE
        LocalBroadcastManager.getInstance(this).registerReceiver(updateReceiver, IntentFilter(TradingService.ACTION_DASHBOARD_UPDATE))
        // Re-check the persisted lock every time the dashboard comes to the
        // foreground (not just on cold launch) -- if the bot was stopped while
        // a HARD LOCK was active, no live broadcast will arrive to reveal the
        // reconcile card, so this is the only thing that would otherwise show it.
        val (persistedLocked, persistedReason) = TradeHistoryStore(this).loadTradingLock()
        if (persistedLocked) {
            reconcileLocked = true
            reconcileReasonText.text = persistedReason.ifBlank { "Exchange balance and local position do not match." }
            controlsLockReasonText.text = reconcileReasonText.text
            updateReconcileVisibility()
        }
        refreshAiTabUi()
        // Vision captures are now event-driven from TradingService; no hourly timer.
    }
    override fun onStop() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(updateReceiver)
        stopBitcoinMarketSocket()
        btcLoadJob?.cancel()
        super.onStop()
    }
    override fun onDestroy() {
        stopBitcoinMarketSocket()
        super.onDestroy()
    }

}
