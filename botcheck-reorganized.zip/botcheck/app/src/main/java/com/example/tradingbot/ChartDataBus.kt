package com.example.tradingbot

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Process-wide bridge that mirrors the BTC/USDT chart state from
 * DashboardActivity into FullscreenChartActivity, so expanding the chart
 * doesn't require re-bootstrapping candles or reopening the websocket --
 * the fullscreen view just observes whatever the dashboard already has.
 *
 * DashboardActivity is the sole writer; FullscreenChartActivity (and any
 * other observer) should only read from the exposed StateFlows.
 */
object ChartDataBus {

    data class Levels(
        val entry: Double? = null,
        val stop: Double? = null,
        val take: Double? = null,
        val trail: Double? = null
    )

    private val _candles = MutableStateFlow<List<ChartCandle>>(emptyList())
    val candles: StateFlow<List<ChartCandle>> = _candles

    private val _levels = MutableStateFlow(Levels())
    val levels: StateFlow<Levels> = _levels

    private val _rangeLabel = MutableStateFlow("")
    val rangeLabel: StateFlow<String> = _rangeLabel

    /** Full candle replace -- called whenever the dashboard reloads/re-buckets the window. */
    fun updateCandles(candles: List<ChartCandle>) {
        _candles.value = candles
    }

    /** Single-candle upsert -- called on every live websocket tick. */
    fun updateLastCandle(candle: ChartCandle) {
        val current = _candles.value
        val idx = current.indexOfFirst { existing -> existing.openTime == candle.openTime }
        _candles.value = if (idx >= 0) {
            current.toMutableList().also { list -> list[idx] = candle }
        } else {
            (current + candle).takeLast(500)
        }
    }

    fun updateLevels(entry: Double?, stop: Double?, take: Double?, trail: Double?) {
        _levels.value = Levels(entry, stop, take, trail)
    }

    fun updateRangeLabel(label: String) {
        _rangeLabel.value = label
    }
}
