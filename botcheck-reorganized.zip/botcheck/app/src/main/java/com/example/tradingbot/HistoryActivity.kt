package com.example.tradingbot

import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Dedicated "history" screen: every closed trade persisted by
 * TradeHistoryStore, browsable as All / Gains-only / Losses-only, with a
 * summary strip (total / gains / losses / net P&L) that updates per filter.
 *
 * This reads the same on-device storage the dashboard's live view reads,
 * so it works whether or not the bot is currently running.
 */
class HistoryActivity : AppCompatActivity() {

    private enum class Filter { ALL, AUTOMATED, MANUAL }

    private lateinit var totalText: TextView
    private lateinit var gainsText: TextView
    private lateinit var lossesText: TextView
    private lateinit var netPnlText: TextView
    private lateinit var listContainer: LinearLayout
    private lateinit var allButton: MaterialButton
    private lateinit var automatedButton: MaterialButton
    private lateinit var manualButton: MaterialButton

    private var allTrades: JSONArray = JSONArray()
    private var currentFilter: Filter = Filter.ALL

    private fun color(resId: Int): Int = ContextCompat.getColor(this, resId)
    private fun price(v: Double): String = String.format(Locale.US, "$%,.2f", v)
    private fun formatQty(q: Double): String = String.format(Locale.US, "%.8f", q).trimEnd('0').trimEnd('.')

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        totalText = findViewById(R.id.historyTotalText)
        gainsText = findViewById(R.id.historyGainsText)
        lossesText = findViewById(R.id.historyLossesText)
        netPnlText = findViewById(R.id.historyNetPnlText)
        listContainer = findViewById(R.id.historyListContainer)
        allButton = findViewById(R.id.filterAllButton)
        automatedButton = findViewById(R.id.filterAutomatedButton)
        manualButton = findViewById(R.id.filterManualButton)

        findViewById<TextView>(R.id.historyBackButton).setOnClickListener { finish() }

        allButton.setOnClickListener { view -> view.performHapticFeedback(HapticFeedbackConstants.CONFIRM); setFilter(Filter.ALL) }
        automatedButton.setOnClickListener { view -> view.performHapticFeedback(HapticFeedbackConstants.CONFIRM); setFilter(Filter.AUTOMATED) }
        manualButton.setOnClickListener { view -> view.performHapticFeedback(HapticFeedbackConstants.CONFIRM); setFilter(Filter.MANUAL) }

        allTrades = TradeHistoryStore(this).getTrades()
        setFilter(Filter.ALL)
    }

    override fun onResume() {
        super.onResume()
        // Pick up any trades closed while this screen wasn't on top.
        allTrades = TradeHistoryStore(this).getTrades()
        render()
    }

    private fun setFilter(filter: Filter) {
        currentFilter = filter
        highlightTabs()
        render()
    }

    private fun highlightTabs() {
        fun style(button: MaterialButton, selected: Boolean) {
            if (selected) {
                button.backgroundTintList = android.content.res.ColorStateList.valueOf(color(R.color.positive_bright))
                button.setTextColor(color(R.color.bg_app))
                button.strokeWidth = 0
            } else {
                button.backgroundTintList = android.content.res.ColorStateList.valueOf(color(R.color.bg_card))
                button.setTextColor(color(R.color.text_primary))
                button.strokeWidth = 4 // px, matches ~1.5dp outline look
                button.strokeColor = android.content.res.ColorStateList.valueOf(color(R.color.divider))
            }
        }
        style(allButton, currentFilter == Filter.ALL)
        style(automatedButton, currentFilter == Filter.AUTOMATED)
        style(manualButton, currentFilter == Filter.MANUAL)
    }

    /** All completed trades newest first. Manual and automated trades are persisted with an explicit type. */
    private fun newestFirst(source: JSONArray): List<JSONObject> {
        val all = mutableListOf<JSONObject>()
        for (i in source.length() - 1 downTo 0) all.add(source.getJSONObject(i))
        return all
    }

    private fun render() {
        val all = newestFirst(allTrades)
        val manual = newestFirst(TradeHistoryStore(this).getManualTrades())
        val automated = newestFirst(TradeHistoryStore(this).getAutomatedTrades())
        val selected = when (currentFilter) {
            Filter.ALL -> all
            Filter.AUTOMATED -> automated
            Filter.MANUAL -> manual
        }
        val wins = selected.count { trade -> trade.optDouble("net", 0.0) >= 0.0 }
        val losses = selected.size - wins
        val netTotal = selected.sumOf { trade -> trade.optDouble("net", 0.0) }

        totalText.text = selected.size.toString()
        gainsText.text = wins.toString()
        lossesText.text = losses.toString()
        netPnlText.text = String.format(Locale.US, "%s$%,.2f", if (netTotal >= 0) "+" else "-", kotlin.math.abs(netTotal))
        netPnlText.setTextColor(if (netTotal >= 0) color(R.color.positive) else color(R.color.negative))

        val toShow = when (currentFilter) {
            Filter.ALL -> all
            Filter.AUTOMATED -> automated
            Filter.MANUAL -> manual
        }

        listContainer.removeAllViews()
        if (toShow.isEmpty()) {
            val emptyMsg = when (currentFilter) {
                Filter.ALL -> "No completed trades yet. They'll show up here as soon as one closes."
                Filter.AUTOMATED -> "No automated trades recorded yet."
                Filter.MANUAL -> "No manual trades recorded yet."
            }
            val empty = TextView(this).apply {
                text = emptyMsg
                setTextColor(color(R.color.text_tertiary))
                textSize = 12f
                setPadding(4, 16, 4, 8)
            }
            listContainer.addView(empty)
            return
        }

        for (obj in toShow) {
            val numberFromLatest = all.indexOfFirst { trade ->
                trade.optLong("t") == obj.optLong("t") &&
                    trade.optString("clientOrderId") == obj.optString("clientOrderId")
            }.let { index -> if (index >= 0) index + 1 else 0 }
            addTradeCard(obj, numberFromLatest)
        }
    }

    private fun addTradeCard(obj: JSONObject, numberFromLatest: Int) {
        val entry = obj.optDouble("entry", 0.0)
        val exit = obj.optDouble("exit", 0.0)
        val qty = obj.optDouble("qty", 0.0)
        val gross = obj.optDouble("gross", (exit - entry) * qty)
        val fees = obj.optDouble("fees", 0.0)
        val tds = obj.optDouble("tds", 0.0)
        val tax = obj.optDouble("tax", 0.0)
        val net = obj.optDouble("net", gross - fees - tds - tax)
        val time = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.US).format(Date(obj.optLong("t", 0L)))
        val profit = net >= 0
        val exitReason = obj.optString("exitReason", "").ifBlank { "—" }
        val fillStatus = obj.optString("fillStatus", "").ifBlank { "—" }
        val clientOrderId = obj.optString("clientOrderId", "").ifBlank { "—" }
        val exchangeOrderId = obj.optLong("orderId", 0L)
        val pathArray = obj.optJSONArray("path")
        val pathPoints = pathArray?.let { arr -> (0 until arr.length()).map { i -> arr.optDouble(i, entry) } } ?: emptyList()

        val card = com.google.android.material.card.MaterialCardView(this).apply {
            setCardBackgroundColor(color(R.color.bg_card))
            radius = 22f
            strokeWidth = 1
            strokeColor = color(R.color.card_stroke)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 14 }
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16) }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(TextView(this).apply {
            text = "Trade #$numberFromLatest"
            textSize = 13f
            setTextColor(color(R.color.text_secondary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        header.addView(TextView(this).apply {
            text = if (profit) "Profit" else "Loss"
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(if (profit) color(R.color.positive) else color(R.color.negative))
        })
        box.addView(header)
        val mode = if (obj.optBoolean("manualTrade", false)) "Manual" else "Auto"
        box.addView(TextView(this).apply {
            text = "$mode trade"
            textSize = 10f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(color(R.color.warning))
            setPadding(0, 2, 0, 6)
        })

        box.addView(row("Entry → exit", "${price(entry)}  →  ${price(exit)}"))
        box.addView(row("Quantity", "${formatQty(qty)} BTC"))
        box.addView(row("Gross P/L", String.format(Locale.US, "%s$%.4f", if (gross >= 0) "+" else "-", kotlin.math.abs(gross))))
        box.addView(row("Exchange fees", String.format(Locale.US, "$%.4f", fees)))
        if (tds != 0.0) box.addView(row("TDS", String.format(Locale.US, "$%.4f", tds)))
        if (tax != 0.0) box.addView(row("Tax estimate", String.format(Locale.US, "$%.4f", tax)))
        val netRow = row("Net P/L", String.format(Locale.US, "%s$%.4f", if (net >= 0) "+" else "-", kotlin.math.abs(net)))
        (netRow.getChildAt(0) as? TextView)?.apply { setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(color(R.color.text_primary)) }
        (netRow.getChildAt(1) as? TextView)?.setTextColor(if (profit) color(R.color.positive) else color(R.color.negative))
        box.addView(netRow)
        box.addView(row("Exit reason", exitReason))
        if (pathPoints.size > 1) {
            val high = pathPoints.max()
            val low = pathPoints.min()
            box.addView(row("Path high / low", "${price(high)}  /  ${price(low)}"))
        }
        box.addView(row("Fill status", fillStatus))
        box.addView(row("Order ID", if (exchangeOrderId > 0L) exchangeOrderId.toString() else "—"))
        box.addView(row("Client order ID", clientOrderId))
        box.addView(row("Time", time))

        card.addView(box)
        listContainer.addView(card)
    }

    private fun row(label: String, value: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, 4, 0, 4)
        addView(TextView(this@HistoryActivity).apply { text = label; textSize = 11f; setTextColor(color(R.color.text_secondary)); layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) })
        // Long values (order IDs) get their own weighted slot so they wrap
        // under the label instead of overflowing the card's right edge.
        addView(TextView(this@HistoryActivity).apply {
            text = value
            textSize = 11f
            setTextColor(color(R.color.text_primary))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = android.view.Gravity.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f)
        })
    }
}
