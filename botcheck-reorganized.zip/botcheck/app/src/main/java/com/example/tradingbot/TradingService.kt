package com.example.tradingbot

import android.app.*
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import java.util.UUID

class TradingService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private var liveWebSocket: WebSocket? = null
    private var liveWebSocketClient: OkHttpClient? = null
    @Volatile private var manualRefreshRequested = false
    @Volatile private var streamEnabled = false
    @Volatile private var currentAutoMode = true
    @Volatile private var currentAutoExit = true
    @Volatile private var pendingManualBuy = false
    @Volatile private var pendingManualSell = false
    @Volatile private var pendingManualAmountUsd = 10.0
    @Volatile private var pendingManualStopLossPercent = DEFAULT_STOP_LOSS_PERCENT
    @Volatile private var pendingManualTakeProfitPercent = DEFAULT_TAKE_PROFIT_PERCENT
    @Volatile private var pendingReconcile = false
    @Volatile private var pendingReconcileAdopt = false
    private val liveExitInProgress = AtomicExecutionGate()
    private val orderExecutionLock = ReentrantLock()
    @Volatile private var reconnectScheduled = false
    @Volatile private var autoBuyCircuitPaused = false
    @Volatile private var autoBuyCircuitReason = ""
    @Volatile private var protectionError = ""
    @Volatile private var lastAiLinkedAnalysisId: String? = null
    // Driven directly by WebSocket lifecycle callbacks (onOpen/onFailure/onClosed),
    // not inferred from tick timing -- so "reconnecting" is reported the instant the
    // socket actually drops, rather than only after STALE_TICK_MS of silence.
    @Volatile private var connectionState: String = CONNECTION_CONNECTING
    @Volatile private var sharedClient: BinanceApiClient? = null
    // Needs to be reachable from submitAndResolveOrder(), which runs outside
    // the onStartCommand() scope, so it's a class field rather than a local val.
    private lateinit var historyStore: TradeHistoryStore
    // Which market this run of the service trades. Set once at service start
    // from EXTRA_SYMBOL (chosen on MarketSelectionActivity) and held fixed
    // for the life of the run -- switching markets requires stopping and
    // restarting the service via the dashboard, same as changing strategy.
    @Volatile private var symbol: String = DEFAULT_SYMBOL
    @Volatile private var baseAsset: String = symbol.removeSuffix("USDT")

    companion object {
        const val CHANNEL_ID = "trading_bot_channel"
        const val NOTIF_ID = 1
        const val DEFAULT_SYMBOL = "BTCUSDT"
        const val EXTRA_SYMBOL = "extra_symbol"
        const val EXTRA_LIVE_MODE = "extra_live_mode"
        const val POLL_INTERVAL_MS = 15_000L
        const val LIVE_TICK_INTERVAL_MS = 250L
        const val STALE_TICK_MS = 30_000L
        const val ENTRY_COOLDOWN_MS = 15 * 60 * 1000L

        // Rolling session window: independent of the calendar-day RiskManager below.
        const val SESSION_WINDOW_MS = 2 * 60 * 60 * 1000L   // 2 hours
        const val SESSION_BUDGET_USD = 10.0
        const val SESSION_PROFIT_TARGET_USD = 1.0            // pauses entries once hit, does not force trades
        const val SESSION_MAX_LOSS_USD = 10.0
        const val ACTION_MANUAL_REFRESH = "com.example.tradingbot.MANUAL_REFRESH"
        const val ACTION_MANUAL_BUY = "com.example.tradingbot.MANUAL_BUY"
        const val ACTION_MANUAL_SELL = "com.example.tradingbot.MANUAL_SELL"
        const val ACTION_SET_MODE = "com.example.tradingbot.SET_MODE"

        const val DAILY_TRADING_BUDGET_USD = 10.0
        const val DEFAULT_STOP_LOSS_PERCENT = 0.012
        // Activation - giveback must stay at/above modeled break-even (~1.74% + slip).
        const val DEFAULT_TRAILING_ACTIVATION_PERCENT = 0.026
        const val DEFAULT_TAKE_PROFIT_PERCENT = 0.025
        const val TRAILING_GIVEBACK_PERCENT = 0.008

        const val EXTRA_DAILY_BUDGET_USD = "dailyBudgetUsd"
        const val EXTRA_STOP_LOSS_PERCENT = "stopLossPercent"
        const val EXTRA_TRAILING_ACTIVATION_PERCENT = "trailingActivationPercent"
        const val EXTRA_TAKE_PROFIT_PERCENT = "takeProfitPercent"
        const val EXTRA_TRADE_AMOUNT_USD = "tradeAmountUsd"
        const val EXTRA_SESSION_BUDGET_USD = "sessionBudgetUsd"
        const val EXTRA_SESSION_PROFIT_TARGET_USD = "sessionProfitTargetUsd"
        const val EXTRA_SESSION_MAX_LOSS_USD = "sessionMaxLossUsd"
        const val EXTRA_AUTO_MODE = "autoMode"
        const val EXTRA_AUTO_EXIT = "autoExit"
        const val EXTRA_STRATEGY_ID = "strategyId"
        const val EXTRA_CONNECTION_STATE = "connection_state"
        const val CONNECTION_CONNECTED = "CONNECTED"
        const val CONNECTION_CONNECTING = "CONNECTING"
        const val CONNECTION_RECONNECTING = "RECONNECTING"

        const val BREAKEVEN_MOVE_PERCENT = 0.0174
        const val MIN_HOLD_MS = 5 * 60 * 1000L

        var onLog: ((String) -> Unit)? = null

        const val ACTION_DASHBOARD_UPDATE = "com.example.tradingbot.DASHBOARD_UPDATE"
        const val EXTRA_BALANCE = "balance"
        const val EXTRA_EQUITY = "equity"
        const val EXTRA_PNL_PERCENT = "pnl_percent"
        const val EXTRA_LAST_PRICE = "last_price"
        const val EXTRA_SIGNAL = "signal"
        const val EXTRA_PRICE_HISTORY = "price_history"
        const val EXTRA_WIN_RATE = "win_rate"
        const val EXTRA_TOTAL_TRADES = "total_trades"
        const val EXTRA_NET_PNL = "net_pnl"
        const val EXTRA_FEES_PLUS_TDS = "fees_plus_tds"
        const val EXTRA_TAX_ESTIMATE = "tax_estimate"
        const val EXTRA_FIXED_TRADE_AMOUNT = "fixed_trade_amount"
        const val EXTRA_POSITION_OPEN = "position_open"
        const val EXTRA_ENTRY_PRICE = "entry_price"
        const val EXTRA_QUANTITY = "quantity"
        const val EXTRA_OPEN_TRADE_PATH = "open_trade_path"
        const val EXTRA_TRADE_HISTORY = "trade_history"
        const val EXTRA_SIGNAL_REASON = "signal_reason"
        const val EXTRA_TRADING_LOCKED = "trading_locked"
        const val EXTRA_ENTRY_TIMESTAMP_MS = "entry_timestamp_ms"
        const val EXTRA_STOP_LOSS_PRICE = "stop_loss_price"
        const val EXTRA_TRAILING_ARM_PRICE = "trailing_arm_price"
        const val EXTRA_POSITION_STATUS_TEXT = "position_status_text"
        const val EXTRA_SESSION_HIGH = "session_high"
        const val EXTRA_SESSION_LOW = "session_low"
        const val EXTRA_STREAM_STALE = "stream_stale"
        const val EXTRA_TRADES_TODAY = "trades_today"
        const val EXTRA_MAX_TRADES_PER_DAY = "max_trades_per_day"
        const val EXTRA_CONSECUTIVE_LOSSES = "consecutive_losses"
        const val EXTRA_MAX_CONSECUTIVE_LOSSES = "max_consecutive_losses"
        const val EXTRA_TAKE_PROFIT_PRICE = "take_profit_price"
        const val EXTRA_MODE_STATUS = "mode_status"
        const val EXTRA_BULLISH_SCORE = "bullish_score"
        const val EXTRA_BEARISH_SCORE = "bearish_score"
        const val EXTRA_SIGNAL_QUALITY = "signal_quality"
        const val EXTRA_RSI = "rsi"
        const val EXTRA_EMA_FAST = "ema_fast"
        const val EXTRA_EMA_SLOW = "ema_slow"
        const val EXTRA_ATR_PERCENT = "atr_percent"
        const val EXTRA_TREND_STRENGTH = "trend_strength"
        const val EXTRA_ACTIVE_STRATEGY_NAME = "active_strategy_name"
        const val EXTRA_AI_EVENT = "ai_event"
        const val EXTRA_API_DEGRADED = "api_degraded"
        const val EXTRA_API_RETRY_ATTEMPT = "api_retry_attempt"
        const val EXTRA_AUTO_BUY_CIRCUIT_PAUSED = "auto_buy_circuit_paused"
        const val EXTRA_PROTECTION_STATUS = "protection_status"
        const val EXTRA_PROTECTION_ORDER_LIST_ID = "protection_order_list_id"
        const val EXTRA_PROTECTION_STOP_PRICE = "protection_stop_price"
        const val EXTRA_PROTECTION_TP_PRICE = "protection_tp_price"
        const val EXTRA_PROTECTION_ERROR = "protection_error"
        const val ACTION_RECONCILE = "com.example.tradingbot.RECONCILE"
        const val EXTRA_RECONCILE_ADOPT = "reconcile_adopt"
        const val ACTION_RESUME_AUTO_BUY = "com.example.tradingbot.RESUME_AUTO_BUY"

        const val ALERT_CHANNEL_ID = "trading_bot_alerts"
        const val ALERT_NOTIF_ID = 2
        const val TRADE_CHANNEL_ID = "trading_bot_trade_events"
        const val TRADE_NOTIF_ID = 3
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        val isManualRefresh = action == ACTION_MANUAL_REFRESH
        if (isManualRefresh) manualRefreshRequested = true
        if (action == ACTION_RESUME_AUTO_BUY) {
            getSharedPreferences("trading_bot_runtime", MODE_PRIVATE).edit()
                .putBoolean("resume_auto_buy_requested", true).apply()
            log("Auto-BUY circuit breaker resume requested.")
        }
        if (action == ACTION_SET_MODE) {
            currentAutoMode = intent?.getBooleanExtra(EXTRA_AUTO_MODE, currentAutoMode) ?: currentAutoMode
            currentAutoExit = intent?.getBooleanExtra(EXTRA_AUTO_EXIT, currentAutoExit) ?: currentAutoExit
            getSharedPreferences("trading_bot_runtime", MODE_PRIVATE).edit().putBoolean("auto_mode", currentAutoMode).putBoolean("auto_exit", currentAutoExit).apply()
        }
        if (action == ACTION_MANUAL_BUY) {
            pendingManualBuy = true
            pendingManualSell = false
            pendingManualAmountUsd = intent?.getDoubleExtra(EXTRA_TRADE_AMOUNT_USD, 10.0) ?: 10.0
            pendingManualStopLossPercent = intent?.getDoubleExtra(EXTRA_STOP_LOSS_PERCENT, DEFAULT_STOP_LOSS_PERCENT) ?: DEFAULT_STOP_LOSS_PERCENT
            pendingManualTakeProfitPercent = intent?.getDoubleExtra(EXTRA_TAKE_PROFIT_PERCENT, DEFAULT_TAKE_PROFIT_PERCENT) ?: DEFAULT_TAKE_PROFIT_PERCENT
        }
        if (action == ACTION_MANUAL_SELL) {
            pendingManualSell = true
            pendingManualBuy = false
        }
        if (action == ACTION_RECONCILE) {
            pendingReconcile = true
            pendingReconcileAdopt = intent?.getBooleanExtra(EXTRA_RECONCILE_ADOPT, false) ?: false
        }

        // Avoid creating a second WebSocket/trading loop when Start is tapped
        // again while this service is already running. A duplicate service
        // loop could otherwise place duplicate orders.
        if (action !in setOf(ACTION_MANUAL_REFRESH, ACTION_MANUAL_BUY, ACTION_MANUAL_SELL, ACTION_SET_MODE, ACTION_RECONCILE) && job?.isActive == true) {
            log("Trading service is already running — ignoring duplicate Start request.")
            return START_STICKY
        }
        if (isManualRefresh && job?.isActive == true) {
            log("Manual dashboard refresh requested.")
            return START_STICKY
        }
        if (action in setOf(ACTION_MANUAL_BUY, ACTION_MANUAL_SELL, ACTION_SET_MODE, ACTION_RECONCILE) && job?.isActive == true) {
            if (action != ACTION_SET_MODE) manualRefreshRequested = true
            return START_STICKY
        }
        val persistedMode = AppPreferences.getTradingMode(this)
        val liveMode = if (intent?.hasExtra(EXTRA_LIVE_MODE) == true) intent.getBooleanExtra(EXTRA_LIVE_MODE, false) else persistedMode == TradingMode.LIVE
        val storedSecure = SecureStorage(applicationContext)
        val apiKey = intent?.getStringExtra("apiKey")?.takeIf { it.isNotBlank() }
            ?: storedSecure.getApiKey(if (liveMode) TradingMode.LIVE else TradingMode.TESTNET)
        val apiSecret = intent?.getStringExtra("apiSecret")?.takeIf { it.isNotBlank() }
            ?: storedSecure.getApiSecret(if (liveMode) TradingMode.LIVE else TradingMode.TESTNET)
        if (action !in setOf(ACTION_MANUAL_BUY, ACTION_MANUAL_SELL, ACTION_SET_MODE, ACTION_RECONCILE)) {
            symbol = intent?.getStringExtra(EXTRA_SYMBOL) ?: AppPreferences.getSelectedMarket(this).symbol
            baseAsset = symbol.removeSuffix("USDT")
        }

        val dailyBudgetUsd = intent?.getDoubleExtra(EXTRA_DAILY_BUDGET_USD, storedSecure.getDailyBudgetUsd())
            ?: storedSecure.getDailyBudgetUsd()
        val stopLossPercent = intent?.getDoubleExtra(EXTRA_STOP_LOSS_PERCENT, storedSecure.getStopLossPercent())
            ?: storedSecure.getStopLossPercent()
        val trailingActivationPercent = intent?.getDoubleExtra(EXTRA_TRAILING_ACTIVATION_PERCENT, storedSecure.getTrailingActivationPercent())
            ?: storedSecure.getTrailingActivationPercent()
        val takeProfitPercent = intent?.getDoubleExtra(EXTRA_TAKE_PROFIT_PERCENT, storedSecure.getTakeProfitPercent())
            ?: storedSecure.getTakeProfitPercent()
        if (action !in setOf(ACTION_MANUAL_BUY, ACTION_MANUAL_SELL, ACTION_SET_MODE)) {
            currentAutoMode = intent?.getBooleanExtra(EXTRA_AUTO_MODE, currentAutoMode) ?: currentAutoMode
            currentAutoExit = intent?.getBooleanExtra(EXTRA_AUTO_EXIT, currentAutoExit) ?: currentAutoExit
        }
        val strategyId = StrategyId.fromStorageKey(intent?.getStringExtra(EXTRA_STRATEGY_ID) ?: storedSecure.getStrategyId().name)
        val sessionBudgetUsd = intent?.getDoubleExtra(EXTRA_SESSION_BUDGET_USD, storedSecure.getSessionBudgetUsd())
            ?: storedSecure.getSessionBudgetUsd()
        val sessionProfitTargetUsd = intent?.getDoubleExtra(EXTRA_SESSION_PROFIT_TARGET_USD, storedSecure.getSessionProfitTargetUsd())
            ?: storedSecure.getSessionProfitTargetUsd()
        val sessionMaxLossUsd = intent?.getDoubleExtra(EXTRA_SESSION_MAX_LOSS_USD, storedSecure.getSessionMaxLossUsd())
            ?: storedSecure.getSessionMaxLossUsd()

        startForeground(NOTIF_ID, buildNotification(if (liveMode) "Trading bot running (LIVE)" else "Trading bot running (testnet)"))
        playStartSound()

        val client = BinanceApiClient(apiKey, apiSecret, useTestnet = !liveMode)
        sharedClient = client
        val strategy = StrategyCatalog.create(strategyId, applicationContext)
        log("Strategy: ${strategyId.displayName}")
        val risk = RiskManager(dailyTradingBudgetUsd = dailyBudgetUsd, maxDailyLossPercent = 0.03)
        historyStore = TradeHistoryStore(applicationContext)
        val aiMemoryStore = AiResearchMemoryStore(applicationContext)
        val aiCheckpointStore = AiAnalysisCheckpointStore(applicationContext)
        val session = SessionRiskManager(
            windowMs = SESSION_WINDOW_MS,
            sessionBudgetUsd = sessionBudgetUsd,
            sessionProfitTargetUsd = sessionProfitTargetUsd,
            sessionMaxLossUsd = sessionMaxLossUsd
        )
        historyStore.loadSessionRisk()?.let { session.restore(it) }
        val position = PositionTracker(
            stopLossPercent = stopLossPercent,
            takeProfitPercent = takeProfitPercent,
            trailingActivationPercent = trailingActivationPercent,
            trailingGivebackPercent = TRAILING_GIVEBACK_PERCENT,
            minNetExitPercent = CostModel.breakEvenMoveFraction(includeSlippage = true)
        )
        val stats = TradeStats()
        historyStore.restoreCumulative(stats)
        val persistedCircuit = historyStore.loadAutoBuyCircuitPaused()
        autoBuyCircuitPaused = persistedCircuit.first
        autoBuyCircuitReason = persistedCircuit.second
        protectionError = historyStore.loadProtectionError()
        val runtimePrefs = getSharedPreferences("trading_bot_runtime", MODE_PRIVATE)
        if (runtimePrefs.getBoolean("resume_auto_buy_requested", false)) {
            autoBuyCircuitPaused = false
            autoBuyCircuitReason = ""
            historyStore.saveAutoBuyCircuitPaused(false)
            runtimePrefs.edit().putBoolean("resume_auto_buy_requested", false).apply()
        }
        if (stats.totalTrades > 0) {
            log("Restored ${stats.totalTrades} prior trade(s) from device storage " +
                "(all-time net P&L $${"%.2f".format(stats.totalNetPnl)}).")
        }

        val priceHistory = ArrayDeque<Double>()
        var sessionHigh = 0.0
        var sessionLow = 0.0
        fun trackSession(p: Double) {
            if (sessionHigh <= 0.0 || p > sessionHigh) sessionHigh = p
            if (sessionLow <= 0.0 || p < sessionLow) sessionLow = p
        }
        var dayStartBalanceForPnl: Double? = null
        var consecutiveErrors = 0
        val openTradePath = ArrayDeque<Double>()

        var livePrice = 0.0
        var lastTickMs = 0L
        var lastLiveBroadcastMs = 0L
        var lastBalance = 0.0
        var lastEquity = 0.0
        var lastPnlPercent = 0.0
        var lastSignal = Signal.HOLD
        var lastReason = "Connecting to Binance live market stream…"
        val stateLock = Any()
        val dayFormat = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        var currentTradingDay: String? = null
        var loggedBudgetExhaustedToday = false
        val servicePrefs = getSharedPreferences("trading_bot_runtime", MODE_PRIVATE)
        currentAutoMode = servicePrefs.getBoolean("auto_mode", currentAutoMode)
        currentAutoExit = servicePrefs.getBoolean("auto_exit", currentAutoExit)

        var tradingLocked = false
        var tradingLockReason = ""
        val persistedLock = historyStore.loadTradingLock()
        if (persistedLock.first) {
            tradingLocked = true
            tradingLockReason = persistedLock.second
            log("HARD LOCK restored from disk: $tradingLockReason")
        }

        job?.cancel()
        streamEnabled = true
        connectionState = CONNECTION_CONNECTING

        val wsClient = OkHttpClient.Builder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build()
        val wsBaseUrl = if (liveMode) "wss://stream.binance.com:9443" else "wss://stream.testnet.binance.vision"
        val wsRequest = Request.Builder()
            .url("$wsBaseUrl/ws/${symbol.lowercase(java.util.Locale.US)}@trade")
            .build()
        lateinit var wsListener: WebSocketListener
        fun scheduleReconnect() {
            if (!streamEnabled || reconnectScheduled) return
            reconnectScheduled = true
            scope.launch {
                try {
                    // Small bounded backoff avoids a reconnect storm when Binance/network is down.
                    delay(2000L)
                    if (isActive && streamEnabled) {
                        liveWebSocket = wsClient.newWebSocket(wsRequest, wsListener)
                    }
                } finally {
                    reconnectScheduled = false
                }
            }
        }
        wsListener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                log("LIVE market stream connected for $symbol")
                lastReason = "Live Binance market stream connected"
                connectionState = CONNECTION_CONNECTED
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val json = JSONObject(text)
                    val price = json.optString("p").toDoubleOrNull() ?: return
                    if (!isPlausiblePrice(price, if (livePrice > 0) livePrice else null)) return
                    livePrice = price
                    lastTickMs = System.currentTimeMillis()
                    trackSession(price)
                    synchronized(stateLock) {
                        priceHistory.addLast(price)
                        if (priceHistory.size > 60) priceHistory.removeFirst()
                        if (position.inPosition) {
                            openTradePath.addLast(price)
                            if (openTradePath.size > 120) openTradePath.removeFirst()
                        }
                    }

                    if (position.inPosition && currentAutoExit) {
                        val exitReason = position.checkExit(price)
                        if (exitReason != ExitReason.NONE && liveExitInProgress.tryAcquire()) {
                            scope.launch {
                                try {
                                    synchronized(stateLock) {
                                        if (!position.inPosition) return@synchronized
                                    }
                                    val qty = position.quantity
                                    log("LIVE EXIT ($exitReason) @ $price — no polling delay")
                                    val fill = submitAndResolveOrder("SELL", qty, price)
                                    if (fill.executedQty <= 0.0) {
                                        log("REFUSING to book live exit: executedQty=0 status=${fill.status} " +
                                            "clientOrderId=${fill.clientOrderId}. Position stays open.")
                                        historyStore.clearPendingOrder()
                                        return@launch
                                    }
                                    if (!fill.fullyFilled) {
                                        log("WARNING: live exit only filled ${fill.executedQty} of $qty requested " +
                                            "(status ${fill.status}) — recording the executed portion only.")
                                    }
                                    val soldQty = fill.executedQty
                                    protectionError = ""
                                    historyStore.saveProtectionError(null)
                                    val cost = stats.recordTrade(position.entryPrice, fill.avgPrice, soldQty)
                                    historyStore.appendTrade(
                                        System.currentTimeMillis(), position.entryPrice, fill.avgPrice, soldQty, cost,
                                        openTradePath.toList(), fill.clientOrderId, fill.orderId, fill.status, exitReason.name, position.isManualTrade()
                                    )
                                    aiMemoryStore.recordLatestOutcome(symbol, cost.netPnl, exitReason.name)
                                    lastAiLinkedAnalysisId?.let { historyStore.recordAiResearchOutcome(it, cost.netPnl, exitReason.name) }
                                    lastAiLinkedAnalysisId = null
                                    historyStore.saveCumulative(stats)
                                    risk.recordTradeResult(cost.netPnl)
                                    session.recordTradeResult(cost.netPnl)
                                    historyStore.saveSessionRisk(session.snapshot())
                                    historyStore.saveDailyRisk(risk.snapshot(currentTradingDay ?: dayFormat.format(java.util.Date())))
                                    notifyTradeClosed(position.entryPrice, fill.avgPrice, soldQty, cost.netPnl)
                                    val exitMsg = position.exitReasonText(exitReason, fill.avgPrice)
                                    if (exitReason == ExitReason.TAKE_PROFIT && position.isManualTrade()) {
                                        notifyManualTargetHit(position.entryPrice, fill.avgPrice, soldQty)
                                    }
                                    synchronized(stateLock) {
                                        openTradePath.clear()
                                        if (fill.fullyFilled) {
                                            position.close()
                                        } else {
                                            position.reduceQuantity((qty - fill.executedQty).coerceAtLeast(0.0))
                                        }
                                        if (position.inPosition) {
                                            position.snapshot()?.let { snapshot -> historyStore.saveOpenPosition(snapshot) }
                                        } else {
                                            historyStore.clearOpenPosition()
                                        }
                                    }
                                    historyStore.clearPendingOrder()
                                    lastSignal = Signal.HOLD
                                    lastReason = exitMsg
                                    broadcastDashboardUpdate(lastBalance, lastEquity, lastPnlPercent, price, Signal.HOLD, priceHistory, stats, position, openTradePath, historyStore, risk.remainingBudget(), exitMsg, tradingLocked, sessionHigh = sessionHigh, sessionLow = sessionLow, streamStale = false, tradesToday = risk.tradesToday(), maxTradesPerDay = risk.maxTradesPerDayLimit(), consecutiveLosses = risk.consecutiveLosses(), maxConsecutiveLosses = risk.maxConsecutiveLossesLimit())
                                } catch (e: Exception) {
                                    val newProtectionError = "LIVE exit failed for $symbol: ${e.message ?: "unknown error"}"
                                    val shouldNotify = protectionError != newProtectionError
                                    protectionError = newProtectionError
                                    historyStore.saveProtectionError(protectionError)
                                    log("PROTECTION ERROR: $protectionError")
                                    if (shouldNotify) notifyProtectionFailure(protectionError)
                                } finally {
                                    liveExitInProgress.release()
                                }
                            }
                        }
                    }

                    // Throttle to at most every LIVE_TICK_INTERVAL_MS. The selected-symbol trade
                    // stream can fire many times a second; the dashboard doesn't need to
                    // redraw that fast, so re-serializing/broadcasting on every single trade
                    // print was pure waste. Position-exit checks above run on every tick
                    // regardless -- only this UI broadcast is throttled.
                    val nowLive = System.currentTimeMillis()
                    if (nowLive - lastLiveBroadcastMs >= LIVE_TICK_INTERVAL_MS) {
                        lastLiveBroadcastMs = nowLive
                        broadcastDashboardUpdate(lastBalance, lastEquity, lastPnlPercent, price, lastSignal, priceHistory, stats, position, openTradePath, historyStore, risk.remainingBudget(), lastReason, tradingLocked, sessionHigh = sessionHigh, sessionLow = sessionLow, streamStale = false, tradesToday = risk.tradesToday(), maxTradesPerDay = risk.maxTradesPerDayLimit(), consecutiveLosses = risk.consecutiveLosses(), maxConsecutiveLosses = risk.maxConsecutiveLossesLimit())
                    }
                } catch (e: Exception) {
                    log("Live stream message error: ${e.message}")
                }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                log("LIVE market stream disconnected: ${t.message ?: "unknown error"}; reconnecting…")
                lastReason = "Live stream reconnecting…"
                connectionState = CONNECTION_RECONNECTING
                scheduleReconnect()
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                log("LIVE market stream closed ($code): $reason; reconnecting…")
                lastReason = "Live stream reconnecting after close…"
                connectionState = CONNECTION_RECONNECTING
                scheduleReconnect()
            }
        }
        liveWebSocketClient = wsClient
        liveWebSocket = wsClient.newWebSocket(wsRequest, wsListener)

        job = scope.launch {
            log("Trading service started for $symbol (TESTNET + LIVE WebSocket)")
            log("Modeled break-even ≈ ${"%.2f".format(CostModel.breakEvenMoveFraction() * 100)}% after fees/TDS/tax/slippage.")

            var unresolvedOrderJournal = false
            try {
                val pendingOrder = historyStore.loadPendingOrder()
                if (pendingOrder != null) {
                    unresolvedOrderJournal = true
                    tradingLocked = true
                    tradingLockReason = "An order was in-flight when the app last stopped (${pendingOrder.side} ${pendingOrder.quantity} $symbol, clientOrderId=${pendingOrder.clientOrderId}). Exchange/local state must be reconciled before trading resumes."
                    historyStore.saveTradingLock(true, tradingLockReason)
                    log("HARD LOCK: $tradingLockReason")
                }
                val persistedPosition = historyStore.loadOpenPosition()
                val startupAccount = client.getAccountInfo()
                val baseOwned = client.getAssetTotal(startupAccount, baseAsset)
                // Matching saved positions resume normally; mismatched saved positions
                // and unrecognized base-asset balance without a saved position set tradingLocked.
                when {
                    persistedPosition != null && baseOwned > 0.0 &&
                        kotlin.math.abs(baseOwned - persistedPosition.quantity) <= maxOf(1e-8, persistedPosition.quantity * 0.001) -> {
                        // Exchange balance is authoritative for executable quantity.
                        // Preserve the saved entry/targets, but never restore more
                        // sellable quantity than the exchange currently reports.
                        position.restore(persistedPosition.copy(quantity = baseOwned))
                        // A previous mismatch lock is no longer needed once the
                        // persisted position and exchange balance reconcile.
                        if (tradingLocked && !unresolvedOrderJournal) {
                            tradingLocked = false
                            tradingLockReason = ""
                            historyStore.clearTradingLock()
                            log("Previous hard lock cleared: local position now matches exchange $baseAsset.")
                        }
                        log("Reconciled with exchange: resuming the open position from before restart " +
                            "(entry=${persistedPosition.entryPrice}, qty=${persistedPosition.quantity}) — " +
                            "confirmed against actual $baseAsset balance ($baseOwned).")
                    }
                    persistedPosition != null -> {
                        tradingLocked = true
                        tradingLockReason = "Local open-position record does not match exchange $baseAsset ($baseOwned vs ${persistedPosition.quantity}). Manual reconcile required."
                        historyStore.saveTradingLock(true, tradingLockReason)
                        historyStore.clearOpenPosition()
                        log("HARD LOCK: $tradingLockReason Automatic BUY is disabled.")
                    }
                    baseOwned > 0.00000001 -> {
                        tradingLocked = true
                        tradingLockReason = "Exchange shows unrecognized $baseAsset ($baseOwned) with no local position. Manual reconcile required."
                        historyStore.saveTradingLock(true, tradingLockReason)
                        log("HARD LOCK: $tradingLockReason Automatic BUY is disabled.")
                    }
                    else -> {
                        // If an old mismatch lock exists but the exchange is now
                        // flat, the user has reconciled the mismatch externally.
                        // Clear only this hard-lock state; daily-loss protection is
                        // stored separately in RiskManager.
                        if (tradingLocked && !unresolvedOrderJournal) {
                            tradingLocked = false
                            tradingLockReason = ""
                            historyStore.clearTradingLock()
                            log("Previous hard lock cleared: exchange is now flat and there is no local position.")
                        }
                    }
                }
            } catch (e: Exception) {
                tradingLocked = true
                tradingLockReason = "Could not verify exchange position at startup: ${e.message ?: "unknown error"}. Automatic BUY is disabled until a successful reconciliation."
                historyStore.saveTradingLock(true, tradingLockReason)
                log("HARD LOCK: $tradingLockReason")
            }

            var lastRestCycleMs = 0L
            while (isActive) {
                try {
                    if (runtimePrefs.getBoolean("resume_auto_buy_requested", false)) {
                        autoBuyCircuitPaused = false
                        autoBuyCircuitReason = ""
                        historyStore.saveAutoBuyCircuitPaused(false)
                        runtimePrefs.edit().putBoolean("resume_auto_buy_requested", false).apply()
                        log("AUTO-BUY circuit breaker manually resumed.")
                    }
                    val nowMs = System.currentTimeMillis()
                    if (!manualRefreshRequested && lastRestCycleMs > 0L && nowMs - lastRestCycleMs < POLL_INTERVAL_MS) {
                        delay(250L)
                        continue
                    }
                    manualRefreshRequested = false
                    lastRestCycleMs = nowMs

                    val klines = client.getKlines(symbol, "1m", 220)
                    val restClose = klines.getJSONArray(klines.length() - 1).getString(4).toDouble()
                    val staleStream = connectionState != CONNECTION_CONNECTED ||
                        livePrice <= 0.0 || lastTickMs <= 0L || nowMs - lastTickMs > STALE_TICK_MS
                    // When the stream is stale/disconnected, use fresh REST price data for
                    // protection and account valuation rather than the last stale tick.
                    val lastClose = if (!staleStream && livePrice > 0.0) livePrice else restClose
                    trackSession(lastClose)

                    if (!isPlausiblePrice(lastClose, priceHistory.lastOrNull())) {
                        log("Skipping cycle — implausible price from exchange ($lastClose vs last trusted ${priceHistory.lastOrNull()}).")
                        delay(POLL_INTERVAL_MS)
                        continue
                    }

                    val account = client.getAccountInfo()
                    val usdtFree = extractBalance(account, "USDT")
                    val btcTotal = client.getAssetTotal(account, baseAsset)
                    val equity = usdtFree + btcTotal * lastClose
                    val usdtBalance = usdtFree

                    val today = dayFormat.format(java.util.Date())
                    if (currentTradingDay == null) {
                        currentTradingDay = today
                        val persistedRisk = historyStore.loadDailyRisk()
                        if (persistedRisk != null) {
                            risk.restore(persistedRisk, today, equity, usdtFree)
                            if (persistedRisk.tradingDay == today) {
                                dayStartBalanceForPnl = persistedRisk.dayStartEquity
                                log("Restored same-day risk: remaining budget \$${"%.2f".format(risk.remainingBudget())}, used \$${"%.2f".format(risk.dailyNotionalUsed())}, " +
                                    "lock=${risk.isDailyStopLocked()}, tradesToday=${risk.tradesToday()}.")
                            } else {
                                log("New calendar day vs persisted risk — starting a fresh daily budget.")
                            }
                        }
                    } else if (currentTradingDay != today) {
                        log("New trading day ($today) — resetting today's trading budget to \$${"%.2f".format(dailyBudgetUsd)} " +
                            "and the daily loss limit. Any open position is carried into the new day, but today's risk accounting starts fresh.")
                        currentTradingDay = today
                        dayStartBalanceForPnl = equity
                        loggedBudgetExhaustedToday = false
                        sessionHigh = lastClose
                        sessionLow = lastClose
                        risk.resetDay(equity, usdtFree)
                        historyStore.saveDailyRisk(risk.snapshot(today))
                    }

                    val wasLocked = risk.isDailyStopLocked()
                    risk.updateBalance(equity, usdtFree)
                    if (dayStartBalanceForPnl == null) dayStartBalanceForPnl = equity
                    if (!wasLocked && risk.isDailyStopLocked()) {
                        log("Daily loss lock engaged — new entries blocked for the rest of today (survives restart).")
                        notifyDailyLossLimitHit()
                    }
                    historyStore.saveDailyRisk(risk.snapshot(currentTradingDay ?: today))

                    val pnlPercent = dayStartBalanceForPnl?.let { start ->
                        if (start > 0) ((equity - start) / start) * 100.0 else 0.0
                    } ?: 0.0

                    var manualActionHandled = false
                    // Process an explicit manual action in the same serialized loop as
                    // automatic trading. Manual mode bypasses the strategy decision, but
                    // it never bypasses exchange filters, balance checks, stale-data checks,
                    // duplicate-position protection, or exchange fill verification.
                    if (pendingManualBuy) {
                        manualActionHandled = true
                        val requestedAmount = pendingManualAmountUsd.coerceAtLeast(1.0)
                        val requestedStop = pendingManualStopLossPercent.coerceIn(0.001, 0.50)
                        val requestedTarget = pendingManualTakeProfitPercent.coerceIn(0.0, 2.0)
                        pendingManualBuy = false
                        if (position.inPosition) {
                            lastReason = "Manual BUY ignored: a position is already open."
                        } else if (tradingLocked) {
                            lastReason = "Manual BUY blocked: $tradingLockReason"
                        } else if (staleStream || lastClose <= 0.0) {
                            lastReason = "Manual BUY blocked: live price data is stale or unavailable."
                        } else {
                            try {
                                val manualGate = risk.newEntryBlockReason(System.currentTimeMillis(), ENTRY_COOLDOWN_MS)
                                    ?: session.entryBlockReason(System.currentTimeMillis())
                                val allowedManualUsd = minOf(requestedAmount, risk.remainingBudget(), session.capTradeValueUsd(requestedAmount))
                                if (manualGate != null) {
                                    lastReason = "Manual BUY blocked: $manualGate"
                                } else if (requestedAmount > allowedManualUsd + 1e-9) {
                                    lastReason = "Manual BUY blocked: requested \$${"%.2f".format(requestedAmount)} exceeds remaining risk budget (daily \$${"%.2f".format(risk.remainingBudget())}, session \$${"%.2f".format(session.capTradeValueUsd(requestedAmount))})."
                                } else {
                                val rules = client.getSymbolRules(symbol)
                                val qty = client.roundToStepSize((requestedAmount / lastClose).coerceAtMost(usdtFree / lastClose), rules)
                                if (qty < rules.minQty || qty * lastClose < rules.minNotional) {
                                    lastReason = "Manual BUY blocked: $${"%.2f".format(requestedAmount)} is below Binance's minimum order size for $symbol."
                                } else {
                                    val fill = submitAndResolveOrder("BUY", qty, lastClose)
                                    if (fill.executedQty <= 0.0) {
                                        historyStore.clearPendingOrder()
                                        lastReason = "Manual BUY failed: Binance reported no executed quantity."
                                    } else {
                                        val filledNotional = fill.avgPrice * fill.executedQty
                                        risk.recordEntryNotional(filledNotional)
                                        session.recordEntryNotional(filledNotional)
                                        position.openWithTargets(fill.avgPrice, fill.executedQty, requestedStop, requestedTarget, manualTrade = true)
                                        historyStore.saveDailyRisk(risk.snapshot(currentTradingDay ?: today))
                                        historyStore.saveSessionRisk(session.snapshot())
                                        position.snapshot()?.let { snapshot -> historyStore.saveOpenPosition(snapshot) }
                                        historyStore.clearPendingOrder()
                                        openTradePath.clear(); openTradePath.addLast(fill.avgPrice)
                                        lastSignal = Signal.BUY
                                        lastReason = "Manual BUY filled · entry ${"%.2f".format(fill.avgPrice)} · SL -${"%.2f".format(requestedStop * 100)}% · TP +${"%.2f".format(requestedTarget * 100)}%."
                                        notifyTradeOpened(fill.avgPrice, fill.executedQty)
                                    }
                                }
                                }
                            } catch (e: Exception) {
                                lastReason = "Manual BUY error: ${e.message ?: "unknown error"}"
                                log(lastReason)
                            }
                        }
                    }

                    if (pendingReconcile) {
                        manualActionHandled = true
                        val adopt = pendingReconcileAdopt
                        pendingReconcile = false
                        try {
                            val account = client.getAccountInfo()
                            val exchangeBase = client.getAssetTotal(account, baseAsset)
                            if (adopt) {
                                if (exchangeBase <= 0.00000001) {
                                    lastReason = "Reconcile (Adopt) skipped: exchange no longer shows a $baseAsset balance to adopt."
                                } else {
                                    try {
                                        val recentTrades = client.getMyTrades(symbol, 1000)
                                        val basis = client.derivePositionCostBasis(recentTrades, exchangeBase)
                                        if (basis == null) {
                                            tradingLocked = true
                                            tradingLockReason = "Cannot safely adopt exchange $baseAsset: recent trade history does not explain the full balance. Entry price is unknown; manual reconciliation required."
                                            historyStore.saveTradingLock(true, tradingLockReason)
                                            lastReason = tradingLockReason
                                        } else {
                                            position.openWithTargets(basis.averageEntryPrice, exchangeBase, DEFAULT_STOP_LOSS_PERCENT, DEFAULT_TAKE_PROFIT_PERCENT, manualTrade = true)
                                            position.snapshot()?.let { snapshot -> historyStore.saveOpenPosition(snapshot) }
                                            openTradePath.clear(); openTradePath.addLast(basis.averageEntryPrice)
                                            tradingLocked = false
                                            tradingLockReason = ""
                                            historyStore.clearTradingLock()
                                            lastReason = "Reconciled: adopted $exchangeBase $baseAsset using exchange trade history; FIFO entry ~${"%.2f".format(basis.averageEntryPrice)}."
                                            log("Reconcile (Adopt): cost basis derived from exchange trades; no synthetic current-price entry was created.")
                                        }
                                    } catch (e: Exception) {
                                        tradingLocked = true
                                        tradingLockReason = "Cannot safely adopt exchange $baseAsset: ${e.message ?: "trade-history lookup failed"}. Manual reconciliation required."
                                        historyStore.saveTradingLock(true, tradingLockReason)
                                        lastReason = tradingLockReason
                                    }
                                }
                            } else {
                                val localQty = position.quantity
                                val localOpen = position.inPosition
                                val matches = (!localOpen && exchangeBase <= 0.00000001) ||
                                    (localOpen && exchangeBase > 0.00000001 &&
                                        kotlin.math.abs(exchangeBase - localQty) <= maxOf(1e-8, localQty * 0.001))
                                if (matches) {
                                    tradingLocked = false
                                    tradingLockReason = ""
                                    historyStore.clearTradingLock()
                                    lastReason = "Reconciled: exchange and local position state match; lock cleared."
                                    log("Reconcile (Clear lock): exchange/local position state verified; lock cleared.")
                                } else {
                                    tradingLocked = true
                                    tradingLockReason = "Cannot clear reconciliation lock: exchange $baseAsset=$exchangeBase but local position=${if (localOpen) localQty else 0.0}. Adopt or externally flatten/reconcile the position first."
                                    historyStore.saveTradingLock(true, tradingLockReason)
                                    lastReason = tradingLockReason
                                    log("HARD LOCK: $tradingLockReason")
                                }
                            }
                        } catch (e: Exception) {
                            lastReason = "Reconcile error: ${e.message ?: "unknown error"}"
                            log(lastReason)
                        }
                    }

                    if (pendingManualSell) {
                        manualActionHandled = true
                        pendingManualSell = false
                        if (position.inPosition && liveExitInProgress.tryAcquire()) {
                            try {
                                val entryBeforeClose = position.entryPrice
                                val qty = position.quantity
                                val fill = submitAndResolveOrder("SELL", qty, lastClose)
                                if (fill.executedQty <= 0.0) {
                                    historyStore.clearPendingOrder()
                                    protectionError = "Manual exit failed/unknown for $symbol: executedQty=0, status=${fill.status}, clientOrderId=${fill.clientOrderId}"
                                    historyStore.saveProtectionError(protectionError)
                                    notifyProtectionFailure(protectionError)
                                    lastReason = "Manual SELL failed: Binance reported no executed quantity."
                                } else {
                                    val soldQty = fill.executedQty
                                    protectionError = ""
                                    historyStore.saveProtectionError(null)
                                    val cost = stats.recordTrade(entryBeforeClose, fill.avgPrice, soldQty)
                                    historyStore.appendTrade(System.currentTimeMillis(), entryBeforeClose, fill.avgPrice, soldQty, cost, openTradePath.toList(), fill.clientOrderId, fill.orderId, fill.status, ExitReason.MANUAL_CLOSE.name, true)
                                    aiMemoryStore.recordLatestOutcome(symbol, cost.netPnl, ExitReason.MANUAL_CLOSE.name)
                                    lastAiLinkedAnalysisId?.let { historyStore.recordAiResearchOutcome(it, cost.netPnl, ExitReason.MANUAL_CLOSE.name) }
                                    lastAiLinkedAnalysisId = null
                                    historyStore.saveCumulative(stats)
                                    risk.recordTradeResult(cost.netPnl)
                                    session.recordTradeResult(cost.netPnl)
                                    historyStore.saveSessionRisk(session.snapshot())
                                    historyStore.saveDailyRisk(risk.snapshot(today))
                                    if (fill.fullyFilled) { position.close(); historyStore.clearOpenPosition(); openTradePath.clear() }
                                    else { position.reduceQuantity((qty - fill.executedQty).coerceAtLeast(0.0)); position.snapshot()?.let { snapshot -> historyStore.saveOpenPosition(snapshot) } }
                                    historyStore.clearPendingOrder()
                                    lastSignal = Signal.HOLD
                                    lastReason = "Manual SELL filled at ${"%.2f".format(fill.avgPrice)} · net P&L ${"%+.2f".format(cost.netPnl)}."
                                    notifyTradeClosed(entryBeforeClose, fill.avgPrice, soldQty, cost.netPnl)
                                }
                            } catch (e: Exception) {
                                lastReason = "Manual SELL error: ${e.message ?: "unknown error"}"
                                log(lastReason)
                            } finally {
                                liveExitInProgress.release()
                            }
                        } else if (liveExitInProgress.isHeld()) {
                            lastReason = "Manual SELL ignored: an automatic protection exit is already being processed."
                        } else {
                            lastReason = "Manual SELL ignored: no open position."
                        }
                    }

                    val decision = strategy.evaluate(klines)
                    val signal = decision.signal
                    lastBalance = usdtBalance
                    lastEquity = equity
                    lastPnlPercent = pnlPercent
                    if (!manualActionHandled) {
                        lastSignal = signal
                        lastReason = decision.reason
                    }

                    priceHistory.addLast(lastClose)
                    if (priceHistory.size > 30) priceHistory.removeFirst()

                    if (position.inPosition) {
                        openTradePath.addLast(lastClose)
                        if (openTradePath.size > 120) openTradePath.removeFirst()
                    }
                    var entryGateBlockReason: String? = null
                    var tvActionForAi: String? = null
                    if (signal == Signal.BUY && currentAutoMode && !manualActionHandled && !position.inPosition && !staleStream) {
                        val gateStorage = SecureStorage(applicationContext)
                        if (gateStorage.getTradingViewGateEnabled()) {
                            try {
                                val tv = TradingViewSignalClient.latest(
                                    gateStorage.getTradingViewRelayUrl(), gateStorage.getTradingViewRelayToken(), symbol
                                )
                                val ageMs = tv?.let { nowMs - it.timeMs }
                                tvActionForAi = tv?.action
                                entryGateBlockReason = when {
                                    tv == null -> "TradingView gate: no valid relay signal is available."
                                    ageMs == null || ageMs < 0L || ageMs > gateStorage.getTradingViewMaxAgeMinutes() * 60_000L -> "TradingView gate: latest signal is stale."
                                    !tv.action.equals("BUY", ignoreCase = true) -> "TradingView gate: latest signal is ${tv.action}, not BUY."
                                    else -> null
                                }
                            } catch (e: Exception) {
                                entryGateBlockReason = "TradingView gate: relay unavailable (${e.message ?: "unknown error"})."
                            }
                        }
                        if (entryGateBlockReason == null && gateStorage.getAiTradeGateEnabled()) {
                            try {
                                val verified = MarketDataValidator.buildClosedSnapshot(symbol, klines, nowMs, minimumCandles = 200)
                                if (!verified.isValid || verified.snapshot == null) {
                                    entryGateBlockReason = "AI gate: market snapshot REVIEW — ${verified.errors.joinToString("; ")}".trim()
                                    lastAiLinkedAnalysisId = null
                                } else if (verified.snapshot.dataAgeMs > 180_000L) {
                                    entryGateBlockReason = "AI gate: verified candle is stale (${verified.snapshot.dataAgeMs / 1000}s old)."
                                    lastAiLinkedAnalysisId = null
                                } else {
                                    val gateResult = AiResearchEngine.evaluate(
                                        gateStorage.getOpenAiApiKey(), verified.snapshot, decision, tvActionForAi, aiCheckpointStore, aiMemoryStore
                                    )
                                    aiMemoryStore.saveDecision(gateResult.decision, tradeLinked = false)
                                    historyStore.appendAiResearchDecision(gateResult.decision)
                                    val threshold = gateStorage.getAiTradeGateThreshold() / 100.0
                                    lastAiLinkedAnalysisId = null
                                    entryGateBlockReason = when {
                                        gateResult.decision.signal != AiResearchEngine.AiSignal.BUY -> "AI gate: ${gateResult.decision.signal} — ${gateResult.decision.reasoning}"
                                        gateResult.decision.confidence < threshold -> "AI gate: confidence ${"%.1f".format(gateResult.decision.confidence * 100)}% is below ${"%.1f".format(gateStorage.getAiTradeGateThreshold())}%."
                                        gateResult.decision.entryPrice != null && kotlin.math.abs(gateResult.decision.entryPrice - lastClose) / lastClose > 0.02 -> "AI gate: suggested entry is too far from the current verified price."
                                        else -> {
                                            aiMemoryStore.markTradeLinked(gateResult.decision.analysisId)
                                            lastAiLinkedAnalysisId = gateResult.decision.analysisId
                                            log("AI gate APPROVED BUY @ $lastClose — ${"%.1f".format(gateResult.decision.confidence * 100)}% confidence; R:R ${gateResult.decision.riskReward?.let { "%.2f".format(it) } ?: "n/a"}")
                                            null
                                        }
                                    }
                                    if (gateResult.decision.signal == AiResearchEngine.AiSignal.REVIEW || gateResult.decision.signal == AiResearchEngine.AiSignal.HOLD) {
                                        log("AI gate BLOCKED entry: ${gateResult.decision.reasoning}")
                                    }
                                }
                            } catch (e: Exception) {
                                lastAiLinkedAnalysisId = null
                                entryGateBlockReason = "AI gate: REVIEW because research failed (${e.message ?: "unknown error"})."
                            }
                        }
                    }

                    val reasonText = when {
                        tradingLocked -> "HARD LOCK: $tradingLockReason"
                        protectionError.isNotBlank() && position.inPosition -> "PROTECTION ERROR: $protectionError"
                        staleStream && !position.inPosition -> "Live price stream is stale/disconnected (>${STALE_TICK_MS / 1000}s). New entries blocked; REST price is used for protection."
                        risk.isDailyStopLocked() -> "Daily loss lock — monitoring only, no new entries."
                        entryGateBlockReason != null -> entryGateBlockReason!!
                        position.inPosition -> position.statusReason(lastClose)
                        else -> decision.reason
                    }
                    broadcastDashboardUpdate(usdtBalance, equity, pnlPercent, lastClose, signal, priceHistory, stats, position, openTradePath, historyStore, risk.remainingBudget(), reasonText, tradingLocked, sessionHigh = sessionHigh, sessionLow = sessionLow, streamStale = staleStream, tradesToday = risk.tradesToday(), maxTradesPerDay = risk.maxTradesPerDayLimit(), consecutiveLosses = risk.consecutiveLosses(), maxConsecutiveLosses = risk.maxConsecutiveLossesLimit())

                    if (position.inPosition && currentAutoExit) {
                        val exitReason = position.checkExit(lastClose)
                        val shouldExitOnSignal = signal == Signal.SELL &&
                            position.holdDurationMs(System.currentTimeMillis()) >= MIN_HOLD_MS

                        if ((exitReason != ExitReason.NONE || shouldExitOnSignal) && liveExitInProgress.tryAcquire()) {
                            val reason = if (exitReason != ExitReason.NONE) exitReason else ExitReason.REVERSAL_SIGNAL
                            val requestedQty = position.quantity
                            log("EXIT ($reason) @ $lastClose — closing position of $requestedQty $symbol")
                            val fill = submitAndResolveOrder("SELL", requestedQty, lastClose)
                            if (fill.executedQty <= 0.0) {
                                historyStore.clearPendingOrder()
                                val newProtectionError = "Exit failed/unknown for $symbol: executedQty=0, status=${fill.status}, clientOrderId=${fill.clientOrderId}"
                                val shouldNotify = protectionError != newProtectionError
                                protectionError = newProtectionError
                                historyStore.saveProtectionError(protectionError)
                                if (shouldNotify) notifyProtectionFailure(protectionError)
                                log("PROTECTION ERROR: $protectionError")
                                log("REFUSING to book exit: executedQty=0 status=${fill.status} " +
                                    "clientOrderId=${fill.clientOrderId}. Local position stays open.")
                            } else {
                                if (!fill.fullyFilled) {
                                    log("WARNING: exit only filled ${fill.executedQty} of $requestedQty requested " +
                                        "(status ${fill.status}) — recording the executed portion only.")
                                }
                                val soldQty = fill.executedQty
                                val exitReasonMsg = position.exitReasonText(reason, fill.avgPrice)
                                if (reason == ExitReason.TAKE_PROFIT && position.isManualTrade()) {
                                    notifyManualTargetHit(position.entryPrice, fill.avgPrice, soldQty)
                                }
                                log("  -> why: $exitReasonMsg (actual fill avg ${fill.avgPrice}, requested at $lastClose)")
                                val cost = stats.recordTrade(position.entryPrice, fill.avgPrice, soldQty)
                                notifyTradeClosed(position.entryPrice, fill.avgPrice, soldQty, cost.netPnl)
                                historyStore.appendTrade(
                                    System.currentTimeMillis(), position.entryPrice, fill.avgPrice, soldQty, cost,
                                    openTradePath.toList(), fill.clientOrderId, fill.orderId, fill.status, "", position.isManualTrade()
                                )
                                val aiOutcomeReason = if (shouldExitOnSignal) ExitReason.REVERSAL_SIGNAL.name else "PROTECTION"
                                aiMemoryStore.recordLatestOutcome(symbol, cost.netPnl, aiOutcomeReason)
                                lastAiLinkedAnalysisId?.let { historyStore.recordAiResearchOutcome(it, cost.netPnl, aiOutcomeReason) }
                                lastAiLinkedAnalysisId = null
                                openTradePath.clear()
                                historyStore.saveCumulative(stats)
                                risk.recordTradeResult(cost.netPnl)
                                session.recordTradeResult(cost.netPnl)
                                historyStore.saveSessionRisk(session.snapshot())
                                historyStore.saveDailyRisk(risk.snapshot(currentTradingDay ?: today))
                                loggedBudgetExhaustedToday = false
                                log(
                                    "  -> gross P&L $${"%.2f".format(cost.grossPnl)}, " +
                                        "fees $${"%.2f".format(cost.exchangeFees)}, " +
                                        "TDS $${"%.2f".format(cost.tds)}, " +
                                        "tax est. $${"%.2f".format(cost.taxOnGain)}, " +
                                        "net $${"%.2f".format(cost.netPnl)}, " +
                                        "remaining today's budget $${"%.2f".format(risk.remainingBudget())}"
                                )
                                if (fill.fullyFilled) {
                                    position.close()
                                    historyStore.clearOpenPosition()
                                } else {
                                    position.reduceQuantity((requestedQty - fill.executedQty).coerceAtLeast(0.0))
                                    position.snapshot()?.let { snapshot -> historyStore.saveOpenPosition(snapshot) } ?: historyStore.clearOpenPosition()
                                }
                                broadcastDashboardUpdate(usdtBalance, equity, pnlPercent, lastClose, Signal.HOLD, priceHistory, stats, position, openTradePath, historyStore, risk.remainingBudget(), exitReasonMsg, tradingLocked, sessionHigh = sessionHigh, sessionLow = sessionLow, streamStale = staleStream, tradesToday = risk.tradesToday(), maxTradesPerDay = risk.maxTradesPerDayLimit(), consecutiveLosses = risk.consecutiveLosses(), maxConsecutiveLosses = risk.maxConsecutiveLossesLimit())
                                historyStore.clearPendingOrder()
                            }
                            liveExitInProgress.release()
                        } else {
                            log("Holding position, entry=${position.entryPrice}, current=$lastClose")
                        }
                    } else if (signal == Signal.BUY && currentAutoMode && !manualActionHandled) {
                        val lockReason = when {
                            tradingLocked -> "HARD LOCK: $tradingLockReason"
                            autoBuyCircuitPaused -> "AUTO-BUY circuit breaker is paused${if (autoBuyCircuitReason.isNotBlank()) ": $autoBuyCircuitReason" else ". Resume manually after the failure condition is understood."}"
                            staleStream -> "Live price stream is stale or disconnected — new entries blocked."
                            entryGateBlockReason != null -> entryGateBlockReason!!
                            else -> risk.newEntryBlockReason(System.currentTimeMillis(), ENTRY_COOLDOWN_MS)
                                ?: session.entryBlockReason(System.currentTimeMillis())
                        }
                        if (lockReason != null) {
                            if (lastReason != lockReason) log(lockReason)
                            lastReason = lockReason
                            broadcastDashboardUpdate(usdtBalance, equity, pnlPercent, lastClose, Signal.HOLD, priceHistory, stats, position, openTradePath, historyStore, risk.remainingBudget(), lockReason, tradingLocked, sessionHigh = sessionHigh, sessionLow = sessionLow, streamStale = staleStream, tradesToday = risk.tradesToday(), maxTradesPerDay = risk.maxTradesPerDayLimit(), consecutiveLosses = risk.consecutiveLosses(), maxConsecutiveLosses = risk.maxConsecutiveLossesLimit())
                        } else {
                            val rules = client.getSymbolRules(symbol)
                            val rawTradeValueUsd = session.capTradeValueUsd(risk.tradeQuantity(lastClose) * lastClose)
                            val rawQty = rawTradeValueUsd / lastClose
                            val qty = client.roundToStepSize(rawQty, rules)

                            if (qty < rules.minQty || qty * lastClose < rules.minNotional) {
                                val skipMsg = "Signal was BUY (${decision.reason}) but today's remaining trading budget " +
                                    "(\$${"%.2f".format(risk.remainingBudget())}) sizes to a quantity " +
                                    "($qty ≈ \$${"%.2f".format(qty * lastClose)}) below the exchange's minimum order " +
                                    "size (min notional \$${rules.minNotional}). No more trades will be placed today " +
                                    "-- the budget refills to \$${"%.2f".format(dailyBudgetUsd)} at tomorrow's reset."
                                if (!loggedBudgetExhaustedToday) {
                                    log(skipMsg)
                                    loggedBudgetExhaustedToday = true
                                }
                                broadcastDashboardUpdate(usdtBalance, equity, pnlPercent, lastClose, Signal.HOLD, priceHistory, stats, position, openTradePath, historyStore, risk.remainingBudget(), skipMsg, tradingLocked, sessionHigh = sessionHigh, sessionLow = sessionLow, streamStale = staleStream, tradesToday = risk.tradesToday(), maxTradesPerDay = risk.maxTradesPerDayLimit(), consecutiveLosses = risk.consecutiveLosses(), maxConsecutiveLosses = risk.maxConsecutiveLossesLimit())
                            } else {
                                log("ENTRY (BUY) @ $lastClose — opening position of $qty $symbol")
                                val fill = submitAndResolveOrder("BUY", qty, lastClose)
                                if (fill.executedQty <= 0.0) {
                                    historyStore.clearPendingOrder()
                                    log("REFUSING to open position: executedQty=0 status=${fill.status} " +
                                        "clientOrderId=${fill.clientOrderId}. Local state stays flat.")
                                } else {
                                    if (!fill.fullyFilled) {
                                        log("WARNING: entry only filled ${fill.executedQty} of $qty requested " +
                                            "(status ${fill.status}) — position opened at the executed size only.")
                                    }
                                    val filledQty = fill.executedQty
                                    val filledNotional = fill.avgPrice * filledQty
                                    risk.recordEntryNotional(filledNotional)
                                    session.recordEntryNotional(filledNotional)
                                    historyStore.saveDailyRisk(risk.snapshot(currentTradingDay ?: today))
                                    historyStore.saveSessionRisk(session.snapshot())
                                    position.open(fill.avgPrice, filledQty)
                                    position.snapshot()?.let { snapshot -> historyStore.saveOpenPosition(snapshot) }
                                    historyStore.clearPendingOrder()
                                    openTradePath.clear()
                                    openTradePath.addLast(fill.avgPrice)
                                    log("  -> filled avg ${fill.avgPrice} (quoted $lastClose), qty $filledQty order=${fill.orderId}")
                                    notifyTradeOpened(fill.avgPrice, filledQty)
                                    broadcastDashboardUpdate(usdtBalance, equity, pnlPercent, lastClose, Signal.BUY, priceHistory, stats, position, openTradePath, historyStore, risk.remainingBudget(), decision.reason, tradingLocked, sessionHigh = sessionHigh, sessionLow = sessionLow, streamStale = staleStream, tradesToday = risk.tradesToday(), maxTradesPerDay = risk.maxTradesPerDayLimit(), consecutiveLosses = risk.consecutiveLosses(), maxConsecutiveLosses = risk.maxConsecutiveLossesLimit())
                                }
                            }
                        }
                    } else {
                        log("No position, no entry signal @ $lastClose")
                    }
                    consecutiveErrors = 0
                } catch (e: Exception) {
                    liveExitInProgress.release()
                    log("Error in trading loop: ${e.message}")
                    consecutiveErrors++
                    if (consecutiveErrors >= 5) {
                        autoBuyCircuitPaused = true
                        autoBuyCircuitReason = "Consecutive trading-loop failures reached $consecutiveErrors."
                        historyStore.saveAutoBuyCircuitPaused(true, autoBuyCircuitReason)
                        notifyRepeatedFailures(e.message ?: "unknown error")
                    }
                }
                delay(250L)
            }
            log("Trading service loop ended.")
        }

        return START_STICKY
    }

    override fun onDestroy() {
        streamEnabled = false
        liveWebSocket?.close(1000, "service stopped")
        liveWebSocket = null
        liveWebSocketClient?.dispatcher?.executorService?.shutdown()
        liveWebSocketClient = null
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    private fun extractBalance(account: org.json.JSONObject, asset: String): Double {
        val balances = account.optJSONArray("balances") ?: return 0.0
        for (i in 0 until balances.length()) {
            val entry = balances.getJSONObject(i)
            if (entry.getString("asset") == asset) {
                return entry.getString("free").toDouble()
            }
        }
        return 0.0
    }

    private fun formatQty(qty: Double): String {
        return String.format(java.util.Locale.US, "%.8f", qty).trimEnd('0').trimEnd('.')
    }

    private fun log(msg: String) {
        onLog?.invoke(msg)
    }

    private fun broadcastDashboardUpdate(
        balance: Double,
        equity: Double,
        pnlPercent: Double,
        lastPrice: Double,
        signal: Signal,
        priceHistory: ArrayDeque<Double>,
        stats: TradeStats,
        position: PositionTracker,
        openTradePath: ArrayDeque<Double>,
        historyStore: TradeHistoryStore,
        riskRemainingBudget: Double,
        reasonText: String = "",
        tradingLocked: Boolean = false,
        sessionHigh: Double = 0.0,
        sessionLow: Double = 0.0,
        streamStale: Boolean = false,
        tradesToday: Int = 0,
        maxTradesPerDay: Int = 0,
        consecutiveLosses: Int = 0,
        maxConsecutiveLosses: Int = 0
    ) {
        val intent = Intent(ACTION_DASHBOARD_UPDATE).apply {
            putExtra(EXTRA_BALANCE, balance)
            putExtra(EXTRA_EQUITY, equity)
            putExtra(EXTRA_PNL_PERCENT, pnlPercent)
            putExtra(EXTRA_LAST_PRICE, lastPrice)
            putExtra(EXTRA_SIGNAL, signal.name)
            putExtra(EXTRA_PRICE_HISTORY, priceHistory.joinToString(","))
            putExtra(EXTRA_WIN_RATE, stats.winRatePercent())
            putExtra(EXTRA_TOTAL_TRADES, stats.totalTrades)
            putExtra(EXTRA_NET_PNL, stats.totalNetPnl)
            putExtra(EXTRA_FEES_PLUS_TDS, stats.totalExchangeFees + stats.totalTds)
            putExtra(EXTRA_TAX_ESTIMATE, stats.totalTaxEstimate)
            putExtra(EXTRA_FIXED_TRADE_AMOUNT, riskRemainingBudget)
            putExtra(EXTRA_POSITION_OPEN, position.inPosition)
            putExtra(EXTRA_ENTRY_PRICE, if (position.inPosition) position.entryPrice else 0.0)
            putExtra(EXTRA_QUANTITY, if (position.inPosition) position.quantity else 0.0)
            putExtra(EXTRA_OPEN_TRADE_PATH, openTradePath.joinToString(","))
            putExtra(EXTRA_TRADE_HISTORY, historyStore.getTradesJson())
            putExtra(EXTRA_SIGNAL_REASON, reasonText)
            putExtra(EXTRA_TRADING_LOCKED, tradingLocked)
            putExtra(EXTRA_ENTRY_TIMESTAMP_MS, position.entryTimeMs())
            putExtra(EXTRA_STOP_LOSS_PRICE, position.stopLossPriceLevel())
            putExtra(EXTRA_TRAILING_ARM_PRICE, position.trailingArmPriceLevel())
            putExtra(EXTRA_TAKE_PROFIT_PRICE, position.takeProfitPriceLevel())
            putExtra(EXTRA_AUTO_MODE, currentAutoMode)
            putExtra(EXTRA_AUTO_EXIT, currentAutoExit)
            putExtra(EXTRA_MODE_STATUS, if (currentAutoMode) "AUTO" else "MANUAL")
            putExtra(EXTRA_BULLISH_SCORE, 0)
            putExtra(EXTRA_BEARISH_SCORE, 0)
            putExtra(EXTRA_SIGNAL_QUALITY, 0)
            putExtra(EXTRA_POSITION_STATUS_TEXT, if (position.inPosition) position.statusReason(lastPrice) else "")
            putExtra(EXTRA_SESSION_HIGH, sessionHigh)
            putExtra(EXTRA_SESSION_LOW, sessionLow)
            putExtra(EXTRA_STREAM_STALE, streamStale)
            putExtra(EXTRA_CONNECTION_STATE, connectionState)
            putExtra(EXTRA_TRADES_TODAY, tradesToday)
            putExtra(EXTRA_MAX_TRADES_PER_DAY, maxTradesPerDay)
            putExtra(EXTRA_CONSECUTIVE_LOSSES, consecutiveLosses)
            putExtra(EXTRA_MAX_CONSECUTIVE_LOSSES, maxConsecutiveLosses)
            putExtra(EXTRA_AUTO_BUY_CIRCUIT_PAUSED, autoBuyCircuitPaused)
            putExtra(EXTRA_PROTECTION_ERROR, protectionError)
            putExtra(EXTRA_PROTECTION_STATUS, if (protectionError.isBlank()) "OK" else "ERROR")
        }
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun playStartSound() {
        try {
            val player = MediaPlayer.create(applicationContext, R.raw.trade_start_sound)
            if (player == null) {
                log("Start sound: failed to load trade_start_sound resource.")
                return
            }
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            player.setOnCompletionListener { mediaPlayer -> mediaPlayer.release() }
            player.setOnErrorListener { mp, _, _ -> mp.release(); true }
            player.start()
        } catch (e: Exception) {
            log("Start sound failed to play: ${e.message}")
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Trading Bot (Testnet)")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setOngoing(true)
            .build()
    }

    private fun notifyTradeOpened(price: Double, qty: Double) {
        val notification = NotificationCompat.Builder(this, TRADE_CHANNEL_ID)
            .setContentTitle("Trade opened")
            .setContentText("Bought ${formatQty(qty)} $symbol at $${"%,.2f".format(price)}")
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(TRADE_NOTIF_ID, notification)
    }

    private fun notifyManualTargetHit(entryPrice: Double, exitPrice: Double, qty: Double) {
        val notification = NotificationCompat.Builder(this, TRADE_CHANNEL_ID)
            .setContentTitle("Manual trade target hit")
            .setContentText("Take-profit reached — auto-exit closed ${formatQty(qty)} $symbol at $${"%,.2f".format(exitPrice)}")
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java)?.notify(TRADE_NOTIF_ID + 1, notification)
    }

    private fun notifyTradeClosed(entryPrice: Double, exitPrice: Double, qty: Double, netPnl: Double) {
        val profit = netPnl >= 0
        val pnlText = "${if (profit) "+" else "-"}$${"%.2f".format(kotlin.math.abs(netPnl))}"
        val notification = NotificationCompat.Builder(this, TRADE_CHANNEL_ID)
            .setContentTitle(if (profit) "Trade closed — profit" else "Trade closed — loss")
            .setContentText(
                "Sold ${formatQty(qty)} $symbol at $${"%,.2f".format(exitPrice)} " +
                    "(entry $${"%,.2f".format(entryPrice)}) · net $pnlText"
            )
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(TRADE_NOTIF_ID, notification)
    }

    private fun notifyDailyLossLimitHit() {
        val notification = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
            .setContentTitle("Trading bot stopped")
            .setContentText("Daily loss limit hit — trading stopped for safety.")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(ALERT_NOTIF_ID, notification)
    }

    private fun notifyRepeatedFailures(lastErrorMessage: String) {
        val notification = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
            .setContentTitle("Trading bot protection paused")
            .setContentText("5 update attempts failed in a row: $lastErrorMessage")
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "The bot has failed 5 times in a row and isn't updating. " +
                    "Last error: $lastErrorMessage. Check your API key/permissions and network connection."
            ))
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(ALERT_NOTIF_ID, notification)
    }

    /**
     * Single gate for every exchange order. It serializes BUY/SELL submissions,
     * persists an in-flight journal before the network call, and only clears the
     * journal after the exchange fill has been resolved. A process death in the
     * middle therefore fails closed on restart instead of risking a duplicate
     * order or silently losing risk accounting.
     */
    private fun submitAndResolveOrder(side: String, quantity: Double, fallbackPrice: Double): OrderFill {
        require(side == "BUY" || side == "SELL") { "Unsupported order side: $side" }
        require(quantity > 0.0) { "Order quantity must be positive" }
        val clientOrderId = "bot-${side.first()}-${System.currentTimeMillis()}-${UUID.randomUUID().toString().replace("-", "").take(8)}"
        orderExecutionLock.lock()
        try {
            val apiClient = requireNotNull(sharedClient) { "BinanceApiClient not initialized" }
            historyStore.savePendingOrder(PendingOrderSnapshot(symbol, side, quantity, clientOrderId, System.currentTimeMillis()))
            val order = apiClient.placeOrderIdempotent(symbol, side, formatQty(quantity), clientOrderId)
            val fill = apiClient.resolveFill(symbol, order, requestedQty = quantity, fallbackPrice = fallbackPrice)
            return fill
        } catch (e: Exception) {
            // Keep the journal on failure/unknown state. Startup will hard-lock
            // until exchange/local state has been explicitly reconciled.
            throw e
        } finally {
            orderExecutionLock.unlock()
        }
    }

    private fun notifyProtectionFailure(message: String) {
        val notification = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
            .setContentTitle("EXIT PROTECTION ERROR")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "$message New BUY entries are blocked while an open position remains under protection. Check the exchange state before retrying."
            ))
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java)?.notify(ALERT_NOTIF_ID + 2, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Trading Bot", NotificationManager.IMPORTANCE_LOW)
            )
            manager.createNotificationChannel(
                NotificationChannel(
                    ALERT_CHANNEL_ID, "Trading Bot Alerts", NotificationManager.IMPORTANCE_HIGH
                )
            )
            manager.createNotificationChannel(
                NotificationChannel(
                    TRADE_CHANNEL_ID, "Trade Events", NotificationManager.IMPORTANCE_DEFAULT
                )
            )
        }
    }
}
