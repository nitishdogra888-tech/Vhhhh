package com.example.tradingbot

import android.content.Context
import org.json.JSONObject

/** Small persistent checkpoint journal for AI research only; never an order journal. */
class AiAnalysisCheckpointStore(context: Context) {
    private val prefs = context.getSharedPreferences("ai_research_checkpoint", Context.MODE_PRIVATE)
    fun begin(id: String, snapshot: MarketSnapshot) {
        val existing = read(id)
        if (existing != null && existing.optString("hash") == snapshot.snapshotHash &&
            existing.optLong("candleCloseTimeMs", -1L) == snapshot.candleCloseTimeMs) return
        prefs.edit().putString(id, JSONObject().apply {
            put("symbol", snapshot.symbol); put("candleCloseTimeMs", snapshot.candleCloseTimeMs); put("hash", snapshot.snapshotHash); put("stage", "STARTED")
        }.toString()).apply()
    }
    fun put(id: String, stage: String, value: String) {
        val root = read(id) ?: JSONObject()
        root.put("stage", stage).put(stage, value)
        prefs.edit().putString(id, root.toString()).apply()
    }
    fun get(id: String, stage: String): String? = read(id)?.optString(stage)?.takeIf { it.isNotBlank() }
    fun complete(id: String) { prefs.edit().remove(id).apply() }
    private fun read(id: String): JSONObject? = prefs.getString(id, null)?.let { runCatching { JSONObject(it) }.getOrNull() }
}
