package com.example.tradingbot

/**
 * One tradable market on Binance: a base asset quoted in USDT.
 *
 * `testnetAvailable = false` markets (currently the bStocks tokenized-equity
 * pairs) do not exist on testnet.binance.vision. The bot can still chart and
 * analyze them using Binance's public mainnet market data (no API key
 * required for that), but AUTO/MANUAL order placement for them requires the
 * app to be in LIVE trading mode with real funds -- see TradingMode.
 */
data class Market(
    val baseAsset: String,        // e.g. "BTC", "NVDAB"
    val quoteAsset: String = "USDT",
    val displayName: String,      // e.g. "Bitcoin", "NVIDIA"
    val kind: MarketKind,
    val testnetAvailable: Boolean,
    val accentColor: String       // hex, used for the icon badge in the picker
) {
    val symbol: String get() = "$baseAsset$quoteAsset"
    val pairLabel: String get() = "$baseAsset/$quoteAsset"
}

enum class MarketKind { CRYPTO, TOKENIZED_STOCK }

object Markets {

    val ALL: List<Market> = listOf(
        Market("BTC", displayName = "Bitcoin", kind = MarketKind.CRYPTO, testnetAvailable = true, accentColor = "#F7931A"),
        Market("ETH", displayName = "Ethereum", kind = MarketKind.CRYPTO, testnetAvailable = true, accentColor = "#627EEA"),
        Market("BNB", displayName = "BNB", kind = MarketKind.CRYPTO, testnetAvailable = true, accentColor = "#F3BA2F"),
        Market("SPCXB", displayName = "SpaceX (bStock)", kind = MarketKind.TOKENIZED_STOCK, testnetAvailable = false, accentColor = "#1B1B1B"),
        Market("NVDAB", displayName = "NVIDIA (bStock)", kind = MarketKind.TOKENIZED_STOCK, testnetAvailable = false, accentColor = "#76B900"),
        Market("TSLAB", displayName = "Tesla (bStock)", kind = MarketKind.TOKENIZED_STOCK, testnetAvailable = false, accentColor = "#E31937"),
        Market("CRCLB", displayName = "Circle (bStock)", kind = MarketKind.TOKENIZED_STOCK, testnetAvailable = false, accentColor = "#7C5CFC"),
        Market("MUB", displayName = "Micron (bStock)", kind = MarketKind.TOKENIZED_STOCK, testnetAvailable = false, accentColor = "#0071C5"),
        Market("SNDKB", displayName = "Sandisk (bStock)", kind = MarketKind.TOKENIZED_STOCK, testnetAvailable = false, accentColor = "#E4002B")
    )

    fun bySymbol(symbol: String): Market? = ALL.firstOrNull { it.symbol == symbol }

    val default: Market get() = ALL.first { it.baseAsset == "BTC" }
}

/**
 * Testnet-vs-live trading mode. This is separate from which market is
 * selected: it controls which Binance API base URL and which stored
 * credentials the bot trades with. Tokenized stocks (bStocks) only exist in
 * LIVE, so selecting one of them while in TESTNET disables order placement
 * (chart/analysis still works).
 */
enum class TradingMode { TESTNET, LIVE }
