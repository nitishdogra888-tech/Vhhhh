package com.example.tradingbot

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Small self-contained price path chart used for each completed trade. */
class TradeChartView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 4f; style = Paint.Style.STROKE }
    private val entryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val exitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 1f; style = Paint.Style.STROKE }
    private var values: List<Double> = emptyList()
    private var profitable = false

    fun setValues(newValues: List<Double>, isProfit: Boolean) {
        values = newValues.filter { value -> value.isFinite() }
        profitable = isProfit
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (values.size < 2) return
        val left = paddingLeft.toFloat() + 8f
        val right = width - paddingRight.toFloat() - 8f
        val top = paddingTop.toFloat() + 8f
        val bottom = height - paddingBottom.toFloat() - 8f
        val minV = values.minOrNull() ?: return
        val maxV = values.maxOrNull() ?: return
        val range = max(1e-9, maxV - minV)

        gridPaint.color = 0x334A4A55
        canvas.drawLine(left, bottom, right, bottom, gridPaint)
        canvas.drawLine(left, top, right, top, gridPaint)

        linePaint.color = if (profitable) 0xFF21D19B.toInt() else 0xFFFF6B57.toInt()
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = if (values.size == 1) left else left + (right - left) * i / (values.size - 1)
            val y = bottom - ((v - minV) / range).toFloat() * (bottom - top)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, linePaint)

        val entryY = bottom - ((values.first() - minV) / range).toFloat() * (bottom - top)
        val exitY = bottom - ((values.last() - minV) / range).toFloat() * (bottom - top)
        entryPaint.color = 0xFF7C6CFF.toInt()
        exitPaint.color = linePaint.color
        canvas.drawCircle(left, entryY, 6f, entryPaint)
        canvas.drawCircle(right, exitY, 6f, exitPaint)
    }
}
