package com.example.tradingbot

import android.content.Context

/**
 * Plain (non-encrypted) app preferences: which market is currently selected
 * and whether the bot is in TESTNET or LIVE mode. Unlike SecureStorage, none
 * of this is a secret -- it's UI/session state, not API credentials.
 */
object AppPreferences {

    private const val PREFS_NAME = "trading_bot_prefs"
    private const val KEY_SYMBOL = "selected_symbol"
    private const val KEY_MODE = "trading_mode"

    fun getSelectedMarket(context: Context): Market {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val symbol = prefs.getString(KEY_SYMBOL, null) ?: return Markets.default
        return Markets.bySymbol(symbol) ?: Markets.default
    }

    fun setSelectedMarket(context: Context, market: Market) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SYMBOL, market.symbol)
            .apply()
    }

    fun getTradingMode(context: Context): TradingMode {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_MODE, TradingMode.TESTNET.name)
        return try {
            TradingMode.valueOf(raw ?: TradingMode.TESTNET.name)
        } catch (e: IllegalArgumentException) {
            TradingMode.TESTNET
        }
    }

    fun setTradingMode(context: Context, mode: TradingMode) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_MODE, mode.name)
            .apply()
    }

    /** Can this market actually be traded (order placement) in the current mode? */
    fun canTrade(context: Context, market: Market): Boolean {
        return when (getTradingMode(context)) {
            TradingMode.LIVE -> true
            TradingMode.TESTNET -> market.testnetAvailable
        }
    }
}
