package com.example.tradingbot

import com.example.tradingbot.scanner.TechnicalIndicators
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TechnicalIndicatorsTest {
    @Test fun smaUsesRollingWindow() {
        val r = TechnicalIndicators.sma(listOf(1.0, 2.0, 3.0, 4.0, 5.0), 3)
        assertEquals(2.0, r[2]!!, 1e-9)
        assertEquals(4.0, r[4]!!, 1e-9)
    }

    @Test fun emaStartsAtSeedAverage() {
        val r = TechnicalIndicators.ema(listOf(1.0, 2.0, 3.0, 4.0), 3)
        assertEquals(2.0, r[2]!!, 1e-9)
        assertTrue(r[3]!! > 2.0)
    }

    @Test fun crossoverDetectsGoldenAndDeath() {
        assertEquals(TechnicalIndicators.Crossover.GOLDEN,
            TechnicalIndicators.detectCrossover(listOf(1.0, 3.0), listOf(2.0, 2.5)))
        assertEquals(TechnicalIndicators.Crossover.DEATH,
            TechnicalIndicators.detectCrossover(listOf(3.0, 1.0), listOf(2.0, 2.5)))
    }
}
