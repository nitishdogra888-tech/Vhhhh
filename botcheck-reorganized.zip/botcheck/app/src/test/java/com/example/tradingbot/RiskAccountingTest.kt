package com.example.tradingbot

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RiskAccountingTest {
    @Test fun dailyBudgetIsConsumedByEntryNotionalAndDoesNotRefillOnProfit() {
        val risk = RiskManager(dailyTradingBudgetUsd = 10.0)
        risk.updateBalance(100.0, 100.0)
        risk.recordEntryNotional(6.0)
        assertEquals(4.0, risk.remainingBudget(), 1e-9)
        risk.recordTradeResult(2.0)
        assertEquals(4.0, risk.remainingBudget(), 1e-9)
        assertEquals(6.0, risk.dailyNotionalUsed(), 1e-9)
    }

    @Test fun sessionBudgetIsConsumedByEntryNotionalAndSurvivesRestore() {
        val session = SessionRiskManager(windowMs = 7_200_000L, sessionBudgetUsd = 10.0)
        session.recordEntryNotional(7.0, 1_000L)
        assertEquals(3.0, session.capTradeValueUsd(9.0, 1_001L), 1e-9)
        val snapshot = session.snapshot(1_002L)
        val restored = SessionRiskManager(windowMs = 7_200_000L, sessionBudgetUsd = 10.0)
        restored.restore(snapshot, 1_003L)
        assertEquals(3.0, restored.capTradeValueUsd(9.0, 1_004L), 1e-9)
    }

    @Test fun sessionProfitTargetLatchesEntryLock() {
        val session = SessionRiskManager(sessionBudgetUsd = 10.0, sessionProfitTargetUsd = 1.0)
        session.recordTradeResult(1.01, 1_000L)
        val reason = session.entryBlockReason(1_001L)
        assertNotNull(reason)
        assertTrue(reason!!.contains("target hit", ignoreCase = true))
    }
}
