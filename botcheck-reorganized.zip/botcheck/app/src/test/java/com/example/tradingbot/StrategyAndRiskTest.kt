package com.example.tradingbot

import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StrategyAndRiskTest {
    private fun klines(count: Int = 120, start: Double = 100.0, step: Double = 0.2): JSONArray {
        val a = JSONArray()
        for (i in 0 until count) {
            val open = start + i * step
            val close = open + step
            val high = close + 0.3
            val low = open - 0.3
            // Binance's real kline API returns every OHLCV field as a JSON string
            // (not a number), and the production code reads them with getString(...).
            // Match that shape here, or getString() throws JSONException on a raw Double.
            a.put(
                JSONArray()
                    .put(i * 60_000L)
                    .put(open.toString())
                    .put(high.toString())
                    .put(low.toString())
                    .put(close.toString())
                    .put("1000.0")
            )
        }
        return a
    }

    @Test fun confluenceUsesClosedCandleAndReturnsStructuredQuality() {
        val decision = IndicatorConfluenceStrategy().evaluate(klines())
        assertTrue(decision.signalQuality in 0..100)
        assertTrue(decision.reason.isNotBlank())
    }

    @Test fun confluenceHoldsWithInsufficientHistory() {
        val decision = IndicatorConfluenceStrategy().evaluate(klines(20))
        assertEquals(Signal.HOLD, decision.signal)
    }

    @Test fun riskBlocksAfterConsecutiveLossLimit() {
        val risk = RiskManager(dailyTradingBudgetUsd = 10.0, maxDailyLossPercent = 0.50, maxConsecutiveLosses = 2, maxTradesPerDay = 8)
        risk.updateBalance(100.0, 100.0)
        risk.recordTradeResult(-0.10)
        risk.recordTradeResult(-0.10)
        assertTrue(risk.newEntryBlockReason(System.currentTimeMillis(), 0L)?.contains("consecutive", ignoreCase = true) == true)
    }

    @Test fun sellNowPreviewUsesTheSameCostFormulaWithoutChangingStats() {
        val preview = CostModel.previewSellNow(entryPrice = 100.0, currentPrice = 110.0, quantity = 2.0)
        assertEquals(20.0, preview.grossPnl, 0.000001)
        assertEquals(0.42, preview.exchangeFees, 0.000001)
        assertEquals(2.2, preview.tds, 0.000001)
        assertEquals(6.0, preview.taxOnGain, 0.000001)
        assertEquals(11.38, preview.netPnl, 0.000001)
        assertEquals(0, TradeStats().totalTrades)
    }
}
