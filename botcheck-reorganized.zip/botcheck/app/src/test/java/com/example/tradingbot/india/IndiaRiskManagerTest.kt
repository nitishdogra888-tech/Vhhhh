package com.example.tradingbot.india

import java.time.ZoneId
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun istMs(y: Int, mo: Int, d: Int, h: Int, min: Int): Long =
    ZonedDateTime.of(y, mo, d, h, min, 0, 0, ZoneId.of("Asia/Kolkata")).toInstant().toEpochMilli()

class IndiaMarketCalendarTest {

    @Test fun openDuringRegularWeekdaySession() {
        // Wednesday 2026-09-16, 11:00 IST -- well inside the 09:15-15:30 window.
        val t = istMs(2026, 9, 16, 11, 0)
        assertTrue(IndiaMarketCalendar.isMarketOpen(t))
        assertNull(IndiaMarketCalendar.marketClosedReason(t))
    }

    @Test fun closedBeforeOpenAndAfterCloseOnAWeekday() {
        val beforeOpen = istMs(2026, 9, 16, 9, 0)
        val afterClose = istMs(2026, 9, 16, 15, 45)
        assertFalse(IndiaMarketCalendar.isMarketOpen(beforeOpen))
        assertFalse(IndiaMarketCalendar.isMarketOpen(afterClose))
        assertNotNull(IndiaMarketCalendar.marketClosedReason(beforeOpen))
        assertNotNull(IndiaMarketCalendar.marketClosedReason(afterClose))
    }

    @Test fun closedOnWeekend() {
        // 2026-09-19 is a Saturday.
        val saturday = istMs(2026, 9, 19, 11, 0)
        assertFalse(IndiaMarketCalendar.isMarketOpen(saturday))
        assertTrue(IndiaMarketCalendar.marketClosedReason(saturday)?.contains("weekend", ignoreCase = true) == true)
    }

    @Test fun intradaySquareOffCutoffBlocksNewEntriesButPriorTimeDoesNot() {
        val beforeCutoff = istMs(2026, 9, 16, 14, 0)
        val afterCutoff = istMs(2026, 9, 16, 15, 20)
        assertFalse(IndiaMarketCalendar.isPastIntradayEntryCutoff(beforeCutoff))
        assertTrue(IndiaMarketCalendar.isPastIntradayEntryCutoff(afterCutoff))
    }

    @Test fun tradingDayKeyIsPinnedToIstRegardlessOfWallClockAmbiguity() {
        // 18:30 UTC on 2026-09-16 is already past midnight (00:00 next day) in IST.
        val lateUtcMs = ZonedDateTime.of(2026, 9, 16, 18, 30, 0, 0, ZoneId.of("UTC")).toInstant().toEpochMilli()
        assertEquals("2026-09-17", IndiaMarketCalendar.tradingDayKey(lateUtcMs))
    }
}

class IndiaRiskManagerTest {

    @Test fun blocksNewEntriesWhenMarketIsClosed() {
        val risk = IndiaRiskManager()
        val weekend = istMs(2026, 9, 19, 11, 0)
        val reason = risk.newEntryBlockReason(weekend, entryCooldownMs = 0L, productType = ProductType.DELIVERY)
        assertTrue(reason?.contains("closed", ignoreCase = true) == true || reason?.contains("weekend", ignoreCase = true) == true)
    }

    @Test fun blocksFreshIntradayEntriesPastSquareOffCutoffEvenIfDeliveryWouldBeFine() {
        val risk = IndiaRiskManager()
        val lateInSession = istMs(2026, 9, 16, 15, 25) // market still open, but past 15:15 cutoff
        assertNotNull(risk.newEntryBlockReason(lateInSession, 0L, ProductType.INTRADAY))
        assertNull(risk.newEntryBlockReason(lateInSession, 0L, ProductType.DELIVERY))
    }

    @Test fun blocksAfterConsecutiveLossLimit() {
        val risk = IndiaRiskManager(dailyTradingBudgetInr = 1000.0, maxDailyLossPercent = 0.50, maxConsecutiveLosses = 2, maxTradesPerDay = 8)
        risk.updateBalance(10_000.0, 10_000.0)
        risk.recordTradeResult(-100.0)
        risk.recordTradeResult(-100.0)
        val mid = istMs(2026, 9, 16, 11, 0)
        assertTrue(risk.newEntryBlockReason(mid, 0L, ProductType.DELIVERY)?.contains("consecutive", ignoreCase = true) == true)
    }

    @Test fun tradeQuantityIsWholeSharesFlooredToBudget() {
        val risk = IndiaRiskManager(dailyTradingBudgetInr = 1000.0)
        risk.updateBalance(10_000.0, 10_000.0)
        // ₹1000 budget / ₹333 per share = 3.003... shares -> must floor to 3, never round up to 4.
        assertEquals(3, risk.tradeQuantity(333.0))
    }

    @Test fun dailyLossLockPersistsAcrossSameIstDayButResetsOnNewIstDay() {
        val risk = IndiaRiskManager(dailyTradingBudgetInr = 1000.0, maxDailyLossPercent = 0.05)
        risk.updateBalance(10_000.0, 10_000.0)
        risk.recordTradeResult(-600.0) // 6% drawdown, past the 5% daily loss limit
        risk.updateBalance(9_400.0, 9_400.0) // reflects the loss, the way TradingService's poll loop would
        assertTrue(risk.isDailyStopLocked())

        val snap = risk.snapshot(tradingDay = "2026-09-16")
        val fresh = IndiaRiskManager(dailyTradingBudgetInr = 1000.0, maxDailyLossPercent = 0.05)
        fresh.restore(snap, today = "2026-09-16", equity = 9_400.0, freeCash = 9_400.0)
        assertTrue(fresh.isDailyStopLocked())

        fresh.restore(snap, today = "2026-09-17", equity = 9_400.0, freeCash = 9_400.0)
        assertFalse(fresh.isDailyStopLocked())
    }
}

class IndiaPositionTrackerTest {

    @Test fun stopLossAndTakeProfitFireAtConfiguredLevels() {
        val tracker = IndiaPositionTracker()
        tracker.open("RELIANCE-EQ", price = 2800.0, qty = 10, productType = ProductType.DELIVERY, stopLossPercent = 0.01, takeProfitPercent = 0.02)
        assertEquals(IndiaExitReason.NONE, tracker.checkExit(2800.0))
        assertEquals(IndiaExitReason.STOP_LOSS, tracker.checkExit(2770.0))
    }

    @Test fun intradayPositionIsForcedFlatAtSquareOffDeadlineEvenIfProfitable() {
        val tracker = IndiaPositionTracker()
        val entryTime = istMs(2026, 9, 16, 10, 0)
        tracker.open("RELIANCE-EQ", price = 2800.0, qty = 10, productType = ProductType.INTRADAY, nowMs = entryTime)
        val pastCutoff = istMs(2026, 9, 16, 15, 20)
        // Price is up vs entry (would otherwise just be "holding"), but the session
        // cutoff must still force an exit -- this has no crypto-side equivalent.
        assertEquals(IndiaExitReason.SQUARE_OFF_DEADLINE, tracker.checkExit(2810.0, nowMs = pastCutoff))
    }

    @Test fun deliveryPositionIsNotForcedFlatBySquareOffCutoff() {
        val tracker = IndiaPositionTracker()
        tracker.open("RELIANCE-EQ", price = 2800.0, qty = 10, productType = ProductType.DELIVERY)
        val pastCutoff = istMs(2026, 9, 16, 15, 20)
        assertEquals(IndiaExitReason.NONE, tracker.checkExit(2800.0, nowMs = pastCutoff))
    }
}
