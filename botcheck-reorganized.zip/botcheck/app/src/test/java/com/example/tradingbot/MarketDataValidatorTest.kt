package com.example.tradingbot

import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MarketDataValidatorTest {
    private fun klines(count: Int = 220, futureLast: Boolean = false): JSONArray {
        val out = JSONArray()
        val base = 1_700_000_000_000L
        for (i in 0 until count) {
            val openTime = base + i * 60_000L
            val closeTime = openTime + 59_999L
            val close = 100.0 + i * 0.1
            out.put(JSONArray().apply {
                put(openTime); put(close); put(close + 1); put(close - 1); put(close); put(1000.0); put(if (futureLast && i == count - 1) System.currentTimeMillis() + 3_600_000 else closeTime)
            })
        }
        return out
    }

    @Test fun rejectsTooLittleHistory() {
        val result = MarketDataValidator.buildClosedSnapshot("BTCUSDT", klines(50), 1_800_000_000_000L)
        assertTrue(result.snapshot == null)
        assertTrue(result.errors.any { it.contains("Not enough") })
    }

    @Test fun excludesFutureIncompleteCandle() {
        val asOf = 1_700_000_000_000L + 219 * 60_000L + 30_000L
        val result = MarketDataValidator.buildClosedSnapshot("BTCUSDT", klines(220, futureLast = true), asOf)
        assertTrue(result.snapshot == null || result.snapshot.candleCloseTimeMs <= asOf)
    }

    @Test fun validSnapshotHasStableHashForSameClosedCandle() {
        val data = klines()
        val a = MarketDataValidator.buildClosedSnapshot("BTCUSDT", data, 1_800_000_000_000L).snapshot
        val b = MarketDataValidator.buildClosedSnapshot("BTCUSDT", data, 1_800_000_000_500L).snapshot
        assertTrue(a != null && b != null)
        assertEquals(a!!.snapshotHash, b!!.snapshotHash)
        assertEquals(a.candleCloseTimeMs, b.candleCloseTimeMs)
    }
}
