package com.example.tradingbot

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class ExecutionGuardsTest {
    @Test
    fun gate_allows_only_one_concurrent_owner() {
        val gate = AtomicExecutionGate()
        val pool = Executors.newFixedThreadPool(16)
        val start = CountDownLatch(1)
        val done = CountDownLatch(16)
        val acquired = AtomicInteger(0)
        repeat(16) {
            pool.execute {
                start.await()
                if (gate.tryAcquire()) acquired.incrementAndGet()
                done.countDown()
            }
        }
        start.countDown()
        done.await()
        assertTrue(acquired.get() <= 1)
        assertTrue(gate.isHeld())
        gate.release()
        assertFalse(gate.isHeld())
        pool.shutdownNow()
    }
}
