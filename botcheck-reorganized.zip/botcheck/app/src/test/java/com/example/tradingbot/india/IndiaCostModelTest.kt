package com.example.tradingbot.india

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IndiaCostModelTest {

    @Test fun intradayTradeCostMatchesHandComputedBreakdown() {
        val cost = IndiaCostModel.tradeCost(entryPrice = 100.0, exitPrice = 110.0, quantity = 10, productType = ProductType.INTRADAY)
        assertEquals(100.0, cost.grossPnl, 0.0001)
        assertEquals(10.0, cost.brokerage, 0.0001)          // min(20, 0.1%) floored to ₹5/side = ₹10 total
        assertEquals(0.275, cost.sttTax, 0.0001)             // 0.025% on sell leg only (₹1100)
        assertEquals(0.0644679, cost.exchangeCharges, 0.0001)
        assertEquals(0.0021, cost.sebiCharges, 0.0001)
        assertEquals(0.15, cost.stampDuty, 0.0001)           // 0.015% on buy leg only (₹1000)
        assertEquals(0.0, cost.dpCharges, 0.0001)            // no DP charge for intraday -- never enters demat
        assertEquals(1.811982, cost.gst, 0.001)
        assertEquals(26.308935, cost.taxEstimate, 0.001)     // 30% speculative-income assumption on net-before-tax
        assertEquals(61.387515, cost.netPnl, 0.001)
    }

    @Test fun deliveryTradeCostHasStampDutyBothLegsStttAndDpCharge() {
        val cost = IndiaCostModel.tradeCost(entryPrice = 100.0, exitPrice = 110.0, quantity = 10, productType = ProductType.DELIVERY)
        assertEquals(100.0, cost.grossPnl, 0.0001)
        assertEquals(2.1, cost.sttTax, 0.0001)                // 0.1% on BOTH legs (₹1000 + ₹1100)
        assertEquals(23.6, cost.dpCharges, 0.0001)            // flat ₹20 + 18% GST, delivery sell only
        assertEquals(12.454290, cost.taxEstimate, 0.001)      // flat 20% STCG assumption, not slab rate
        assertEquals(49.817160, cost.netPnl, 0.001)
        // Delivery has strictly more charges than intraday on an identical trade (STT both legs + DP charge).
        val intraday = IndiaCostModel.tradeCost(100.0, 110.0, 10, ProductType.INTRADAY)
        assertTrue(cost.totalCharges > intraday.totalCharges)
    }

    @Test fun noCryptoStyleTdsIsCharged() {
        // Crypto's CostModel charges 1% TDS on every sell leg. Equities have no such
        // per-trade TDS -- IndiaTradeCost simply has no field for it, and STT (the
        // actual equity charge) is far smaller than 1% of sell value in either mode.
        val cost = IndiaCostModel.tradeCost(100.0, 110.0, 10, ProductType.DELIVERY)
        assertTrue(cost.sttTax < 0.01 * 110.0 * 10)
    }

    @Test fun breakEvenGrowsWithProductCostAndShrinksAsBrokerageCapDominates() {
        val intradaySmall = IndiaCostModel.breakEvenMoveFraction(tradeValueRs = 50_000.0, productType = ProductType.INTRADAY)
        val deliverySmall = IndiaCostModel.breakEvenMoveFraction(tradeValueRs = 50_000.0, productType = ProductType.DELIVERY)
        // Delivery carries STT on both legs + a DP charge intraday never pays, so its
        // break-even move is always larger than intraday's for the same notional.
        assertTrue(deliverySmall > intradaySmall)

        // Once notional is well past the point brokerage saturates at its ₹20 cap,
        // brokerage stops scaling with size while the trade's gross P/L keeps scaling
        // with it -- so break-even % should shrink as notional grows.
        val intradayLarge = IndiaCostModel.breakEvenMoveFraction(tradeValueRs = 100_000.0, productType = ProductType.INTRADAY)
        assertTrue(intradayLarge < intradaySmall)
    }

    @Test fun previewSellNowMatchesTradeCostAndNeverMutatesState() {
        val preview = IndiaCostModel.previewSellNow(entryPrice = 100.0, currentPrice = 110.0, quantity = 10, productType = ProductType.INTRADAY)
        val direct = IndiaCostModel.tradeCost(100.0, 110.0, 10, ProductType.INTRADAY)
        assertEquals(direct.netPnl, preview.netPnl, 0.0001)
        assertEquals(0, IndiaTradeStats().totalTrades)
    }

    @Test fun brokerageIsFlooredAtFiveRupeesForSmallOrdersAndCappedAtTwentyForLargeOnes() {
        assertEquals(5.0, IndiaCostModel.brokerage(1000.0), 0.0001)   // 0.1% of ₹1000 = ₹1, floored to ₹5
        assertEquals(20.0, IndiaCostModel.brokerage(50_000.0), 0.0001) // 0.1% of ₹50,000 = ₹50, capped to ₹20
        assertEquals(15.0, IndiaCostModel.brokerage(15_000.0), 0.0001) // 0.1% of ₹15,000 = ₹15, between floor/cap
    }
}
