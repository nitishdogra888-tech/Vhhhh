# Keep rules for release minification.
#
# okhttp, org.json, and kotlinx-coroutines ship their own consumer rules
# bundled in their AARs, so they generally don't need manual keeps here.
# androidx.security (Tink under the hood) uses reflection to look up key
# managers/primitives, which R8 can't see statically — without these keeps,
# EncryptedSharedPreferences can crash at runtime *only* in a minified
# build, which is easy to miss if you only ever test the debug build.
-keep class com.google.crypto.tink.** { *; }
-keep interface com.google.crypto.tink.** { *; }
-dontwarn com.google.crypto.tink.**

# Keep our own data/model classes' field names — nothing here is
# serialized via reflection (org.json is used directly, not annotation
# based), so this mainly guards against future additions that might rely
# on reflection without remembering to update this file.
-keep class com.example.tradingbot.scanner.ScanResult { *; }
-keep class com.example.tradingbot.scanner.Bar { *; }
-keep class com.example.tradingbot.SymbolRules { *; }

# Standard Kotlin metadata keep, so reflection-based Kotlin features
# (data class copy/componentN, coroutines) keep working correctly.
-keepattributes *Annotation*, InnerClasses, Signature, Exceptions
-keep class kotlin.Metadata { *; }
