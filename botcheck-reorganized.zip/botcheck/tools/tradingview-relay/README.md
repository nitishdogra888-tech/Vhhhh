# TradingView → VPS relay

This relay only receives TradingView alerts and stores the latest signal per symbol. It never places an order.

## Run

```bash
docker compose up -d --build
```

Change `WEBHOOK_TOKEN` before exposing it to the internet. Put the relay behind HTTPS (for example, an Nginx/Caddy reverse proxy) rather than exposing plain HTTP directly.

## TradingView alert

Use a strategy/indicator alert configured for **Any alert() function call** and send JSON like:

```json
{"symbol":"BTCUSDT","action":"BUY","price":{{close}},"timeMs":{{timenow}}}
```

For a SELL signal, change `action` to `SELL`. The Android app polls `/signal/latest?symbol=BTCUSDT` with the same token.
