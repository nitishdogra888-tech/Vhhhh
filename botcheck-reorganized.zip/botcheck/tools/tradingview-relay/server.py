#!/usr/bin/env python3
"""Tiny dependency-free TradingView webhook relay.

POST /webhook with X-Webhook-Token and JSON:
{"symbol":"BTCUSDT","action":"BUY","price":100000,"timeMs":123}
GET /signal/latest?symbol=BTCUSDT with the same token.

It stores only the latest signal per symbol in signals.json. It does not place
orders and should sit behind HTTPS/reverse proxy on a VPS for internet use.
"""
import json, os, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8080"))
TOKEN = os.getenv("WEBHOOK_TOKEN", "")
FILE = os.getenv("SIGNALS_FILE", "signals.json")
LOCK = threading.Lock()


def load():
    try:
        with open(FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

SIGNALS = load()


def save():
    tmp = FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(SIGNALS, f)
    os.replace(tmp, FILE)


class Handler(BaseHTTPRequestHandler):
    server_version = "TradingViewRelay/1.0"

    def send_json(self, code, obj):
        raw = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def authorized(self):
        return bool(TOKEN) and self.headers.get("X-Webhook-Token", "") == TOKEN

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/health":
            self.send_json(200, {"ok": True})
            return
        if parsed.path != "/signal/latest" or not self.authorized():
            self.send_json(401, {"ok": False, "error": "unauthorized"})
            return
        symbol = parse_qs(parsed.query).get("symbol", [""])[0].upper()
        with LOCK:
            value = SIGNALS.get(symbol)
        self.send_json(200, {"found": value is not None, **(value or {})})

    def do_POST(self):
        if urlparse(self.path).path != "/webhook" or not self.authorized():
            self.send_json(401, {"ok": False, "error": "unauthorized"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length > 16384:
                raise ValueError("payload too large")
            data = json.loads(self.rfile.read(length).decode("utf-8"))
            symbol = str(data.get("symbol", "")).upper().strip()
            action = str(data.get("action", "")).upper().strip()
            price = float(data.get("price", 0))
            time_ms = int(data.get("timeMs", 0))
            if not symbol or action not in {"BUY", "SELL", "HOLD"} or price <= 0 or time_ms <= 0:
                raise ValueError("invalid signal")
            value = {"symbol": symbol, "action": action, "price": price, "timeMs": time_ms}
            with LOCK:
                SIGNALS[symbol] = value
                save()
            self.send_json(200, {"ok": True, **value})
        except Exception as exc:
            self.send_json(400, {"ok": False, "error": str(exc)})

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("WEBHOOK_TOKEN must be set")
    print(f"TradingView relay listening on {HOST}:{PORT}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
