/**
 * Standalone backtest for the SMA-crossover + momentum + regime-filter
 * strategy used in TradingService.kt / Strategy.kt.
 *
 * Matches SAFETY-FIXED live logic:
 *  - closed candles only
 *  - fresh momentum (threshold cross, not while remaining true)
 *  - cost-aware trailing (won't exit below modeled break-even)
 *  - 15-candle entry cooldown after an exit
 *  - intrabar high/low for stop-loss (if high/low columns exist)
 *
 * Data: https://data.binance.vision/?prefix=data/spot/monthly/klines/BTCUSDT/1m/
 *
 *   kotlinc Backtest.kt -include-runtime -d backtest.jar
 *   java -jar backtest.jar BTCUSDT-1m-2024-01.csv
 */

import java.io.File
import java.time.LocalDate
import java.time.ZoneOffset

const val SHORT_PERIOD = 5
const val LONG_PERIOD = 20
const val RSI_PERIOD = 14
const val MOMENTUM_LOOKBACK = 5
const val MOMENTUM_THRESHOLD_PERCENT = 2.0
const val REGIME_PERIOD = 100

const val STOP_LOSS_PERCENT = 0.012
const val TRAILING_ACTIVATION_PERCENT = 0.026
const val TRAILING_GIVEBACK_PERCENT = 0.008
const val MIN_HOLD_CANDLES = 5
const val ENTRY_COOLDOWN_CANDLES = 15

const val FEE_RATE_PER_SIDE = 0.001
const val TDS_RATE_ON_SELL = 0.01
const val FLAT_TAX_RATE_ON_GAINS = 0.30
const val ASSUMED_SLIPPAGE_PERCENT_PER_SIDE = 0.02

enum class Signal { BUY, SELL, HOLD }
enum class ExitReason { STOP_LOSS, TRAILING_STOP, REVERSAL_SIGNAL, NONE }

data class Trade(
    val entryTime: Long,
    val exitTime: Long,
    val entryPrice: Double,
    val exitPrice: Double,
    val netPnl: Double,
    val grossPnlPercent: Double,
    val reason: String
)

fun wilderRsi(closes: List<Double>, period: Int): Double {
    if (closes.size < period + 1) return 50.0
    var avgGain = 0.0
    var avgLoss = 0.0
    for (i in 1..period) {
        val change = closes[i] - closes[i - 1]
        if (change > 0) avgGain += change else avgLoss += -change
    }
    avgGain /= period
    avgLoss /= period
    for (i in (period + 1) until closes.size) {
        val change = closes[i] - closes[i - 1]
        val gain = if (change > 0) change else 0.0
        val loss = if (change < 0) -change else 0.0
        avgGain = (avgGain * (period - 1) + gain) / period
        avgLoss = (avgLoss * (period - 1) + loss) / period
    }
    if (avgLoss == 0.0) return 100.0
    val rs = avgGain / avgLoss
    return 100.0 - (100.0 / (1.0 + rs))
}

fun breakEvenMoveFraction(): Double {
    var lo = 0.0
    var hi = 0.2
    repeat(40) {
        val mid = (lo + hi) / 2.0
        val s = ASSUMED_SLIPPAGE_PERCENT_PER_SIDE / 100.0
        val entry = 1.0 * (1.0 + s)
        val exit = (1.0 + mid) * (1.0 - s)
        val qty = 1.0 / entry
        val gross = (exit - entry) * qty
        val fees = (entry * qty + exit * qty) * FEE_RATE_PER_SIDE
        val tds = exit * qty * TDS_RATE_ON_SELL
        val tax = if (gross > 0) gross * FLAT_TAX_RATE_ON_GAINS else 0.0
        val net = gross - fees - tds - tax
        if (net >= 0.0) hi = mid else lo = mid
    }
    return hi
}

fun evaluate(
    closes: List<Double>,
    i: Int,
    lastShortAboveLong: Boolean?,
    momentumWasTrue: Boolean
): Triple<Signal, Boolean, Boolean> {
    val window = closes.subList(0, i + 1)
    if (window.size < maxOf(LONG_PERIOD, REGIME_PERIOD) + 1) {
        return Triple(Signal.HOLD, lastShortAboveLong ?: false, momentumWasTrue)
    }

    val shortSma = window.takeLast(SHORT_PERIOD).average()
    val longSma = window.takeLast(LONG_PERIOD).average()
    val shortAboveLong = shortSma > longSma
    val rsi = wilderRsi(window, RSI_PERIOD)

    val crossedUp = lastShortAboveLong == false && shortAboveLong
    val crossedDown = lastShortAboveLong == true && !shortAboveLong

    val risePercent = if (window.size > MOMENTUM_LOOKBACK) {
        val past = window[window.size - 1 - MOMENTUM_LOOKBACK]
        val now = window.last()
        (now - past) / past * 100.0
    } else 0.0
    val momentumNow = risePercent >= MOMENTUM_THRESHOLD_PERCENT && rsi < 75.0
    val momentumBuy = momentumNow && !momentumWasTrue

    val regimeSma = if (REGIME_PERIOD > 0 && window.size >= REGIME_PERIOD) window.takeLast(REGIME_PERIOD).average() else null
    val regimeUptrend = regimeSma == null || window.last() >= regimeSma
    val regimeDowntrend = regimeSma == null || window.last() <= regimeSma

    val signal = when {
        crossedUp && rsi < 70.0 && regimeUptrend -> Signal.BUY
        momentumBuy && regimeUptrend -> Signal.BUY
        crossedDown && rsi > 30.0 && regimeDowntrend -> Signal.SELL
        else -> Signal.HOLD
    }
    return Triple(signal, shortAboveLong, momentumNow)
}

fun closeTrade(
    trades: MutableList<Trade>,
    closeTimes: List<Long>,
    entryIndex: Int,
    exitIndex: Int,
    entryPrice: Double,
    exitRaw: Double,
    reason: String
): Double {
    val exitPrice = exitRaw * (1.0 - ASSUMED_SLIPPAGE_PERCENT_PER_SIDE / 100.0)
    val buyValue = entryPrice
    val sellValue = exitPrice
    val qty = 1.0 / buyValue
    val grossPnl = (sellValue - buyValue) * qty
    val exchangeFees = (buyValue * qty + sellValue * qty) * FEE_RATE_PER_SIDE
    val tds = sellValue * qty * TDS_RATE_ON_SELL
    val taxOnGain = if (grossPnl > 0) grossPnl * FLAT_TAX_RATE_ON_GAINS else 0.0
    val netPnl = grossPnl - exchangeFees - tds - taxOnGain
    val grossPnlPercent = (sellValue - buyValue) / buyValue * 100.0
    trades.add(Trade(closeTimes[entryIndex], closeTimes[exitIndex], entryPrice, exitPrice, netPnl, grossPnlPercent, reason))
    return netPnl
}

fun main(args: Array<String>) {
    if (args.isEmpty()) {
        println("Usage: java -jar backtest.jar <klines.csv> [more.csv ...] [--as-of-ms=EPOCH_MS | --as-of-date=YYYY-MM-DD]")
        return
    }

    // Point-in-time guard: a historical run can explicitly set its analysis
    // cutoff. Every candle after that cutoff is discarded before strategy
    // evaluation. This same rule must be applied to any future news/sentiment
    // or fundamental inputs added to a backtest.
    val asOfMs = args.firstOrNull { it.startsWith("--as-of-ms=") }?.substringAfter("=")?.toLongOrNull()
        ?: args.firstOrNull { it.startsWith("--as-of-date=") }?.substringAfter("=")?.let {
            runCatching { LocalDate.parse(it).plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() - 1L }.getOrNull()
        }
    val dataFiles = args.filterNot { it.startsWith("--as-of-ms=") || it.startsWith("--as-of-date=") }
    if (dataFiles.isEmpty()) {
        println("No CSV data file supplied.")
        return
    }

    data class Row(val open: Double, val high: Double, val low: Double, val close: Double, val closeTime: Long)
    val rows = mutableListOf<Row>()
    for (path in dataFiles) {
        val file = File(path)
        if (!file.exists()) {
            println("File not found: $path")
            return
        }
        file.forEachLine { line ->
            if (line.isBlank()) return@forEachLine
            val cols = line.split(",")
            if (cols.size < 7) return@forEachLine
            val o = cols[1].toDoubleOrNull() ?: return@forEachLine
            val h = cols[2].toDoubleOrNull() ?: return@forEachLine
            val l = cols[3].toDoubleOrNull() ?: return@forEachLine
            val close = cols[4].toDoubleOrNull() ?: return@forEachLine
            val closeTime = cols[6].toLongOrNull() ?: return@forEachLine
            if (closeTime <= 0L || asOfMs != null && closeTime > asOfMs) return@forEachLine
            if (o <= 0 || h <= 0 || l <= 0 || close <= 0 || h < l || h < o || h < close || l > o || l > close) return@forEachLine
            rows += Row(o, h, l, close, closeTime)
        }
    }

    rows.sortBy { it.closeTime }
    val deduped = rows.distinctBy { it.closeTime }
    val highs = deduped.map { it.high }
    val lows = deduped.map { it.low }
    val closes = deduped.map { it.close }
    val closeTimes = deduped.map { it.closeTime }

    if (asOfMs != null) println("Point-in-time cutoff: ${asOfMs} (all later candles excluded before evaluation).")
    if (closes.size < maxOf(LONG_PERIOD, REGIME_PERIOD) + MOMENTUM_LOOKBACK + 5) {
        println("Not enough candles (${closes.size}) for the configured periods (need > ${maxOf(LONG_PERIOD, REGIME_PERIOD)}).")
        return
    }

    val be = breakEvenMoveFraction()
    println("Loaded ${closes.size} closed candles from ${args.size} file(s).")
    println("Strategy: SMA($SHORT_PERIOD/$LONG_PERIOD), RSI($RSI_PERIOD, Wilder), " +
        "momentum ${MOMENTUM_THRESHOLD_PERCENT}% over $MOMENTUM_LOOKBACK candles (fresh cross), regime SMA($REGIME_PERIOD)")
    println("Exits: stop-loss ${STOP_LOSS_PERCENT * 100}%, trailing activate ${TRAILING_ACTIVATION_PERCENT * 100}% / " +
        "giveback ${TRAILING_GIVEBACK_PERCENT * 100}pp, trail floor BE ${"%.2f".format(be * 100)}%, min hold $MIN_HOLD_CANDLES, cooldown $ENTRY_COOLDOWN_CANDLES")
    println("Costs: fee ${FEE_RATE_PER_SIDE * 100}%/side, TDS ${TDS_RATE_ON_SELL * 100}% of sell, " +
        "tax ${FLAT_TAX_RATE_ON_GAINS * 100}% of gains (no loss offset), " +
        "assumed slippage ${ASSUMED_SLIPPAGE_PERCENT_PER_SIDE}%/side")
    println("Intrabar high/low used for stop-loss simulation.")
    println()

    var lastShortAboveLong: Boolean? = null
    var momentumWasTrue = false
    var inPosition = false
    var entryPrice = 0.0
    var entryIndex = 0
    var peakProfitPercent = 0.0
    var lastExitIndex = -9999

    val trades = mutableListOf<Trade>()

    val minCandlesNeeded = maxOf(LONG_PERIOD, REGIME_PERIOD)
    for (i in minCandlesNeeded until closes.size) {
        val price = closes[i]
        val (signal, shortAboveLong, momentumNow) = evaluate(closes, i, lastShortAboveLong, momentumWasTrue)
        lastShortAboveLong = shortAboveLong
        momentumWasTrue = momentumNow

        if (inPosition) {
            val stopPrice = entryPrice * (1.0 - STOP_LOSS_PERCENT)
            if (lows[i] <= stopPrice) {
                closeTrade(trades, closeTimes, entryIndex, i, entryPrice, stopPrice, "STOP")
                inPosition = false
                peakProfitPercent = 0.0
                lastExitIndex = i
                continue
            }

            val highProfit = (highs[i] - entryPrice) / entryPrice
            if (highProfit > peakProfitPercent) peakProfitPercent = highProfit
            val currentProfitPercent = (price - entryPrice) / entryPrice
            val givebackFromPeak = peakProfitPercent - currentProfitPercent
            val trailingActive = peakProfitPercent >= TRAILING_ACTIVATION_PERCENT
            val aboveBe = currentProfitPercent >= be

            val exitReason = when {
                trailingActive && givebackFromPeak >= TRAILING_GIVEBACK_PERCENT && aboveBe -> ExitReason.TRAILING_STOP
                else -> ExitReason.NONE
            }
            val heldLongEnough = (i - entryIndex) >= MIN_HOLD_CANDLES
            val shouldExitOnSignal = signal == Signal.SELL && heldLongEnough

            if (exitReason != ExitReason.NONE || shouldExitOnSignal) {
                val why = if (exitReason == ExitReason.TRAILING_STOP) "TRAIL" else "REVERSAL"
                closeTrade(trades, closeTimes, entryIndex, i, entryPrice, price, why)
                inPosition = false
                peakProfitPercent = 0.0
                lastExitIndex = i
            }
        } else if (signal == Signal.BUY && (i - lastExitIndex) >= ENTRY_COOLDOWN_CANDLES) {
            entryPrice = price * (1.0 + ASSUMED_SLIPPAGE_PERCENT_PER_SIDE / 100.0)
            entryIndex = i
            inPosition = true
            peakProfitPercent = 0.0
        }
    }

    if (trades.isEmpty()) {
        println("No trades were triggered over this dataset with the current parameters.")
        return
    }

    val wins = trades.count { it.netPnl > 0 }
    val losses = trades.count { it.netPnl <= 0 }
    val winRate = wins.toDouble() / trades.size * 100.0
    val avgNetPnlPercent = trades.map { it.netPnl * 100.0 }.average()
    val expectancyPerTrade = trades.map { it.netPnl }.average() * 100.0
    val grossWins = trades.filter { it.netPnl > 0 }.sumOf { it.netPnl }
    val grossLossesAbs = kotlin.math.abs(trades.filter { it.netPnl <= 0 }.sumOf { it.netPnl })
    val profitFactor = if (grossLossesAbs <= 0) Double.POSITIVE_INFINITY else grossWins / grossLossesAbs

    var peak = 1.0
    var runningEquity = 1.0
    var maxDrawdownPercent = 0.0
    var streak = 0
    var longestLossStreak = 0
    for (t in trades) {
        runningEquity *= (1.0 + t.netPnl)
        if (runningEquity > peak) peak = runningEquity
        val dd = (peak - runningEquity) / peak * 100.0
        if (dd > maxDrawdownPercent) maxDrawdownPercent = dd
        if (t.netPnl <= 0) {
            streak++
            if (streak > longestLossStreak) longestLossStreak = streak
        } else streak = 0
    }

    val mid = closes.size / 2
    val oos = trades.filter { it.entryTime >= (closeTimes.getOrNull(mid) ?: 0L) }
    val oosExpect = if (oos.isEmpty()) 0.0 else oos.map { it.netPnl }.average() * 100.0

    println("=== Results ===")
    println("Total trades:        ${trades.size}")
    println("Win rate:            ${"%.1f".format(winRate)}% ($wins wins / $losses losses)")
    println("Profit factor:       ${"%.2f".format(profitFactor)}")
    println("Avg net P&L/trade:   ${"%.3f".format(avgNetPnlPercent)}% of capital deployed")
    println("Expectancy/trade:    ${"%.3f".format(expectancyPerTrade)}%")
    println("Max drawdown:        ${"%.2f".format(maxDrawdownPercent)}%")
    println("Longest losing streak: $longestLossStreak")
    println("OOS trades (2nd half): ${oos.size}, OOS expectancy ${"%.3f".format(oosExpect)}%")
    println()
    if (expectancyPerTrade <= 0) {
        println("Expectancy is <= 0 on this dataset after costs. Do not trade this configuration live.")
    } else {
        println("Expectancy is positive on this dataset — necessary, not sufficient. Test other months before live.")
    }
}
